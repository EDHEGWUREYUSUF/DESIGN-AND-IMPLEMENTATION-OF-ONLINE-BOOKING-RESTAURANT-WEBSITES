<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('designs/backend');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>

<div class="main-content">
    <div class="page-header">
        <h2 class="header-title" style="width:100%;">
            Restaurant Food
        </h2>
    </div>
    
    <!-- Search -->
    <div class="row">
        <div class="col-12 col-sm-6 mb-3">
            <div class="search-tool">
                <input id="search" class="form-control" placeholder="Search..." oninput="load('', '')" />
            </div>
        </div>
        
        <?php 
        if($role != 'administrator' && $role != 'developer') {?>
            
            <div class="col-sm-6 mb-3">
                <a href="javascript:;" class="btn btn-primary btn-block pop" pageSize="modal-lg" pageTitle="Add Food" pageName="<?=site_url('kitchen/food/manage'); ?>"><i class="anticon anticon-plus-square"></i> Add Food</a>
            </div>
        <?php } else { ?>
            <div class="col-sm-3 mb-3">
                <select id="category_id" class="select2" onchange="load('', '');">
                    <option value="">All Restaurant...</option>
                    <?php 
                        $role_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
                        $pro = $this->Crud->read_single_order('role_id', $role_id, 'user', 'business_name', 'asc'); 
                        if(!empty($pro)){
                            foreach($pro as $prod){?>
                            <option value="<?=$prod->id; ?>" <?php if(!empty($e_restaurant_id)){if($e_restaurant_id == $prod->id){echo 'selected';}} ?>><?=ucwords($prod->business_name); ?></option>
                    <?php } }?>
                </select>
            </div>
            <div class="col-sm-3 mb-3">
                <a href="javascript:;" class="btn btn-primary btn-block pop" pageSize="modal-lg"  pageTitle="Add Food" pageName="<?=site_url('kitchen/food/manage'); ?>"><i class="anticon anticon-plus-square"></i> Add Food</a>
            </div>

        <?php } ?>
        
    </div>

    <!-- List -->
    <div class="row mt-1 mb-2">
        <div class="col-sm-12">
            <ul class="list-group">
                <div id="load_data"></div>
            </ul>

            <div id="loadmore"></div>
        </div>
    </div>
</div>
<script src="<?php echo site_url(); ?>assets/backend/jquery.min.js"></script>
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script>
    $(function() {
        load('', '');
       
    });


    function load(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = x + '/' + y + '/';
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><br/><br/><br/><br/><i class="anticon anticon-loading" style="font-size:48px;"></i></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading"></i></div>');
        }

        var search = $('#search').val();
        var restaurant_id = $('#restaurant_id').val();

        $.ajax({
            url: site_url + 'kitchen/food/load' + methods,
            type: 'post',
             data: { search: search, restaurant_id: restaurant_id },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }

                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-default btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><i class="anticon anticon-reload"></i>Load ' + dt.left + ' More</a>');
                } else {
                    $('#loadmore').html('');
                }
            },
            complete: function () {
                $.getScript(site_url + 'assets/backend/jsmodal.js');
            }
        });
    }
</script>   
<?=$this->endSection();?>