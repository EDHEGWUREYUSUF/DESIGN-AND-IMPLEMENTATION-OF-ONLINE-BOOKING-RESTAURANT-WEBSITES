<?php

namespace App\Controllers;

class Order extends BaseController {

    
    //Orders
	public function index($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'order';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'order';
		$form_link = site_url($mod.'/index');
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_pump_id');
                        $code = $this->Crud->read_field('id', $del_id, 'pump', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted pump ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('pump', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_code'] = $e->order_code;
								$data['e_state'] ='re';

								// currency
								$curr = '&#163;';
								$data['e_curr'] = $curr;

								$category_id = $this->Crud->read_field('id', $e->food_id, 'food', 'menu_id');
								$name = $this->Crud->read_field('id', $e->food_id, 'food', 'name');
								$food_img = $this->Crud->read_field('id', $e->food_id, 'food', 'image');
								$vendor_id = $e->restaurant_id;
								$customer_id = $e->user_id;

								// category data
								$category = $this->Crud->read_field('id', $category_id, 'menu', 'name');


								// vendor data
								$vendor = $this->Crud->read_field('id', $vendor_id, 'user', 'business_name');
								$vendor_phone = $this->Crud->read_field('id', $vendor_id, 'user', 'phone');
								$vendor_email = $this->Crud->read_field('id', $vendor_id, 'user', 'email');
								$vendor_img_id = $this->Crud->read_field('id', $vendor_id, 'user', 'img_id');
								$vendor_img = $this->Crud->image($vendor_img_id, 'big');

								// customer data
								$customer = $this->Crud->read_field('id', $customer_id, 'user', 'fullname');
								$customer_phone = $this->Crud->read_field('id', $customer_id, 'user', 'phone');
								$customer_email = $this->Crud->read_field('id', $customer_id, 'user', 'email');
								$customer_img_id = $this->Crud->read_field('id', $customer_id, 'user', 'img_id');
								$customer_img = $this->Crud->image($customer_img_id, 'big');

								$item_name = '';
								
								
								$data['e_menu'] = $category;
								$data['e_vendor'] = $vendor;
								$data['e_name'] = $name;
								$data['e_vendor_phone'] = $vendor_phone;
								$data['e_vendor_email'] = $vendor_email;
								$data['e_vendor_img'] = $vendor_img;
								$data['e_food_img'] = $food_img;
								$data['e_customer'] = $customer;
								$data['e_customer_phone'] = $customer_phone;
								$data['e_customer_email'] = $customer_email;
								$data['e_customer_img'] = $customer_img;
								// $data['e_delivery_date'] = date('M d, Y h:i A', strtotime($e->used_date));
								$data['e_item_name'] = $name;
								$data['e_quantity'] = number_format((float)$e->qty);
								$data['e_price'] = number_format((float)$e->price, 2);
								$data['e_total'] = number_format((float)$e->amount, 2);
								// $data['e_total'] = number_format((float)$e->sub_total, 2);

								if($e->status) { $status = 'Approved'; } else { $status = $e->status; }
								$data['e_status'] = $e->status;
								$data['e_reg_date'] = date('M d, Y h:i A', strtotime($e->reg_date));

								
								$comms = '';
								
								$data['comms'] = $comms;
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$order_id =  $this->request->getVar('order_id');
					$status =  $this->request->getVar('status');
					
					// do create or update
					if($order_id) {
						$upd_data['status'] = $status;
						$send_user = $this->Crud->read_field('id', $order_id, 'order', 'user_id');
						$order_code = $this->Crud->read_field('id', $order_id, 'order', 'order_code');
						$food_id = $this->Crud->read_field('id', $order_id, 'order', 'food_id');
						$amount = $this->Crud->read_field('id', $order_id, 'order', 'amount');
						$restaurant_id = $this->Crud->read_field('id', $order_id, 'order', 'restaurant_id');
						$restaurant = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
						$prepare_time = $this->Crud->read_field('id', $food_id, 'food', 'prepare_time');
						$send_email = $this->Crud->read_field('id', $send_user, 'user', 'email');
						$send_name = $this->Crud->read_field('id', $send_user, 'user', 'fullname');
						$ready_min = $prepare_time;
						$min = date('d F Y H:iA', strtotime(date(fdate). ' + '.$ready_min.' minute'));
						// echo $min;
						// die;

						$upd_rec = $this->Crud->updates('id', $order_id, $table, $upd_data);
						if($upd_rec > 0) {
							if($status == 'confirm'){
								$body = 'Dear '.$send_name.',<br><br> Your order with '.$order_code.' has been <b>Confirmed</b>. Your order will be ready in '.$min.'minutes ('.$ready_min.')';
								$this->Crud->send_email($send_email, 'Order Confirmed', $body);
								$this->Crud->updates('id', $order_id, 'order', array('confirm_date'=>date(fdate)));
							}
							if($status == 'ready'){
								$body = 'Dear '.$send_name.',<br><br> Your order with '.$order_code.' is now <b>Ready for Pickup</b>. at '.$restaurant;
								$this->Crud->send_email($send_email, 'Your Order is Ready', $body);
							}
							if($status == 'delivered'){
								$body = 'Dear '.$send_name.',<br><br> Your order with '.$order_code.' is <b>Delivered Successful</b>.';
								$this->Crud->send_email($send_email, 'Order Delivered', $body);
								$this->Crud->updates('id', $order_id, 'order', array('delivery_date'=>date(fdate)));
								//Pay Restaurant
								if($amount > 0){
									$v_ins['user_id'] = $restaurant_id;
									$v_ins['type'] = 'credit';
									$v_ins['amount'] = $amount;
									$v_ins['item'] = 'order';
									$v_ins['remark'] = 'Order Payment';
									$v_ins['reg_date'] = date(fdate);
									$v_id = $this->Crud->create('wallet', $v_ins);
								}
							}
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $order_id, 'order', 'order_code');
							$action = $by.' updated Order ('.$code.') Status to '.ucwords($status);
							$this->Crud->activity('order', $order_id, $action);

							echo $this->Crud->msg('success', 'Status Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
						
					}
					die;
						
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$count = 0;
			$rec_limit = 25;
			$item = '';

			if($limit == '') {$limit = $rec_limit;}
			if($offset == '') {$offset = 0;}
			
			if(!empty($this->request->getVar('status'))) { $status = $this->request->getVar('status'); } else { $status = ''; }
			if(!empty($this->request->getVar('restaurant_id'))) { $restaurant_id = $this->request->getVar('restaurant_id'); } else { $restaurant_id = ''; }
			if(!empty($this->request->getVar('start_date'))) { $start_date = $this->request->getVar('start_date'); } else { $start_date = ''; }
			if(!empty($this->request->getVar('end_date'))) { $end_date = $this->request->getVar('end_date'); } else { $end_date = ''; }
			$search = $this->request->getVar('search');

			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				if($role == 'kitchen' || $role == 'receptionist'){
					$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
				}
				if($role == 'restaurant'){
					$restaurant_id = $log_id;
				}
	
				$query = $this->Crud->filter_order($limit, $offset, $log_id, $search, $status, $start_date, $end_date, $restaurant_id);
				$all_rec = $this->Crud->filter_order('', '', $log_id, $search, $status, $start_date, $end_date, $restaurant_id);
				if(!empty($all_rec)) { $count = count($all_rec); } else { $count = 0; }
				$curr = '&#163;';
				$debit = 0;
				$credit = 0;
				$resp['count'] = $count;
				
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$code = $q->order_code;
						$user_id = $q->user_id;
						$restaurant_id = $q->restaurant_id;
						$qty = $q->qty;
						$status = $q->status;
						$food_id = $q->food_id;
						$total = number_format((float)$q->amount, 2);
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));
                        // category
						$food = $this->Crud->read_field('id', $food_id, 'food', 'name');

						$menu_id = $this->Crud->read_field('id', $food_id, 'food', 'menu_id');
						$menu = $this->Crud->read_field('id', $menu_id, 'menu', 'name');

						
						// state
						$restaurant = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
						$user = $this->Crud->read_field('id', $user_id, 'user', 'fullname');

						// user 
						$user_image_id = $this->Crud->read_field('id', $restaurant_id, 'user', 'img_id');
						$user_image = $this->Crud->image($user_image_id, 'big');

                        $st = '';
					    if($status == 'pending'){
							$st = '<span class="text-warning">PENDING</span>';
					    }
						if($status == 'confirm'){
							$st = '<span class="text-info">CONFIRMED</span>';
					    }
						if($status == 'ready'){
							$st = '<span class="text-primary
							">READY FOR DELIVERY</span>';
					    }
						if($status == 'delivered'){
							$st = '<span class="text-success">DELIVERED</span>';
					    }

                        // if can edit
						if($role_u) {
						    
							$code = '
								<a href="javascript:;" class="text-success pop" pageTitle="Order Statement" pageName="'.base_url('order/index/manage/edit/'.$id).'" pageSize="modal-lg">
									<i class="anticon anticon-edit"></i> <span class="m-l-3 m-r-10"><b>'.$code.'</b></span>
								</a>
							';
						}
						$item .= '
                            <li class="list-group-item">
                                <div class="row pt-1">
                                    <div class="col-8 col-md-3 mb-0">
                                        <div class="single">
											<div class="text-muted font-size-12">'.$reg_date.'</div>
                                            <b class="font-size-16">'.$food.'</b>
                                            <div class="text-muted font-size-12"><b>MENU: </b>'.strtoupper($menu).'</div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3 mb-0">
                                        <div class="single">
                                            <div class="font-size-14">'.$code.'</div>
                                            <div class="text-muted font-size-12">Customer -> '.strtoupper($user).'</div>
                                            <div class="text-muted font-size-12">Restaurant -> '.strtoupper($restaurant).'</div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="single">
                                            <div class="text-muted font-size-12">'.$st.'</div>
                                            <div class="font-size-14">'.strtoupper('').'</div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-2 text-right">
                                        <div class="single">
                                            <div class="text-muted font-size-12">AMOUNT</div>
                                            <b class="font-size-16 text-success">'.$curr.$total.'</b>
                                        </div>
                                    </div>
                                </div>
                            </li>
						';
					}
				}
			}

			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/><br/><br/>
						<i class="anticon anticon-shopping-cart" style="font-size:150px;"></i><br/><br/>No Orders Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$more_record = $count - ($offset + $rec_limit);
			$resp['left'] = $more_record;
			// $resp['total'] = $curr . number_format($total, 2);
			
			if($count > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage' || $param1 == 'fund' || $param1 == 'statement') { // view for form data posting
			return view('order/list_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Orders  | '.app_name;
			$data['page_active'] = $mod;
			return view('order/list', $data);
		}
    }

}
