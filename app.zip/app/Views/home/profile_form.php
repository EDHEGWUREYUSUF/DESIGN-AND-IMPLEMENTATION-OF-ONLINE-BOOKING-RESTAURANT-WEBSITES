<?php
    use App\Models\Crud;
    $this->Crud = new Crud();

 if($param2 == 'order'){
    $order_id = $param3;
    $food_id = $this->Crud->read_field('id', $order_id, 'order', 'food_id');
    $qty = $this->Crud->read_field('id', $order_id, 'order', 'qty');
    $delivery_date = $this->Crud->read_field('id', $order_id, 'order', 'delivery_date');
    $status = $this->Crud->read_field('id', $order_id, 'order', 'status');
    $order_code = $this->Crud->read_field('id', $order_id, 'order', 'order_code');
    $food = $this->Crud->read_field('id', $food_id, 'food', 'name');
    $amount = $this->Crud->read_field('id', $food_id, 'food', 'price');
    $img = $this->Crud->read_field('id', $food_id, 'food', 'image');
    $menu_id = $this->Crud->read_field('id', $food_id, 'food', 'menu_id');
    $restaurant_id = $this->Crud->read_field('id', $food_id, 'food', 'restaurant_id');
    $menu = $this->Crud->read_field('id', $menu_id, 'menu', 'name');
    $price = $this->Crud->read_field('id', $food_id, 'food', 'price');
    $description = $this->Crud->read_field('id', $food_id, 'food', 'description');
    $restaurant = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
    $address = $this->Crud->read_field('id', $restaurant_id, 'user', 'address');
    $sub_total = (float)$amount * (int)$qty;
    if($status == 'pending'){
        $st = '<small><i class="bi bi-exclamation-octagon-fill text-warning"></i> Pending </small>';
    }
    if($status == 'confirm'){
        $st = '<small><i class="bi bi-check-circle-fill text-info"></i> Confirmed </small>';
    }
    if($status == 'ready'){
        $st = '<small><i class="bi bi-check2-circle text-info"></i> Ready for Pick-up </small>';
    }
    if($status == 'delivered'){
        $st = '<small><i class="bi bi-check2-all text-success"></i> Picked-Up on </small>
        <p class="mb-0 small text-success">'.date('d M Y, h:iA', strtotime($delivery_date)).'</p>';
    }
    $prepare = '';
    // if($prepare_status > 0){
    //     $prepare = '<div class="h6 mb-2 text-dark">'.$prepare_time.' Mins</div>';
    // }


    if(empty($img) || !file_exists($img)){
        $img = 'assets/img/gallery.png';
    }
    ?>
    <div class="login-popup">
        
        <div class="offcanva offcanvas-en" >
            <div class="offcanvas-header border-bottom p-4">
                <h6 class="offcanvas-title fw-bold" id="offcanvasRightLabel">Order #<?=$order_code; ?></h6>
                <button type="button" class="btn-close position-absolut" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body p-4">
                <div class="mb-3 d-flex gap-3">
                    <i class="bi bi-geo-alt h5 mb-0"></i>
                    <span class="text-start">
                        <h6 class="mb-0 fw-bold"><?=ucwords($restaurant); ?></h6>
                        <div class="text-muted small text-opacity-50"><?=ucwords($address); ?></div>
                    </span>
                </div>
                <div class="mb-3 d-flex gap-3">
                    <i class="bi bi-house h5 mb-0"></i>
                    <span class="text-start">
                        <h6 class="mb-0 fw-bold">ME</h6>
                    </span>
                </div>
                <div class="mb-4 d-flex align-items-center gap-3 border-top pt-4 mt-4">
                    <?=$st; ?>
                </div>
                <div class="bg-white cart-box border rounded position-relative mb-3">
                    <div class="p-3 border-bottom">
                        
                    </div>
                    <div class="py-2">
                        <div class="cart-box-item d-flex align-items-center py-2 px-3">
                            <div class="success-dot"></div>
                            <div class="cart-box-item-title px-2">
                                <p class="mb-0"><?=ucwords($food); ?> x <?=$qty; ?></p>
                                <p class="small text-muted mb-0"><?=ucwords($menu); ?></p>
                            </div>
                            <div class="cart-box-item-price ms-auto">
                                <div class="text-end"><?=curr.number_format($amount,2); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-body border p-3 rounded">
                    <div class="d-flex justify-content-between align-items-center pb-1">
                        <div class="text-muted">Item total</div>
                        <div class="text-dark"><?=curr.number_format($sub_total,2); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<script src="<?php echo site_url(); ?>assets/frontend/js/jsform.js?v=<?=time(); ?>"></script>