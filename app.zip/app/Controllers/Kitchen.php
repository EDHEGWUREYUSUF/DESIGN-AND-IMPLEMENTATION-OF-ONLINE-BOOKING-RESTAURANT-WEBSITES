<?php

namespace App\Controllers;

class Kitchen extends BaseController {
    //Pump for Filling Station
	public function category($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'kitchen/category';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'category';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_category_id');
                        $code = $this->Crud->read_field('id', $del_id, 'category', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted Category ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('kitchen', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_category_id'] = $e->category_id;
								$data['e_restaurant_id'] = $e->restaurant_id;
								
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$cate_id =  $this->request->getVar('cate_id');
					$name =  $this->request->getVar('name');
					$category_id =  $this->request->getVar('category_id');
					$restaurant_id =  $this->request->getVar('restaurant_id');
					if($role == 'kitchen' || $role == 'receptionist'){
						$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
					}
					if($role == 'restaurant'){
						$restaurant_id = $log_id;
					}
		
					// do create or update
					if($cate_id) {
						$upd_data['name'] = $name;
						// $upd_data['category_id'] = $category_id;
						$upd_data['restaurant_id'] = $restaurant_id;
						
						$upd_rec = $this->Crud->updates('id', $cate_id, $table, $upd_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $cate_id, 'category', 'name');
							$action = $by.' updated Category ('.$code.') Record';
							$this->Crud->activity('kitchen', $cate_id, $action);

							echo $this->Crud->msg('success', 'Category Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'category_id', $category_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['name'] = $name;
							// $ins_data['category_id'] = $category_id;
							$ins_data['restaurant_id'] = $restaurant_id;
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Category Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'category', 'name');
								$action = $by.' created Category ('.$code.') Record';
								$this->Crud->activity('kitchen', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('restaurant_id'))) { $restaurant_id = $this->request->getPost('restaurant_id'); } else { $restaurant_id = ''; }
			if(!empty($this->request->getPost('category_id'))) { $category_id = $this->request->getPost('category_id'); } else { $category_id = ''; }
			$search = $this->request->getPost('search');

			$items = '
				<li class="list-group-item d-none d-md-block">
					<div class="row p-t-15">
						<div class="col-sm-8 m-b-2">
							<span class="text-dark"><b>NAME</b></span>
						</div>
						<div class="col-sm-4 m-b-2 text-right" >
							<b>ACTION</b>
						</div>
					</div>
				</li>
				
			';

            //echo $status;
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				if($role == 'kitchen' || $role == 'receptionist'){
					$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
				}
				if($role == 'restaurant'){
					$restaurant_id = $log_id;
				}
	
				$all_rec = $this->Crud->filter_category('', '', $log_id, $restaurant_id, $category_id, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_category($limit, $offset, $log_id, $restaurant_id, $category_id, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$category_id = $q->category_id;
						$restaurant_id = $q->restaurant_id;
						$name = $q->name;
						$restaurant = $this->Crud->read_field('id', $q->restaurant_id, 'user', 'business_name');
						$category = $this->Crud->read_field('id', $q->category_id, 'category', 'name');
						if(empty($category))$category = '-';



						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="anticon anticon-edit"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger ml-3 pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="anticon anticon-trash"></i> Delete
									</a>
								
							';
						}
						$item .= '
							<li class="list-group-item">
								<div class="row pt-1">
									<div class="col-6 col-sm-8 mb-2">
										<span class="text-info"><b>'.strtoupper($name).'</b></span><br>
										Restaurant <i class="anticon anticon-swap-right"></i> <b>'.ucwords($restaurant).'</b>
									</div>
									<div class="col-sm-4 mb-2 text-right" >
										'.$all_btn.'
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<em class="icon anticon anticon-home" style="font-size:150px;"></em><br/><br/>No Restaurant Category Returned
					</div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Category - '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

	public function menu($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'kitchen/menu';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'menu';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_menu_id');
                        $code = $this->Crud->read_field('id', $del_id, 'menu', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted Menu ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('kitchen', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Menu Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_category_id'] = $e->category_id;
								$data['e_restaurant_id'] = $e->restaurant_id;
								$data['e_logo'] = $e->image;
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$menu_id =  $this->request->getVar('menu_id');
					$name =  $this->request->getVar('name');
					$category_id =  $this->request->getVar('category_id');
					$restaurant_id =  $this->request->getVar('restaurant_id');
					$logo = $this->request->getVar('logo');
					if($role == 'kitchen' || $role == 'receptionist'){
						$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
					}
					if($role == 'restaurant'){
						$restaurant_id = $log_id;
					}
					//// Image upload
					if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/menu/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}

					// do create or update
					if($menu_id) {
						$upd_data['name'] = $name;
						// $upd_data['category_id'] = $category_id;
						$upd_data['restaurant_id'] = $restaurant_id;
						$upd_data['image'] = $logo;
						
						$upd_rec = $this->Crud->updates('id', $menu_id, $table, $upd_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $menu_id, 'category', 'name');
							$action = $by.' updated Menu ('.$code.') Record';
							$this->Crud->activity('kitchen', $menu_id, $action);

							echo $this->Crud->msg('success', 'Menu Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'category_id', $category_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['name'] = $name;
							// $ins_data['category_id'] = $category_id;
							$ins_data['restaurant_id'] = $restaurant_id;
							$ins_data['image'] = $logo;
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Menu Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'category', 'name');
								$action = $by.' created Menu ('.$code.') Record';
								$this->Crud->activity('kitchen', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

		// if($param1 == 'get_category'){
		// 	$restaurant_id = $this->request->getPost('restaurant_id');
		// 	$category_id = $this->request->getPost('category_id');
		// 	if($role == 'kitchen' || $role == 'receptionist'){
		// 		$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
		// 	}
		// 	if($role == 'restaurant'){
		// 		$restaurant_id = $log_id;
		// 	}
		// 	$category = $this->Crud->read_single_order('restaurant_id', $restaurant_id, 'category', 'name', 'asc');

		// 	if(empty($category)){
		// 		$cate = '<option value="">Select Restaurant First</option>';
		// 	} else {
		// 		$cate = '<option value="">Select</option>';
		// 		foreach($category as $c){
		// 			$sel = '';
		// 			if($category_id == $c->id)$sel = 'selected';
		// 			$cate .= '<option value="'.$c->id.'" '.$sel.'>'.$c->name.'</option>';
		// 		}
		// 	}

		// 	echo $cate;
		// 	die;
		// }
        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('restaurant_id'))) { $restaurant_id = $this->request->getPost('restaurant_id'); } else { $restaurant_id = ''; }
			if(!empty($this->request->getPost('restaurant_id'))) { $category_id = $this->request->getPost('category_id'); } else { $category_id = ''; }
			$search = $this->request->getPost('search');

			$items = '
				<li class="list-group-item d-none d-md-block">
					<div class="row p-t-15">
						<div class="col-sm-8 m-b-2">
							<span class="text-dark"><b>MENU</b></span>
						</div>
						
						<div class="col-sm-4 m-b-2 text-right" >
							<b>ACTION</b>
						</div>
					</div>
				</li>
				
			';

            //echo $status;
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				if($role == 'kitchen' || $role == 'receptionist'){
					$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
				}
				if($role == 'restaurant'){
					$restaurant_id = $log_id;
				}
				$all_rec = $this->Crud->filter_menu('', '', $log_id, $restaurant_id, $category_id, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_menu($limit, $offset, $log_id, $restaurant_id, $category_id, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$category_id = $q->category_id;
						$restaurant_id = $q->restaurant_id;
						$name = $q->name;
						$logo = $q->image;
						$restaurant = $this->Crud->read_field('id', $q->restaurant_id, 'user', 'business_name');
						$category = $this->Crud->read_field('id', $q->category_id, 'category', 'name');
						if(empty($category))$category = '-';
						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						

						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="anticon anticon-edit"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger ml-3 pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="anticon anticon-trash"></i> Delete
									</a>
								
							';
						}
						$item .= '
							<li class="list-group-item">
								<div class="row pt-1">
									<div class="col-6 col-sm-8 mb-2">
										<div class="d-flex align-items-center">
											<div class="avatar avatar-image">
												<img src="'.site_url($logo).'" alt="">
											</div>
											<div class="m-l-10">
												<div class="text-dark  font-size-16 font-weight-semibold">'.strtoupper($name).'
												<br>
												<i class="anticon anticon-swap-right"></i> '.ucwords($restaurant).'
												</div>
											</div>
										</div>
									</div>
									<div class="col-sm-4 mb-2 text-right" >
										'.$all_btn.'
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<em class="icon anticon anticon-home" style="font-size:150px;"></em><br/><br/>No Restaurant Category Returned
					</div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Menu - '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

	public function food($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'kitchen/food';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'food';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_food_id');
                        $code = $this->Crud->read_field('id', $del_id, 'menu', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted Food ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('kitchen', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Food Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_category_id'] = $e->category_id;
								$data['e_restaurant_id'] = $e->restaurant_id;
								$data['e_menu_id'] = $e->menu_id;
								$data['e_price'] = $e->price;
								$data['e_discount_status'] = $e->discount_status;
								$data['e_discount'] = $e->discount;
								$data['e_prepare_time'] = $e->prepare_time;
								$data['e_description'] = $e->description;
								$data['e_status'] = $e->status;
								$data['e_logo'] = $e->image;
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$food_id =  $this->request->getVar('food_id');
					$name =  $this->request->getVar('name');
					$restaurant_id =  $this->request->getVar('restaurant_id');
					$logo = $this->request->getVar('logo');
					$menu_id =  $this->request->getVar('menu_id');
					$price =  $this->request->getVar('price');
					$prepare_time =  $this->request->getVar('prepare_time');
					$discount_status =  $this->request->getVar('discount_status');
					$discount = $this->request->getVar('discount');
					$description =  $this->request->getVar('description');
					$status =  $this->request->getVar('status');
					$category_id = $this->Crud->read_field('id', $menu_id, 'menu', 'category_id');


					//// Image upload
					if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/food/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}
					if($role == 'kitchen' || $role == 'receptionist'){
						$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
					}
					if($role == 'restaurant'){
						$restaurant_id = $log_id;
					}
					$ins_data['name'] = $name;
					$ins_data['category_id'] = $category_id;
					$ins_data['restaurant_id'] = $restaurant_id;
					$ins_data['image'] = $logo;
					$ins_data['menu_id'] = $menu_id;
					$ins_data['prepare_time'] = $prepare_time;
					$ins_data['price'] = $price;
					$ins_data['discount_status'] = $discount_status;
					$ins_data['discount'] = $discount;
					$ins_data['description'] = $description;
					$ins_data['status'] = $status;
					
					// do create or update
					if($food_id) {
						$upd_rec = $this->Crud->updates('id', $food_id, $table, $ins_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $menu_id, 'food', 'name');
							$action = $by.' updated Food ('.$code.') Record';
							$this->Crud->activity('kitchen', $food_id, $action);

							echo $this->Crud->msg('success', 'Food Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check3('name', $name, 'restaurant_id', $restaurant_id, 'menu_id', $menu_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Food Already Exist');
						} else {
							
							
							$ins_data['reg_date'] = date(fdate);
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Food Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'food', 'name');
								$action = $by.' created Food ('.$code.') Record';
								$this->Crud->activity('kitchen', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

		
		if($param1 == 'get_menu'){
			$restaurant_id = $this->request->getPost('restaurant_id');
			$menu_id = $this->request->getPost('menu_id');

			$category = $this->Crud->read_single_order('restaurant_id', $restaurant_id, 'menu', 'name', 'asc');
			if($role == 'kitchen' || $role == 'receptionist'){
				$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
			}
			if($role == 'restaurant'){
				$restaurant_id = $log_id;
			}
			if(empty($category)){
				$cate = '<option value="">Select Restaurant First</option>';
			} else {
				$cate = '<option value="">Select</option>';
				foreach($category as $c){
					$sel = '';
					if($menu_id == $c->id)$sel = 'selected';
					$cate .= '<option value="'.$c->id.'" '.$sel.'>'.$c->name.'</option>';
				}
			}

			echo $cate;
			die;
		}
		
        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('restaurant_id'))) { $restaurant_id = $this->request->getPost('restaurant_id'); } else { $restaurant_id = ''; }
			if(!empty($this->request->getPost('category_id'))) { $category_id = $this->request->getPost('category_id'); } else { $category_id = ''; }
			$search = $this->request->getPost('search');

			$items = '
				
				
			';

            //echo $status;
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				if($role == 'kitchen' || $role == 'receptionist'){
					$restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
				}
				if($role == 'restaurant'){
					$restaurant_id = $log_id;
				}
				$all_rec = $this->Crud->filter_food('', '', $log_id, $restaurant_id, $category_id, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_food($limit, $offset, $log_id, $restaurant_id, $category_id, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$category_id = $q->category_id;
						$restaurant_id = $q->restaurant_id;
						$name = $q->name;
						$price = $q->price;
						$discount_status = $q->discount_status;
						$discount = $q->discount;
						$description = $q->description;
						$status = $q->status;
						$menu_id = $q->menu_id;
						$logo = $q->image;
						$menu = $this->Crud->read_field('id', $q->menu_id, 'menu', 'name');
						$restaurant = $this->Crud->read_field('id', $q->restaurant_id, 'user', 'business_name');
						$category = $this->Crud->read_field('id', $q->category_id, 'category', 'name');
						if(empty($category))$category = '-';
						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						$reg_date = date('d F Y h:iA', strtotime($q->reg_date));

						$st = '<span class="text-danger mt-4">DISABLED</span>';
						if($status > 0){
							$st = '<span class="text-success mt-4">ACTIVE</span>';
						}

						$discounts = '';
						if($discount_status > 0){
							$discounts = '<br><span class="text-danger">Discount <i class="anticon anticon-swap-right"></i>'.curr.number_format((float)$discount, 2).'</span>';
						}
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="anticon anticon-edit"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger ml-3 pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="anticon anticon-trash"></i> Delete
									</a>
								
							';
						}
						$item .= '
							<li class="list-group-item">
								<div class="row pt-1">
									<div class="col-sm-4 mb-2">
										<div class="d-flex align-items-center">
											<div class="">
												<img src="'.site_url($logo).'" class="rounded" height="100" width="100" alt="">
											</div>
											<div class="m-l-10">
												<div class="text-dark  font-size-16 font-weight-semibold">'.strtoupper($name).'
												<br>
												<i class="anticon anticon-swap-right"></i> '.ucwords($menu).'
												</div>
												<span class="text-primary">'.ucwords($restaurant).'</span>
											</div>
										</div>
									</div>
									<div class=" col-sm-3 mb-2"><br>
										<span class="text-dark font-size-16 mt-4">'.curr.number_format($price,2).'</span>
										
										'.$discounts.'
									</div>
									<div class=" col-sm-3 mb-2"><br><b>'.$st.'</b>
									</div>
									<div class="col-sm-2 mb-2 text-right" ><br>
										'.$all_btn.'
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<em class="icon anticon anticon-coffee" style="font-size:150px;"></em><br/><br/>No Restaurant Food Returned
					</div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Food - '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

}
