<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('designs/backend');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Sales</h3>
                        </div><!-- .nk-block-head-content -->
                        <div class="nk-block-head-content">
                            <div class="toggle-wrap nk-block-tools-toggle">
                                <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="more-options"><em class="icon ni ni-more-v"></em></a>
                                <div class="toggle-expand-content" data-content="more-options">
                                    <ul class="nk-block-tools g-5">
                                        <li>
                                                <div class="col-12 col-sm-12"> <label for="name" class="small text-muted"></label>
                                                    <div class="form-control-wrap">
                                                        <div class="form-icon form-icon-right">
                                                            <em class="icon ni ni-search"></em>
                                                        </div>
                                                        <input type="text" class="form-control" id="search" name="search" placeholder="Search" oninput="load('', '')" >
                                                    </div>
                                                </div>
                                        </li>
                                        <li>
                                            <div class="row">
                                                <div class="col-6 col-sm-6"> <label for="name" class="small text-muted">START DATE</label>
                                                    <input type="date" class="form-control" name="start_date" id="start_date" oninput="loads()" style="border:1px solid #ddd;">
                                                </div>
                                                <div class="col-6 col-sm-6"> <label for="name" class="small text-muted">END DATE</label>
                                                    <input type="date" class="form-control" name="end_date" id="end_date" oninput="loads()" style="border:1px solid #ddd;">
                                                </div>
                                                <div class="col-md-12" style="color: transparent;"><span id="date_resul"></span></div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="row">
                                                <div class="col-12 col-sm-12"> 
                                                    <a href="javascript:;" class="mt-4 btn btn-white btn-outline-light" onclick="$('#filter_box').toggle();"><em class="icon ni ni-filter"></em><span>Filter</span></a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                            
                        </div><!-- .nk-block-head-content -->
                    </div>
                    <div id="filter_box" class="nk-block-between row mt-2 mb-1" style="display:none;">
                                        
                        <div class="col-sm-2 mb-1">
                            <select class="form-select js-select2" data-search="on" id="product_id" name="product_id" onchange="load('','');">
                                <option value="all">All Product</option>
                                <?php $cat = $this->Crud->read_order('category', 'name', 'asc');foreach ($cat as $ca) {?>
                                        <option value="<?=$ca->id;?>"><?=ucwords($ca->name); ?></option>
                                    <?php }?>
                            </select>
                        </div>
                    
                    
                        <div class="col-sm-2 mb-1">
                                <select class="form-select js-select2" data-search="on" id="country_id" name="country_id" onchange="statea();">
                                    <option value="all">Select Country</option>
                                    <?php $cat = $this->Crud->read_order('country', 'name', 'asc');foreach ($cat as $ca) {?>
                                            <option value="<?=$ca->id;?>" <?php if(!empty($e_country_id)){if($e_country_id == $ca->id){echo 'selected';}} ?>><?=ucwords($ca->name); ?></option>
                                        <?php }?>
                                </select>
                        </div>
                    
                        <div class="col-sm-2 mb-1" id="state_resp">
                            <input type="text" class="form-control mt-4" name="state" id="state"  readonly placeholder="Select Country First">
                            <label for="name" class="small text-muted">STATE</label>
                        </div>
                    
                        <div class="col-sm-2 mb-1" id="lga_resp">
                            <input type="text" class="form-control mt-4" name="lga" id="lga"  readonly placeholder="Select State First">
                            <label for="name" class="small text-muted">CITY</label>
                        </div>
                        <div class="col-sm-2 mb-1" id="branch_resp">
                            <input type="text" class="form-control mt-4" name="branch" id="branch"  readonly placeholder="Select City First">
                            <label for="name" class="small text-muted">BRANCH</label>
                        </div>
                    </div><!-- .nk-block-between -->
                </div><!-- .nk-block-head -->
                <div class="nk-block" >
                    <div class="card card-bordered card-stretch">
                        <div class="card-inner-group">
                            <div class="nk-tb-list nk-tb-ulist mb-3" id="load_data">
                        
                            </div>
                            <div id="loadmore"></div><!-- .nk-tb-list -->
                        </div><!-- .nk-block -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo base_url(); ?>/assets/backend/js/jquery.min.js"></script>
<script>
    $(function() {
        load('', '');
    });

    function statea() {
        var country = $('#country_id').val();
        $.ajax({
            url: '<?=site_url('accounts/get_state/');?>'+ country,
            success: function(data) {
                $('#state_resp').html(data);load('', '');
            }
        });
        
    }

    function lgaa() {
        var lga = $('#state').val();
        $.ajax({
            url: '<?=site_url('accounts/get_lga/');?>'+ lga,
            success: function(data) {
                $('#lga_resp').html(data);load('', '');
            }
        });
    }

    function branc() {
        var lgas = $('#lga').val();
        $.ajax({
            url: '<?=site_url('accounts/get_branch/');?>'+ lgas,
            success: function(data) {
                $('#branch_resp').html(data);load('', '');
            }
        });
    }

    function loads() {
        var start_date = $('#start_date').val();
        var end_date = $('#end_date').val();

        if(!start_date || !end_date){
            $('#date_resul').css('color', 'Red');
            $('#date_resul').html('Enter Start and End Date!!');
        } else if(start_date > end_date){
            $('#date_resul').css('color', 'Red');
            $('#date_resul').html('Start Date cannot be greater!');
        } else {
            $('#date_resul').html('');
            load('', '');
        }
    }
   
    function load(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = '/' + x + '/' + y;
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><br/><br/><br/><br/><span class="ni ni-loader fa-spin" style="font-size:38px;"></span></div>');
            $('#total_id').html('<div class="col-sm-12 text-center"><span class="ni ni-loader fa-spin" ></span></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><span class="ni ni-loader fa-spin"></span></div>');
        }

        var product_id = $('#product_id').val();
        var station_id = $('#station_id').val();
        var country_id = $('#country_id').val();
        var state = $('#state').val();
        var lga = $('#lga').val();
        var branch = $('#branch').val();
        var search = $('#search').val();
        var start_date = $('#start_date').val();
        var end_date = $('#end_date').val();
        //alert(status);

        $.ajax({
            url: site_url + 'order/sales/load' + methods,
            type: 'post',
            data: { country_id: country_id,state: state, lga: lga, branch: branch,product_id: product_id,station_id: station_id, search: search, start_date: start_date, end_date: end_date },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }
                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load More</a>');
                } else {
                    $('#loadmore').html('');
                }
            },
            complete: function () {
                $.getScript(site_url + '/assets/backend/js/jsmodal.js');
            }
        });
    }
</script>   

<?=$this->endSection();?>