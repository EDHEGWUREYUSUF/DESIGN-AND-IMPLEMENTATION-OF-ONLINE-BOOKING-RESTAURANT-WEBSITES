<?php

namespace App\Controllers;

class Support extends BaseController {
    //Pump for Filling Station
	public function list($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('fls_id') == ''){
			$request_uri = uri_string();
			$this->session->set('fls_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'support/list';

        $log_id = $this->session->get('fls_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'support';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_support_id');
                        $code = $this->Crud->read_field('id', $del_id, 'support', 'title');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted support ticket('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('support', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} elseif($param2 == 'escalate'){
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('e_support_id');
                        $code = $this->Crud->read_field('id', $del_id, 'support', 'title');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' escalated support ticket('.$code.')';
						
						$te = $this->Crud->read_single('role_id', 1, 'user');
						foreach($te as $team){
							$in_data['from_id'] = $log_id;
							$in_data['to_id'] = $team->id;
							$in_data['content'] = $code;
							$in_data['item'] = 'support';
							$in_data['new'] = 0;
							$in_data['reg_date'] = date(fdate);
							$in_data['item_id'] = $del_id;
							$this->Crud->create('notify', $in_data);
							
						}
							///// store activities
						$this->Crud->activity('support', $del_id, $action);
						
						echo $this->Crud->msg('success', 'Support Ticket Escalated');
						echo '<script>location.reload(false);</script>';
						
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_title'] = $e->title;
								$data['e_details'] = $e->details;
								$data['e_role_id'] = $e->role_id;
								$data['e_img'] = $e->file;
								$data['e_status'] = $e->status;
							}
						}
					}
				}

                // prepare for edit
				if($param2 == 'view') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_user_id'] = $e->user_id;
								$data['e_title'] = $e->title;
								$data['e_details'] = $e->details;
								$data['e_reg_date'] = $e->reg_date;
								$data['e_img'] = $e->file;
								$data['e_status'] = $e->status;
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$support_id =  $this->request->getVar('support_id');
					$title =  $this->request->getVar('name');
					$details =  $this->request->getVar('details');
					$status =  $this->request->getVar('status');
                    $img_id =  $this->request->getVar('img');
					
                    //// Image upload
					if(file_exists($this->request->getFile('pics'))) {
						$path = 'assets/backend/images/users/'.$log_id.'/';
						$file = $this->request->getFile('pics');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $img_id = $getImg->path;
					}

					$teams = ["3","6"];
					$opt = json_encode($teams);
					$branch = $this->Crud->read_field('id', $log_id, 'user', 'branch_id');
					$partner_id = $this->Crud->read_field('id', $log_id, 'user', 'partner_id');
					$branch_id = $this->Crud->read_field2('branch_id', $branch, 'role_id', 6, 'user', 'id');
					// do create or update
					if($support_id) {
						$upd_data['title'] = $title;
						if(!empty($img_id) || !empty($getImg->path))$upd_data['file'] = $img_id;
						$upd_data['details'] = $details;
						$upd_data['status'] = $status;
						
						$upd_rec = $this->Crud->updates('id', $support_id, $table, $upd_data);
						if($upd_rec > 0) {
							$op = json_decode($opt);
							for($i=0; $i <=1; $i++){
								if($i == 0)	$team = $partner_id;  
								if($i == 1) $team = $branch_id; 
								if($i > 1) continue;
								$in_data['from_id'] = $log_id;
								$in_data['to_id'] = $team;
								$in_data['content'] = $title;
								$in_data['item'] = 'support';
								$in_data['new'] = 0;
								$in_data['reg_date'] = date(fdate);
								$in_data['item_id'] = $support_id;
								$this->Crud->create('notify', $in_data);
							
							} 
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $support_id, 'support', 'title');
							$action = $by.' updated Support ('.$code.') Record';
							$this->Crud->activity('support', $support_id, $action);

							echo $this->Crud->msg('success', 'Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('title', $title, 'user_id', $log_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['title'] = $title;
							if(!empty($img_id) || !empty($getImg->path))$ins_data['file'] = $img_id;
							$ins_data['details'] = $details;
							$ins_data['status'] = $status;
							$ins_data['branch_id'] = $branch_id;
							$ins_data['user_id'] = $log_id;
							$ins_data['role_id'] = $opt;
							$ins_data['reg_date'] = date(fdate);
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Record Created');
								$op = json_decode($opt);
								for($i=0; $i <=1; $i++){
									if($i == 0)	$team = $partner_id;  
									if($i == 1) $team = $branch_id; 
									if($i > 1) continue;
									$in_data['from_id'] = $log_id;
									$in_data['to_id'] = $team;
									$in_data['content'] = $title;
									$in_data['item'] = 'support';
									$in_data['new'] = 0;
									$in_data['reg_date'] = date(fdate);
									$in_data['item_id'] = $ins_rec;
									$this->Crud->create('notify', $in_data);
								
								} 
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'support', 'title');
								$action = $by.' created Support Ticket ('.$code.') Record';
								$this->Crud->activity('support', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

			$items = '
				<div class="nk-tb-item nk-tb-head">
					<div class="nk-tb-col"><span class="sub-text">User</span></div>
					<div class="nk-tb-col"><span class="sub-text">Title</span></div>
					<div class="nk-tb-col tb-col-lg"><span class="sub-text">Description</span></div>
					<div class="nk-tb-col tb-col-mb"><span class="sub-text">Status</span></div>
					<div class="nk-tb-col"><span class="sub-text"></span></div>
				</div><!-- .nk-tb-item -->
				
			';

            //echo $status;
			$log_id = $this->session->get('fls_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_support('', '', $log_id, $status, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_support($limit, $offset, $log_id, $status, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$title = $q->title;
						$user_i = $q->user_id;
						$status = $q->status;
						$details = $q->details;
						$reg_date = date('M d, Y h:ia', strtotime($q->reg_date));
						$file = $q->file;

						$img_id = $this->Crud->read_field('id', $user_i, 'user', 'img_id');
						$names = $this->Crud->read_field('id', $user_i, 'user', 'fullname');
						if(empty($img_id)){
							$wors = $this->Crud->image_name($names);
							$img = '<span>'.$wors.'</span>';
						} else {
							$image = $this->Crud->read_field('id', $img_id, 'file', 'path');
							$img = '<img height="38px" src="'.site_url($image).'">';
						}
						if($status == 0){
							$stat = 'Ticket Opened';
							$st = 'danger';
						} else {
							$stat = 'Ticket Closed';
							$st = 'success';
						}
						$my_branch = $this->Crud->read_field('id', $log_id, 'user', 'branch_id');
						$part = $this->Crud->read_field('id', $user_i, 'user', 'partner_id');
								
                        $string = (strlen($details) > 13) ? substr($details,0,40).'...' : $details;
						$es_btn = '';
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$title.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="ni ni-edit-alt"></i> Edit
									</a><br>
									<a href="'.site_url('support/comment/'.$id).'" class="text-info"  pageName="">
										<i class="ni ni-eye"></i> Attend
									</a>
								
							';
							if(($my_branch == $q->branch_id  && $role == 'manager' && $status == 0) || ($part == $log_id  && $role == 'partner' && $status == 0)){
								
								$es_btn = '
									<br>
									<a href="javascript:;" class="text-danger pop" pageTitle="Manage '.$title.'" pageName="'.site_url($mod.'/manage/escalate/'.$id).'">
										<i class="ni ni-send"></i> Escalate
									</a>
								';
							}
						}

						if($role == 'developer' || $role == 'administrator'){
							$item .= '
								<div class="nk-tb-item">
									<div class="nk-tb-col">
										<div class="user-card">
											<div class="user-avatar ">
												'.$img.'
											</div>
											<div class="user-info">
												<span class="tb-lead">'.ucwords($names).' <span class="dot dot-success d-md-none ms-1"></span></span>
												<span>'.$reg_date.'</span>
											</div>
										</div>
									</div>
									<div class="nk-tb-col">
										<span class="text-dark"><b>'.ucwords($title).'</b></span>
									</div>
									<div class="nk-tb-col tb-col-mb">
										<span>'.ucwords($string).'</span>
									</div>
									<div class="nk-tb-col tb-col-mb">
										<span class="text-'.$st.'">'.$stat.'</span>
									</div>
									<div class="nk-tb-col nk-tb-col-mb">
										'.$all_btn.'
									</div>
								</div><!-- .nk-tb-item -->
							';
						} else {
							if($user_i == $log_id){
								$item .= '
									<div class="nk-tb-item">
										<div class="nk-tb-col">
											<div class="user-card">
												<div class="user-avatar ">
													'.$img.'
												</div>
												<div class="user-info">
													<span class="tb-lead">'.ucwords($names).' <span class="dot dot-success d-md-none ms-1"></span></span>
													<span>'.$reg_date.'</span>
												</div>
											</div>
										</div>
										<div class="nk-tb-col">
											<span class="text-dark"><b>'.ucwords($title).'</b></span>
										</div>
										<div class="nk-tb-col tb-col-mb">
											<span>'.ucwords($string).'</span>
										</div>
										<div class="nk-tb-col tb-col-mb">
											<span class="text-'.$st.'">'.$stat.'</span>
										</div>
										<div class="nk-tb-col nk-tb-col-mb">
											'.$all_btn . $es_btn.'
										</div>
									</div><!-- .nk-tb-item -->
								';
							} else {
								$my_branch = $this->Crud->read_field('id', $log_id, 'user', 'branch_id');
								$part = $this->Crud->read_field('id', $user_i, 'user', 'partner_id');
								if(($my_branch == $q->branch_id  && $role == 'manager') || ($part == $log_id  && $role == 'partner')){
									$item .= '
										<div class="nk-tb-item">
											<div class="nk-tb-col">
												<div class="user-card">
													<div class="user-avatar ">
														'.$img.'
													</div>
													<div class="user-info">
														<span class="tb-lead">'.ucwords($names).' <span class="dot dot-success d-md-none ms-1"></span></span>
														<span>'.$reg_date.'</span>
													</div>
												</div>
											</div>
											<div class="nk-tb-col">
												<span class="text-dark"><b>'.ucwords($title).'</b></span>
											</div>
											<div class="nk-tb-col tb-col-mb">
												<span>'.ucwords($string).'</span>
											</div>
											<div class="nk-tb-col tb-col-mb">
												<span class="text-'.$st.'">'.$stat.'</span>
											</div>
											<div class="nk-tb-col nk-tb-col-mb">
												'.$all_btn . $es_btn.'
											</div>
										</div><!-- .nk-tb-item -->
									';
								}
							}
						}

						
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="text-center text-muted">
                                <br/><br/><br/><br/>
                                <i class="ni ni-chat_circle" style="font-size:150px;"></i><br/><br/>No Support Ticket Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Support Ticket  | '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

     //Filling Station Branch
	public function comment($param1='', $param2='', $param3='', $param4='') {
		// check session login
		if($this->session->get('fls_id') == ''){
			$request_uri = uri_string();
			$this->session->set('fls_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'support/list';

        $log_id = $this->session->get('fls_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

		$data['file'] = $this->Crud->read_field('id', $param1, 'support', 'file');
		$data['titles'] = $this->Crud->read_field('id', $param1, 'support', 'title');
		$data['details'] = $this->Crud->read_field('id', $param1, 'support', 'details');
		$data['reg_date'] = $this->Crud->read_field('id', $param1, 'support', 'reg_date');
		$user = $this->Crud->read_field('id', $param1, 'support', 'user_id');
		$img_id = $this->Crud->read_field('id', $user, 'user', 'img_id');
		$names = $this->Crud->read_field('id', $user, 'user', 'fullname');
		if(empty($img_id)){
			$wors = $this->Crud->image_name($names);
			$img = '<span>'.$wors.'</span>';
		} else {
			$image = $this->Crud->read_field('id', $img_id, 'file', 'path');
			$img = '<img height="40px" src="'.site_url($image).'">';
		}
		$data['name'] = $names;
		$data['usr'] = $user;
		$data['image'] = $img;
       
		$table = 'branch';
		$form_link = site_url('support/comment');
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= '/'.$param3.'/';}
		if($param4){$form_link .= $param4;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['param4'] = $param4;
		$data['form_link'] = $form_link;

      
		// record listing
		if($param2 == 'load') {
			$limit = $param3;
			$offset = $param4;

			$count = 0;
			$rec_limit = 25;
			$item = '';

			if($limit == '') {$limit = $rec_limit;}
			if($offset == '') {$offset = 0;}
			
			$search = $this->request->getVar('search');
			$todo = $param1;
			
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$query = $this->Crud->filter_comment($limit, $offset, $log_id, $todo, $search);
				$all_rec = $this->Crud->filter_comment('', '', $log_id, $todo, $search);
				if(!empty($all_rec)) { $count = count($all_rec); } else { $count = 0; }

				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$comment = $q->comment;
						$resp_id = $q->resp_id;
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));
                        
						//$user = $this->Crud->read_field('id', $param1, 'support', 'user_id');
						$img_id = $this->Crud->read_field('id', $resp_id, 'user', 'img_id');
						$names = $this->Crud->read_field('id', $resp_id, 'user', 'fullname');
						if(empty($img_id)){
							$wors = $this->Crud->image_name($names);
							$img = '<span>'.$wors.'</span>';
						} else {
							$image = $this->Crud->read_field('id', $img_id, 'file', 'path');
							$img = '<img height="38px" src="'.site_url($image).'">';
						}
						$name = $names;
						$image = $img;

						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="ni ni-edit-alt"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="ni ni-trash-alt"></i> Delete
									</a>
								
							';
						}


                        $item .= '
							<div class="nk-reply-item">
								<div class="nk-reply-header">
									<div class="user-card">
										<div class="user-avatar bg-pink">
											'.$image.'
										</div>
										<div class="user-name">'.ucwords($name).'</div>
									</div>
									<div class="date-time">'.$reg_date.'</div>
								</div>
								<div class="nk-reply-body">
									<div class="nk-reply-entry entry">
										'.ucwords($comment).'
									</div>
								</div>
							</div>

							<hr>	
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = '
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="text-center text-muted">
                                <br/><br/><br/><br/>
                                <i class="ni ni-chat-circle" style="font-size:150px;"></i><br/><br/>No Comment Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $count;

			$more_record = $count - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($count > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view('support/comment_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Support Tickets  | '.app_name;
			$data['page_active'] = $mod;
			return view('support/comment', $data);
		}
    }

	public function save_comment(){
		$log_id = $this->session->get('fls_id');
		$support_id = $this->request->getVar('support_id');
		$user_id = $this->Crud->read_field('id', $support_id, 'support', 'user_id');
		$comment = $this->request->getVar('comment');
		if(!empty($comment)){
			if($this->Crud->check3('resp_id', $log_id, 'comment', $comment, 'support_id', $support_id, 'support_comment') == 0){
				$ins_rec['user_id'] = $user_id;
				$ins_rec['support_id'] = $support_id;
				$ins_rec['resp_id'] = $log_id;
				$ins_rec['comment'] = $comment;
				$ins_rec['reg_date'] = date(fdate);
				$this->Crud->create('support_comment', $ins_rec);
			}
		}
		echo 'Comment ('.$this->Crud->check('support_id', $support_id, 'support_comment').')';
	}
}
