<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('frontend/designs');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>

<div class="container py-5">
   <div class="row">
      <div class="col-lg-12">
         <div class="shadow-sm bg-white rounded overflow-hidden border">
            <div class="p-0">
               <div class="row px-0 m-0">
                  <div class="col-12 col-md-3 px-0 bg-light">
                     <div class="border-bottom d-flex bg-white border-end align-items-center gap-3 p-4">
                        <img src="assets/img/team1.jpg" alt class="img-fluid rounded-circle bg-light h-40">
                        <span class="text-start">
                           <p class="mb-0 fw-bold"><?=ucwords($log_name); ?></p>
                           <small class="text-muted"><i class="bi bi-phone"></i> <?=$log_phone; ?></small>
                        </span>
                        <span class="ms-auto" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit Profile">
                           <a data-bs-toggle="modal" data-bs-target="#staticBackdropep" class="text-decoration-none" href="#"><i class="bi bi-pencil-square icon-sm"></i></a>
                        </span>
                     </div>
                     <div class="nav p-4 ps-md-4 py-md-4 pe-md-0 bg-light flex-column delivery-tabs" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <button class="nav-link py-3 active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="bi bi-list"></i> Orders List</button>
                        <button class="nav-link py-3" id="v-pills-about-tab" data-bs-toggle="pill" data-bs-target="#v-pills-about" type="button" role="tab" aria-controls="v-pills-about" aria-selected="false"><i class="bi bi-globe"></i> About</button>
                        <a href="<?=site_url('auth/logout'); ?>" class="nav-link py-3"><i class="bi bi-lock"></i> Logout</a>
                     </div>
                  </div>
                  <div class="col-12 col-md-9 px-0">

                     <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                           <div class="p-4">
                              <div class="mb-4">
                                 <h5 class="mb-0 fw-bold">My Orders</h5>
                              </div>
                              <div class="row row-cols-1 row-cols-md-1 g-4" id="load_data">
                                 
                                 
                              </div>
                              <div class="row row-cols-1 row-cols-md-1 py-3 g-4" id="">
                                 
                                 <div class="col" id="loadmore">
                                    
                                 </div>
                              </div>
                           </div>
                        </div>


                        <div class="tab-pane fade" id="v-pills-about" role="tabpanel" aria-labelledby="v-pills-about-tab">
                           <div class="p-4">
                              <div class="mb-4">
                                 <h5 class="mb-0 fw-bold">About Us</h5>
                              </div>
                              <div class="mb-4">
                                 <h6 class="fw-bold">You now have the power to move things</h6>
                                 <p class="text-muted">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                              </div>
                              <div class="mb-4">
                                 <h6 class="fw-bold">Relationship</h6>
                                 <p class="text-muted">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
                              </div>
                              <div class="mb-4">
                                 <h6 class="fw-bold">Notice</h6>
                                 <p class="text-muted mb-2">Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary. </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<input type="hidden" name="restaurant_id" id="restaurant_id" value="<?=$param1; ?>">
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
   $(function() {
     order_load();
   });


   function order_load(x, y) {
      var more = 'no';
      var methods = '';
      if (parseInt(x) > 0 && parseInt(y) > 0) {
         more = 'yes';
         methods = '/' + x + '/' + y;
      }
      console.log('re');
      if (more == 'no') {
         $('#load_data').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
      } else {
         $('#loadmore').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
      }

      var search = $('#searches').val();
      //alert(status);

      $.ajax({
         url: site_url + 'home/profile/order_load' + methods,
         type: 'post',
         success: function (data) {
            var dt = JSON.parse(data);
            if (more == 'no') {
               $('#load_data').html(dt.item);
            } else {
               $('#load_data').append(dt.item);
            }

            if (dt.offset > 0) {
               $('#loadmore').html('<a href="javascript:;" class="btn btn-outline-success btn-lg py-3 px-4 w-100" onclick="order_load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
            } else {
               $('#loadmore').html('');
            }
            $('#counts').html(dt.count);
         },
         complete: function () {
               $.getScript(site_url + '/assets/frontend/js/jsmodal.js');
         }
      });
   }

      // Update the countdown every second
      // setInterval(updateCountdown, 1000);

      function updateCountdown(remainingTime, id) {
         var countdown = document.getElementById("countdown_" + id);
         // Define the interval inside the function
         var countdownInterval = setInterval(function() {
               if (remainingTime <= 0) {
                     countdown.innerHTML = "Food is ready!";
                     // Clear the interval when countdown reaches zero
                     clearInterval(countdownInterval);
               } else {
                     var minutes = Math.floor(remainingTime / 60);
                     var seconds = remainingTime % 60;
                     countdown.innerHTML = "Ready in: " + minutes + " mins, " + seconds + " secs";
                     remainingTime--; // Decrement remaining time
               }
            }, 1000); // Update every second
      }

   </script>

<?=$this->endSection();?>