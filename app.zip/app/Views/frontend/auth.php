<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>
<?php if($param1 == 'login'){?>
    <div class="login-popup">
        <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="row g-0">
            <div class="d-none d-md-flex col-md-4 col-lg-4 bg-image1"></div>
            <div class="col-md-8 col-lg-8 py-lg-5">
                <div class="login p-5">
                    <div class="mb-4 pb-2">
                        <h5 class="mb-2 fw-bold">Login</h5>
                        <p class="text-muted mb-0">Please add your details to sign-in</p>
                    </div>
                    <div class="row">
                        <div class="col-sm-12"><div id="bb_ajax_msg"><div id="bb_ajax_msga"></div></div></div>
                    </div>
                    <?php echo form_open_multipart('auth/login', array('id'=>'bb_ajax_form', 'class'=>'')); ?>
                        <div class="input-group bg-white border rounded mb-3 p-2">
                            <span class="input-group-text bg-white border-0"><i class="bi bi-envelope pe-2"></i></span>
                            <input type="email" class="form-control bg-white border-0 ps-0" name="email" id="email" required placeholder="Enter Email Address">
                        </div>
                        <div class="input-group bg-white border rounded mb-3 p-2">
                            <span class="input-group-text bg-white border-0"><i class="bi bi-key pe-2"></i></span>
                            <input type="password" class="form-control bg-white border-0 ps-0" id="password" name="password" required placeholder="Enter Password">
                        </div>
                        <input type="hidden" name="type" value="web">
                        <button class="btn btn-lg text-white py-3 bb_form_btn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Login <i class="bi bi-arrow-right ms-2"></i></button>
                    </form>
                    <div class="form-check py-3">
                        <a class="text-decoration-none pop" style="color:#1b2a52"  href="javascript:;" pageName="<?=base_url('auth/frontend/forgot'); ?>">Forgot your Password?</a>
                    </div>
                    <div class="form-check py-4 text-center"><span class="text-muted">Dont have an Account?</span><b>
                        <a class="text-decoration-none pop " style="color:#1b2a52"  href="javascript:;" pageSize="modal-lg" pageName="<?=base_url('auth/frontend/register'); ?>">Sign Up </a></b>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php if($param1 == 'register'){?>
    <div class="login-popup">
        <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="row g-0">
            <div class="col-md-12 col-lg-12 py-lg-2">
                <div class="login p-5">
                    <div class="mb-4 pb-2">
                        <?php if(!$log_id){?>
                            <h5 class="mb-2 fw-bold">Sign Up</h5>
                            <p class="text-muted mb-0">Please add your details to sign-up</p>
                        <?php } else {?>
                            <h5 class="mb-2 fw-bold">My Profile</h5>
                            <p class="text-muted mb-0">Edit your details</p>
                        <?php } ?>
                    </div>
                    <?php echo form_open_multipart('auth/register', array('id'=>'bb_ajax_form', 'class'=>'')); ?>
                        <div class="row g-6">
                            <input type="hidden" name="user_id" value="<?php if(!empty($log_id)){echo $log_id;} ?>">
                            <div class=" bg-white border rounded col-md-5 col-12 mx-1 mb-2">
                                <label>Fullname</label>
                                <input type="text" class="form-control bg-white border-0 ps-1" value="<?php $st = $this->Crud->read_field('id', $log_id, 'user', 'fullname'); if(!empty($st)){echo $st;}?>"  name="fullname" id="fullname" required placeholder="Fullname">
                            </div>
                            <div class="bg-white border rounded col-md-6 col-12 mx-1 mb-2">
                                <label>Email Address</label>
                                <input type="email" class="form-control bg-white border-0 ps-1" value="<?php $st = $this->Crud->read_field('id', $log_id, 'user', 'email'); if(!empty($st)){echo $st;}?>" <?php if(!empty($st)){echo 'readonly';} ?> name="email" id="email" required placeholder="Email Address">
                            </div>
                            <div class="bg-white border rounded mb-3 col-md-5 col-12 mx-1">
                                <label>Phone Number</label>
                                <input type="text" class="form-control bg-white border-0 ps-1" onkeypress="return event.charCode == 46 || (event.charCode >= 48 && event.charCode <= 57)" value="<?php $st = $this->Crud->read_field('id', $log_id, 'user', 'phone'); if(!empty($st)){echo $st;}?>"  name="phone" id="phone" required placeholder="Mobile No">
                            </div>
                            <div class="bg-white border rounded mb-3 col-md-6 col-12 mx-1">
                                <label>Address</label>
                                <input type="text" class="form-control bg-white border-0 ps-1" value="<?php $st = $this->Crud->read_field('id', $log_id, 'user', 'address'); if(!empty($st)){echo $st;}?>"  name="address" id="address" required placeholder="Address">
                            </div>
                            <div class="bg-white border rounded mb-3 col-md-5 col-12 mx-1">
                                <label>Password</label>
                                <input type="password" class="form-control bg-white border-0 ps-0" name="password" id="password" required placeholder="Enter Password">
                            </div>
                            <div class="bg-white border rounded mb-3 col-md-6 col-12 mx-1">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control bg-white border-0 ps-0" name="confirm" id="confirm" placeholder="Confirm Password" oninput="check_password()">
                                <div id="password_response"></div>
                            </div>
                            
                        </div>
                        <?php if(empty($log_id)){?>
                            <button class="btn btn-lg text-white py-3 bb_form_btn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Sign Up <i class="bi bi-arrow-right ms-2"></i></button>
                        <?php } else {?>
                            <button class="btn btn-lg text-white py-3 bb_form_btn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Update profiile <i class="bi bi-arrow-right ms-2"></i></button>
                        <?php } ?>
                    </form>
                    <?php if(empty($log_id)){?>
                        <div class="form-check py-4 text-center">
                            <span class="text-muted">Already have an Account?</span><b>
                            <a  href="javascript:;" pageSize="modal-lg" pageName="<?=base_url('auth/frontend/login'); ?>" class="text-decoration-none pop" style="color:#1b2a52">Login </a></b>
                        </div>
                    <?php } ?>
                    <div class="row">
                        <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if($param1 == 'forgot'){?>
    <div class="login-popup">
        <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="row g-0">
            <div class="d-none d-md-flex col-md-4 col-lg-4 bg-image1"></div>
            <div class="col-md-8 col-lg-8 py-lg-5">
                <div class="row">
                    <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
                </div>
                <div class="login p-5">
                    <div class="mb-4 pb-2">
                        <h5 class="mb-2 fw-bold">Reset Password</h5>
                        <p class="text-muted mb-0">Please enter your email to receive a link to create new password</p>
                    </div>
                    <?php echo form_open_multipart('main/reset', array('id'=>'bb_ajax_form', 'class'=>'')); ?>
                        <div class="input-group bg-white border rounded mb-3 p-2">
                            <span class="input-group-text bg-white border-0"><i class="bi bi-envelope pe-2"></i></span>
                            <input type="email" class="form-control bg-white border-0 ps-0" name="email" id="email" required placeholder="Enter Email Address">
                        </div>
                        <button class="btn btn-lg text-white py-3 bb_form_tn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Reset <i class="bi bi-arrow-right ms-2"></i></button>

                        
                    <?php if(empty($log_id)){?>
                        <div class="form-check py-4 text-center">
                            <span class="text-muted">Already have an Account?</span><b>
                            <a  href="javascript:;" pageSize="modal-lg" pageName="<?=base_url('auth/frontend/login'); ?>" class="text-decoration-none pop" style="color:#1b2a52">Login </a></b>
                        </div>
                    <?php } ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if($param1 == 'verify'){?>
    <div class="login-popup">
        <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="row g-0">
            <div class="col-md-12 col-lg-12 py-lg-5">
                <div class="row">
                    <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
                </div>
                <div class="login p-5">
                    <div class="mb-4 pb-2">
                        <h5 class="mb-2 fw-bold">Verify OTP</h5>
                        <p class="text-muted mb-0">Please enter One Time Passsword Sent to your Phone/Email to Complete your Registration</p>
                    </div>
                    
                    <?php echo form_open_multipart('main/verifyOTP', array('id'=>'bb_ajax_form', 'class'=>'')); ?>
                        <div class="d-flex gap-3 text-center">
                            <input type="hidden" name="id" id="id" value="<?=$param2; ?>">
                            <div class="input-group bg-white border rounded mb-3 p-2">
                                <input type="text" name="otp1" id="otp1" required  oninput="this.value=this.value.replace(/[^\d]/,'')" class="form-control bg-white border-0 text-center" maxlength="1">
                            </div>
                            <div class="input-group bg-white border rounded mb-3 p-2">
                                <input type="text" name="otp2" id="otp2" required  oninput="this.value=this.value.replace(/[^\d]/,'')" class="form-control bg-white border-0 text-center" maxlength="1">
                            </div>
                            <div class="input-group bg-white border rounded mb-3 p-2">
                                <input type="text" name="otp3" id="otp3" required  oninput="this.value=this.value.replace(/[^\d]/,'')" class="form-control bg-white border-0 text-center" maxlength="1">
                            </div>
                            <div class="input-group bg-white border rounded mb-3 p-2">
                                <input type="text" name="otp4" id="otp4" required  oninput="this.value=this.value.replace(/[^\d]/,'')" class="form-control bg-white border-0 text-center" maxlength="1">
                            </div>
                        </div>
                        <button class="btn btn-lg text-white py-3 bb_form_btn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Verify <i class="bi bi-arrow-right ms-2"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if($param1 == 'agent'){?>
    <div class="login-popup">
        <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="row g-0">
            <div class="col-md-12 col-lg-12 py-lg-2">
                <div class="login p-5">
                    <div class="mb-4 pb-2">
                        <p class="text-muted mb-0">Enter your details</p>
                    </div>
                    <div class="row">
                        <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
                    </div>
                    <?php echo form_open_multipart('main/delivery_register', array('id'=>'bb_ajax_form', 'class'=>'')); ?>
                        <div class="row">
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Select Prefered Location <small class="text-danger">*</small></label>

                                <select class="form-select" name="state_id" id="state_id" required aria-label="Default select example">
                                    <option value="">Select Location</option>
                                    <?php
                                        $roles = '';
                                        $qroles = $this->Crud->read_order('state', 'name', 'asc');
                                        if(!empty($qroles)) {
                                            foreach($qroles as $qr) {
                                                $allow = array('Lagos', 'Rivers', 'Abuja Federal Capital');
                                                if(!in_array($qr->name, $allow)) continue;
        
                                                $sel = '';
                                                echo '<option value="'.$qr->name.'" '.$sel.'>'.$qr->name.'</option>';
                                            }
                                        }
                                    
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Full Name <small class="text-danger">*</small></label>
                                <input type="text" class="form-control" id="fullname" name="fullname" required placeholder="Enter Your Name">
                            </div>
                            <div class="mb-3 col-sm-12 col-12">
                                <label class="form-label">Address <small class="text-danger">*</small></label>
                                <input type="text" class="form-control" id="address" name="address" required placeholder="Enter Your Address">
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Phone Number <small class="text-danger">*</small></label>
                                <input type="text" class="form-control" id="phone" onkeypress="return event.charCode == 46 || (event.charCode >= 48 && event.charCode <= 57)" name="phone" required placeholder="Enter Your Phone Number">
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Email Address <small class="text-danger">*</small></label>
                                <input type="email" class="form-control" id="email" name="email" required placeholder="Enter Your Email Address">
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">High School Qualification <small class="text-danger">*</small></label>
                                <select class="form-select" name="qualification" id="qualification" required  aria-label="Default select example">
                                    <option value="">Select Qualification</option>
                                    <option value="Degree">Degree</option>
                                    <option value="SSCE">SSCE</option>
                                    <option value="Primary">Primary</option>
                                </select>
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Any Marketing Experience<small class="text-danger">*</small></label>
                                <select class="form-select" name="marketing" id="marketing" required aria-label="Default select example">
                                    <option value="No">No</option>
                                    <option value="Yes">Yes</option>
                                </select>
                            </div>
                            <div class="mb-3 col-sm-6 col-12">
                                <label class="form-label">Proficient in Language <small class="text-danger">*</small></label>
                                <div>
                                    <input type="checkbox" name="language[]" id="language" value="English" class="me-1"><span>English</span>
                                    <input type="checkbox" name="language[]" id="language" value="Igbo" class="me-1"><span>Igbo</span>
                                    <input type="checkbox" name="language[]" id="language" value="Yoruba" class="me-1"><span>Yoruba</span>
                                    <input type="checkbox" name="language[]" id="language" value="Hausa" class="me-1"><span>Hausa</span>
                                </div>
                            </div>
                            <div class="mb-3 col-sm-12 col-12">
                                <label class="form-label">Any Useful Information to share with us</label>
                                <textarea type="text" class="form-control" id="info" name="info" placeholder="Enter Information"></textarea>
                            </div>
                        </div>
                        <button class="btn btn-lg text-white py-3 bb_form_btn px-4 text-uppercase w-100 mt-4" style="background-color:#1b2a53 !important;"  type="submit" id="btns">Submit Form <i class="bi bi-arrow-right ms-2"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<script src="<?php echo site_url(); ?>assets/frontend/js/jsmodal.js"></script>
<script src="<?php echo site_url(); ?>assets/frontend/js/jsform.js?v=<?=time(); ?>"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $("#otp1").keyup(function(){
            var text_lenght = $('#otp1').val().length;
            if (text_lenght == 1) {
                $('#otp2').focus();
            }
        });

        $("#otp2").keyup(function(){
            var text_lenght = $('#otp2').val().length;
            if (text_lenght == 1) {
                $('#otp3').focus();
            }
        });
        $("#otp3").keyup(function(){
            var text_lenght = $('#otp3').val().length;
            if (text_lenght == 1) {
                $('#otp4').focus();
            }
        });
    });
</script>
<script>
    function statea() {
        var country = $('#country').val();
        $.ajax({
            url: '<?=site_url('auth/get_state/');?>'+ country,
            success: function(data) {
                $('#state_id').html(data);
            }
        });
    }

    function check_password() {
        var password = $('#password').val();
        var confirm = $('#confirm').val();
        $.ajax({
            url: '<?=site_url('auth/check_password');?>/'+ password + '/' + confirm,
            success: function(data) {
                $('#password_response').html(data);
            }
        });
    }

    
</script>