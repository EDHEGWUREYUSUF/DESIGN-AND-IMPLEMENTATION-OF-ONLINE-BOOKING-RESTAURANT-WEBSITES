
<?php
use App\Models\Crud;
$this->Crud = new Crud();
?>
<?php echo form_open_multipart($form_link, array('id'=>'bb_ajax_form', 'class'=>'')); ?>
    <!-- delete view -->
    <?php if($param2 == 'delete') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <h3><b>Are you sure?</b></h3>
                <input type="hidden" name="d_food_id" value="<?php if(!empty($d_id)){echo $d_id;} ?>" />
            </div>
            
            <div class="col-sm-12 text-center">
                <button class="btn btn-danger text-uppercase" type="submit">
                    <i class="anticon anticon-trash"></i> Yes - Delete
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- insert/edit view -->
    <?php if($param2 == 'edit' || $param2 == '') { ?>
       
        
        <div class="row">
            <input type="hidden" name="food_id" value="<?php if(!empty($e_id)){echo $e_id;} ?>" />
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Name</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php if(!empty($e_name)){echo $e_name;} ?>" required>
                </div>
            </div>

           
            <?php
                if(!empty($e_menu_id))echo '<input type="hidden" id="e_menu_id" value="'.$e_menu_id.'">';
            ?>
           
            <?php if($role == 'developer' || $role == 'administrator'){?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="activate">Restaurant</label>
                        <select class=" js-select2" id="restaurant_ids" name="restaurant_id" onchange="get_cate();" required>
                            <option value="">Select</option>
                            <?php 
                                $role_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
                                $pro = $this->Crud->read_single_order('role_id', $role_id, 'user', 'business_name', 'asc'); 
                                if(!empty($pro)){
                                    foreach($pro as $prod){?>
                                    <option value="<?=$prod->id; ?>" <?php if(!empty($e_restaurant_id)){if($e_restaurant_id == $prod->id){echo 'selected';}} ?>><?=ucwords($prod->business_name); ?></option>
                            <?php } }?>
                        </select>
                    </div>
                </div>
                
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="activate">Menu</label>
                            <select class="form-select form-control" id="cate_ids" name="menu_id" required>
                               <option value="">Select Restaurant First</option>
                            </select>
                        </div>
                    </div>
                    
                
          
            <?php } else{?>
                <input type="hidden" value="<?=$log_id; ?>" name="restaurant_id">

                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="activate">Menu</label>
                        <select class=" js-select2" id="menu_id" name="menu_id" required>
                            <option value="">Select</option>
                            <?php 
                                if($role == 'kitchen' || $role == 'receptionist'){
                                    $restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
                                }
                                if($role == 'restaurant'){
                                    $restaurant_id = $log_id;
                                }
                                $pro = $this->Crud->read_single_order('restaurant_id', $restaurant_id, 'menu', 'name', 'asc'); 
                                if(!empty($pro)){
                                    foreach($pro as $prod){?>
                                <option value="<?=$prod->id; ?>" <?php if(!empty($e_menu_id)){if($e_menu_id == $prod->id){echo 'selected';}} ?>><?=ucwords($prod->name); ?></option>
                            <?php } }?>
                        </select>
                    </div>
                </div>
            <?php } ?> 
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Price</label>
                    <input type="text" class="form-control" name="price" id="price" oninput="formatDecimalInput(this)" value="<?php if(!empty($e_price)){echo $e_price;} ?>" required>
                </div>
            </div>
            <!-- <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Discount Status</label>
                    <select class="js-select2" id="discount_status" name="discount_status" onchange="discount_stat();" required>
                        <option value="0" <?php if(!empty($e_discount_status)){if($e_discount_status == 1){echo 'selected';}} ?>>No Discount</option>
                        <option value="1" <?php if(!empty($e_discount_status)){if($e_discount_status == 1){echo 'selected';}} ?>> Active</option>
                    </select>
                </div>
            </div>
                  
            <div class="col-sm-6" style="display:none;" id="discount_resp">
                <div class="form-group">
                    <label for="activate">Discount Price</label>
                    <input type="text" class="form-control" name="discount" id="discount" oninput="formatDecimalInput(this)" value="<?php if(!empty($e_discount)){echo $e_discount;} ?>">
                </div>
            </div> -->
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Preparation Time (Mins)</label>
                    <input type="text" class="form-control" name="prepare_time" id="prepare_time" oninput="formatDecimalInput(this)" value="<?php if(!empty($e_prepare_time)){echo $e_prepare_time;} ?>">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Status</label>
                    <select class="js-select2" id="status" name="status" required>
                        <option value="0" <?php if(!empty($e_status)){if($e_status == 0){echo 'selected';}} ?>>Disabled</option>
                        <option value="1" <?php if(!empty($e_status)){if($e_status == 1){echo 'selected';}} ?>>Active</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Description</label>
                    <textarea class="form-control" name="description" required rows="3"><?php if(!empty($e_description)){echo $e_description;} ?></textarea>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group"><b>Food Image</b><br>
                    <label for="img-upload" class="pointer text-center" style="width:100%;">
                        <input type="hidden" name="logo" value="<?php if(!empty($e_logo)){echo $e_logo;} ?>" />
                        <img id="img0" src="<?php if(!empty($e_logo)){echo site_url($e_logo);} ?>" style="max-width:100%;" />
                        <span class="btn btn-danger btn-block no-mrg-btm">Choose Image</span>
                        <input class="d-none" type="file" name="logo" id="img-upload">
                    </label>
                </div>
            </div>       


            <div class="col-sm-12 text-center">
                <button class="btn btn-primary bb_fo_btn" type="submit">
                    <i class="anticon anticon-save"></i> Save Record
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

    <?php } ?>
<?php echo form_close(); ?>
<script>
    // $('.js-select2').select2();
    
    <?php if(!empty($e_menu_id)){?>
        get_cate();
    <?php } ?>
    function get_cate(){
        var restaurant_id = $('#restaurant_ids').val();
        var e_menu_id = $('#e_menu_id').val();
        $.ajax({
            url: site_url + 'kitchen/food/get_menu',
            type: 'post',
            data: { restaurant_id: restaurant_id, menu_id:e_menu_id },
            success: function (data) {
                $('#cate_ids').html(data);
            }
            
        });
    }

    function formatDecimalInput(input) {
        input.value = input.value
            .replace(/[^\d.]/g, '')                 // Remove non-numeric and non-decimal characters
            .replace(/^(\d*\.\d{0,2}|\d*)$/, '$1');  // Allow up to two decimal places
    }
    
    function discount_stat(){
        var status = $('#discount_status').val();

        if(status == 1){
            $('#discount_resp').show(500);
        }

        if(status == 0){
            $('#discount_resp').hide(500);
        }
    }


    function readURL(input, id) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#' + id).attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	$("#img-upload").change(function(){
		readURL(this, 'img0');
	});
	
	$("#img-uploads").change(function(){
		readURL(this, 'img1');
	});


</script>
<script src="<?php echo site_url(); ?>assets/js/jsform.js"></script>