<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('frontend/designs');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>
<!-- app link -->
<section class="main-banner bg-white pt-4">
         <div class="container">
            <div id="carouselExampleFade" class="carousel slide carousel-fade mb-4" data-bs-ride="carousel">
               <div class="carousel-inner rounded">
                  <div class="carousel-item active">
                     <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/banner1.png" class="d-block w-100" alt="..."></a>
                  </div>
                  <div class="carousel-item">
                     <a href="packages.html"><img src="<?=site_url(); ?>assets/frontend/img/banner2.png" class="d-block w-100" alt="..."></a>
                  </div>
               </div>
               <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
               <span class="carousel-control-prev-icon" aria-hidden="true"></span>
               <span class="visually-hidden">Previous</span>
               </button>
               <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
               <span class="carousel-control-next-icon" aria-hidden="true"></span>
               <span class="visually-hidden">Next</span>
               </button>
            </div>
         </div>
      </section>
      <section class="bg-white pt-4">
         <div class="container">
            <div class="align-items-center  mb-2 mt-3" align="center">
               <h3 class="mb-0 fw-bold">How it Works</h3>
            </div>
            <div class="row  row-cols-md-2 row-cols-lg-3 g-6">
               <div class="col-md-4" align="center"><img src="<?=site_url(); ?>assets/frontend/img/location.png" alt="#" class="img-fluid  rounded-4 p-3"><h5 align="center">Set Delivery Location</h5><p>Select the location where you want us to deliver</p></div>
               <div class="col-md-4" align="center"><img src="<?=site_url(); ?>assets/frontend/img/web-page.png" alt="#" class="img-fluid  rounded-4 p-3"><h5 align="center">Choose the Product</h5><p>Browse shops that deliver near you</p></div>
               <div class="col-md-4" align="center"><img src="<?=site_url(); ?>assets/frontend/img/food-delivery.png" alt="#" class="img-fluid  rounded-4 p-3"><h5 align="center">Receive it at your doorstep</h5><p>Your order will be delivered to you in no time</p></div>
               
            </div>
         </div>
      </section>
      <section class="bg-white">
         <div class="container py-5">
            <div class="d-flex align-items-center justify-content-between mb-4">
               <h5 class="mb-0 fw-bold">Waterme Products Categories</h5>
               <a class="text-decoration-none text-success" href="listing.html">View All <i class="bi bi-arrow-right-circle-fill ms-1"></i></a>
            </div>
            <div class="row row-cols-2 row-cols-md-4 row-cols-lg-6 g-4 homepage-products-range">
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/1.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Fresh Milk</h6>
                        <p class="card-text small text-success">128 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/2.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Vegetables</h6>
                        <p class="card-text small text-success">345 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/3.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Fruits</h6>
                        <p class="card-text small text-success">233 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/4.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Bakery & Dairy</h6>
                        <p class="card-text small text-success">4445 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/5.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Beverages</h6>
                        <p class="card-text small text-success">234 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/6.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Breakfast, Snacks</h6>
                        <p class="card-text small text-success">83 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="bg-white">
         <div class="container py-5">
            <div class="d-flex align-items-center justify-content-between mb-4">
               <h5 class="mb-0 fw-bold">WatermePlus Products Categories</h5>
               <a class="text-decoration-none text-success" href="listing.html">View All <i class="bi bi-arrow-right-circle-fill ms-1"></i></a>
            </div>
            <div class="row row-cols-2 row-cols-md-4 row-cols-lg-6 g-4 homepage-products-range mb-5">
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/1.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Fresh Milk</h6>
                        <p class="card-text small text-success">128 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/2.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Vegetables</h6>
                        <p class="card-text small text-success">345 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/3.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Fruits</h6>
                        <p class="card-text small text-success">233 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/4.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Bakery & Dairy</h6>
                        <p class="card-text small text-success">4445 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/5.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Beverages</h6>
                        <p class="card-text small text-success">234 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?=site_url(); ?>assets/frontend/img/6.png" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14">Breakfast, Snacks</h6>
                        <p class="card-text small text-success">83 Items</p>
                     </div>
                     <a href="listing.html" class="stretched-link"></a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="bg-white">
         <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-4">
               <h5 class="mb-0 fw-bold">Trending Vendors</h5>
               <a class="text-decoration-none text-success" href="listing.html">View All <i class="bi bi-arrow-right-circle-fill ms-1"></i></a>
            </div>
            <div class="row g-4">
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider1.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider2.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider3.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider4.jpg" class="img-fluid rounded-3"></a>
               </div>
            </div>
         </div>
      </section>
      <section class="bg-white"><div class="container text-white "><div class="d-flex align-items-center justify-content-between"></div>.</div></section>
      <section class="bg-white">
         <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-4">
               <h5 class="mb-0 fw-bold">Trending Brands</h5>
               <a class="text-decoration-none text-success" href="listing.html">View All <i class="bi bi-arrow-right-circle-fill ms-1"></i></a>
            </div>
            <div class="row g-4">
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider1.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider2.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider3.jpg" class="img-fluid rounded-3"></a>
               </div>
               <div class="col-md-3 col-6">
                  <a href="listing.html"><img src="<?=site_url(); ?>assets/frontend/img/slider4.jpg" class="img-fluid rounded-3"></a>
               </div>
            </div>
         </div>
      </section>
      <section id="app-section" class="bg-white py-5 mobile-app-section">
         <div class="container">
            <div class="bg-light rounded px-4 pt-4 px-md-4 pt-md-4 px-lg-5 pt-lg-5 pb-0">
               <div class="row justify-content-center align-items-center app-2 px-lg-4">
                  <div class="col-md-7 px-lg-5">
                     <div class="text-md-start text-center">
                        <h1 class="fw-bold mb-2 text-dark">Get the Waterme app</h1>
                        <div class="m-0 text-muted">WaterMe App helps you locate your favourite water brand from the nearest vendor & gets it delivered to your doorstep in a reasonable manner.</div>
                     </div>
                     <div class="text-md-start text-center mt-5 mt-md-1 pb-md-4 pb-lg-5">
                        <p class="mb-3">Download app from</p>
                        <a href="#/"><img alt="#" src="<?=site_url(); ?>assets/frontend/img/play-store.svg" class="img-fluid mobile-app-icon"></a>
                        <a href="#/"><img alt="#" src="<?=site_url(); ?>assets/frontend/img/app-store.svg" class="img-fluid mobile-app-icon"></a>
                     </div>
                  </div>
                  <div class="col-md-5 pe-lg-5 mt-3 mt-md-0 mt-lg-0">
                     <img alt="#" src="<?=site_url(); ?>assets/frontend/img/mobile-app.png" class="img-fluid">
                  </div>
               </div>
            </div>
         </div>
      </section>
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo base_url(); ?>/assets/backend/js/jquery.min.js"></script>
<script>
    $(function() {
        load('', '');
    });
   
    function load(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = '/' + x + '/' + y;
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><br/><br/><br/><br/><span class="ni ni-loader fa-spin" style="font-size:38px;"></span></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><span class="ni ni-loader fa-spin"></span></div>');
        }

        var partner = $('#partner').val();
        var search = $('#search').val();
        //alert(status);

        $.ajax({
            url: site_url + 'product/pump/load' + methods,
            type: 'post',
            data: { partner: partner, search: search },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }

                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
                } else {
                    $('#loadmore').html('');
                }
            },
            complete: function () {
                $.getScript(site_url + '/assets/backend/js/jsmodal.js');
            }
        });
    }
</script>   

<?=$this->endSection();?>