<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('frontend/designs');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>
<style>
   
   /* Styles for screens smaller than 600 pixels */
   @media (max-width: 600px) {
   .sliders {
      height: 250px;
   }
   }

   /* Styles for screens between 601 and 900 pixels */
   @media (min-width: 601px) and (max-width: 900px) {
   .sliders {
      height: 400px;
   }
   }

   /* Styles for screens larger than 900 pixels */
   @media (min-width: 901px) {
   .sliders {
      height: 500px;
   }
   }
</style>


<div class="container-fluid my-5">
   <div class="row">
      <div class="col-lg-2">
         
      </div>
      <div class="col-lg-7">
         <div class="fixed-sidebar">
            <div class="bg-white cart-box shadow-sm rounded position-relative mb-3">
               <div class="p-3 border-bottom">
                  <h5 class="mb-0 fw-bold">Your Cart</h5>
                  <p class="small mb-0"><span id="counts"></span> item(s)</p>
               </div> <div id="ucart"></div>
               <div class="py-2" id="load_data">
                  
               </div>
            </div>
            
            <div class="d-grid my-3">
               <a href="javascript:;" id="linkss" class="btn btn-success btn-lg py-3 px-4">
                  <div class="d-flex justify-content-between">
                     <div>Checkout</div>
                     <div class="fw-bold" id="price_resp"></div>
                  </div>
               </a>
               <div id="bb_ajax_msg2"></div>
            </div>
         </div>
      </div>
      <div class="col-lg-2">
         
      </div>
   </div>
</div>

<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
    $(function() {
        load();
    });
   
      function load(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = '/' + x + '/' + y;
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        }

        var partner = $('#partner').val();
        var search = $('#search').val();
        //alert(status);

        $.ajax({
            url: site_url + 'home/cart/load' + methods,
            type: 'post',
            data: { partner: partner, search: search },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }

                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
                } else {
                    $('#loadmore').html('');
                }
               $('#counts').html(dt.count);
               $('#linkss').attr('onClick', dt.linkss);
               $('#price_resp').html(dt.total);
            },
            complete: function () {
                $.getScript(site_url + '/assets/frontend/js/jsmodal.js');
            }
        });
    }
</script>   

<?=$this->endSection();?>