<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('frontend/designs');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>

<section class="bg-white">
   <div class="container">
      <div class="row py-3">
         <div class="col-12">
            <nav>
               <ol class="breadcrumb small mb-0">
                  <li class="breadcrumb-item"><a href="<?=site_url(); ?>" class="text-decoration-none text-success">Home</a></li>
                  <li class="breadcrumb-item"><a href="<?=site_url('home/restaurant'); ?>" class="text-decoration-none text-success">Restaurant</a></li>
               <li class="breadcrumb-item active" aria-current="page"><?=ucwords($business_name); ?></li>
               </ol>
            </nav>
         </div>
      </div>
   </div>
</section>
<main class="sticky-top ">
   <section class="bg-success">
      <div class="container-fluid py-4">
         <div class="row justify-content-between align-items-center">
            <div class="col-md-6">
               <div class="d-flex align-items-center listing-detail-info gap-3">
                  <img src="<?=site_url($business_logo); ?>" class="img-fluid rounded-3" alt="...">
                  <div class="listing-detail-info-body">
                     <h3 class="listing-detail-info-title fw-bold mb-1 text-white"><?=ucwords($business_name); ?></h3>
                     <!-- <p class="mb-3 text-white-50">Cafe, Beverages, Fast Food, Desserts, India</p> -->
                     <!-- <div class="d-flex align-items-center gap-4">
                        <div>
                           <div class="text-uppercase text-warning-light fw-bold fs-14"><i class="bi bi-star-fill"></i> 4.0</div>
                           <p class="text-white-50 small mb-0">1K+ Ratings</p>
                        </div>
                        <div>
                           <div class="text-uppercase text-white fw-bold fs-14">33 mins</div>
                           <p class="text-white-50 small mb-0">Delivery Time</p>
                        </div>
                        <div>
                           <div class="text-uppercase text-warning-light fw-bold fs-14">Open now</div>
                           <p class="text-white-50 small mb-0">Opening</p>
                        </div>
                     </div> -->
                  </div>
               </div>
            </div>
            <div class="col-md-4 d-none d-md-block">
               <!-- <div class="offer-box position-relative bg-white rounded-3 shadow-sm p-4">
                  <small class="offer-box-title fw-bold bg-warning text-white">OFFER</small>
                  <div class="d-flex align-items-center gap-3 mb-3">
                     <i class="bi bi-percent m-0 rounded-pill rounded-icon"></i>
                     <span>
                     <div class="text-uppercase text-success fw-bold">60% off</div>
                     <p class="text-muted small mb-0">Up to ₹120 | Use code MISSEDYOU</p>
                     </span>
                  </div>
                  <div class="d-flex align-items-center gap-3">
                     <i class="bi bi-gift m-0 rounded-pill rounded-icon"></i>
                     <span>
                     <div class="text-uppercase text-success fw-bold">Free Food</div>
                     <p class="text-muted small mb-0">Free Laccha Paratha on orders above Rs 349</p>
                     </span>
                  </div>
               </div> -->
            </div>
         </div>
      </div>
   </section>
</main>

<section class="border-bottom bg-light listing-detail-page py-4">
   <div class="container-fluid">
      <div class="row">
         <div class="col-12 col-md-2">
            <div class="listing-detail-fixed-sidebar">
               <div class="nav flex-column listing-detail-tabs mt-3 pb-4 navbar_resps" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                  
                  
               </div>
            </div>
         </div>
         <div class="col-12 col-md-6">
            <div class="border-start border-end position-relative bg-white">
               <form class="bg-white border-bottom p-2">
                  <div class="input-group border-0 osahan-search-icon rounded">
                     <span class="input-group-text bg-white border-0"><i class="icofont-search"></i></span>
                     <input type="text" class="form-control bg-white border-0 ps-2" placeholder="Search in <?=ucwords($business_name); ?>" oninput="nav_content()" id="searches">
                  </div>
               </form>

               <div class="tab-content restaurant_resp" id="v-pills-tabContent">

                  <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                     <div class="bg-light border-bottom p-3">
                        <h5 class="fw-bold mb-0 text-dark">Recommended</h5>
                     </div>
                     
                     
                  </div>

               </div>
            </div>
         </div>
         <div class="col-12 col-md-4">
            <div class="listing-detail-fixed-sidebar mb-4">
               <div class="bg-white cart-box border rounded position-relative mt-4">
                  <div class="p-3 border-bottom">
                     <h5 class="mb-0 fw-bold">Your Cart</h5>
                  </div>
                  <div class="py-2" id="cart_resp">
                    
                     
                  </div>
               </div>
               <div class="d-grid my-4">
                  
                  <a href="javascript:;" id="btn_cart" class="btn btn-success btn-lg py-3 px-4">
                  
                  <div class="d-flex justify-content-between">
                     <div >Checkout</div>
                     <div id="price_resp" class="fw-bold"><?=curr;?>0</div>
                  </div>
                  </a>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<input type="hidden" name="restaurant_id" id="restaurant_id" value="<?=$param1; ?>">
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
   $(function() {
      navbar_resp();nav_content();cart_load();
   });
   
   function nav_content(x, y) {
      $('#v-pills-tabContent').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');

      var restaurant_id = $('#restaurant_id').val();
      var search = $('#searches').val();
      //alert(status);

      $.ajax({
         url: site_url + 'home/vendor/nav_content',
         type: 'post',
         data: { restaurant_id: restaurant_id },
         success: function (data) {
            var dt = JSON.parse(data);
            $('#v-pills-tabContent').html(dt.item);
         }
      });
   }

   
   
   function navbar_resp() {
        
      $('#v-pills-tab').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        
      var restaurant_id = $('#restaurant_id').val();
      var search = $('#searches').val();
      
      
      $.ajax({
         url: site_url + 'home/vendor/navbar',
         type: 'post',
         data: { restaurant_id: restaurant_id },
         success: function (data) {
            var dt = JSON.parse(data);
            $('#v-pills-tab').html(dt.item);
            $('#counts').html(dt.count);
         }
      });
   }

   function load(id, x, y) {
      var more = 'no';
      var methods = '';
      if (parseInt(x) > 0 && parseInt(y) > 0) {
         more = 'yes';
         methods = '/' + x + '/' + y;
      }
      console.log('re');
      if (more == 'no') {
         $('#content_'+id).html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
      } else {
         $('#content_more_'+id).html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
      }

      var search = $('#searches').val();
      //alert(status);

      $.ajax({
         url: site_url + 'home/vendor/load' + methods,
         type: 'post',
         data: { menu_id: id, search: search },
         success: function (data) {
            var dt = JSON.parse(data);
            if (more == 'no') {
               $('#content_'+id).html(dt.item);
            } else {
               $('#content_'+id).append(dt.item);
            }

            if (dt.offset > 0) {
               $('#content_more_'+id).html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
            } else {
               $('#content_more_'+id).html('');
            }
            $('#counts').html(dt.count);
         },
         complete: function () {
               $.getScript(site_url + '/assets/frontend/js/jsmodal.js');
         }
      });
   }

   function cart_load(){
      $('#cart_resp').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        
      var restaurant_id = $('#restaurant_id').val();
      var search = $('#searches').val();
      
      
      $.ajax({
         url: site_url + 'home/vendor/cart_load',
         type: 'post',
         success: function (data) {
            var dt = JSON.parse(data);
            $('#cart_resp').html(dt.item);
            $('#cart_nos').html(dt.count);
            $('#price_resp').html(dt.total);
            $('#btn_cart').attr('href',dt.link);
         }
      });
   }
</script>   

<?=$this->endSection();?>