<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?php echo $this->extend('designs/backend'); ?>
<?php echo $this->section('title'); ?>
    <?php echo $title; ?>
<?php echo $this->endSection(); ?>

<?php echo $this->section('content'); ?>
<div class="main-content">
    <?php if($role == 'developer' || $role == 'administrator'){?>
        <div class="row">
        <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-blue">
                                <i class="anticon anticon-user"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="customer">0</h2>
                                <p class="m-b-0 text-muted">Customer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-cyan">
                                <i class="anticon anticon-home"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="restaurant">0</h2>
                                <p class="m-b-0 text-muted">Restaurant</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-gold">
                                <i class="anticon anticon-shopping-cart"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="order">0</h2>
                                <p class="m-b-0 text-muted">Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-green">
                                <i class="anticon anticon-user"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="balance">£0</h2>
                                <p class="m-b-0 text-muted">Available Balance</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-blue">
                                <i class="anticon anticon-home"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="credit">£0</h2>
                                <p class="m-b-0 text-muted">Credit</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-red">
                                <i class="anticon anticon-wallet"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="debit">£0</h2>
                                <p class="m-b-0 text-muted">Debit</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-sm-12">
                <ul class="list-group">
                    <div id="load_data"></div>
                </ul>
            </div>
        </div>
    <?php } ?>
    <?php if($role == 'restaurant'){?>
        <div class="row">
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-blue">
                                <i class="anticon anticon-user"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="customer">0</h2>
                                <p class="m-b-0 text-muted">Customer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-cyan">
                                <i class="anticon anticon-home"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="restaurant">0</h2>
                                <p class="m-b-0 text-muted">Restaurant</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-gold">
                                <i class="anticon anticon-shopping-cart"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0" id="order">0</h2>
                                <p class="m-b-0 text-muted">Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    <?php } ?>
</div>
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
    $(function() {
        load();load_activity();
    });
   
      function load(x, y) {
        $('#customer').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading "></i></div>');
        $('#restaurant').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading "></div>');
        $('#order').html('<div class="col-sm-12 text-center"><div class="text-center"><i class="anticon anticon-loading "></div>');
        $('#balance').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading "></i></div>');
        $('#credit').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading "></div>');
        $('#debit').html('<div class="col-sm-12 text-center"><div class="text-center"><i class="anticon anticon-loading "></div>');
       

        $.ajax({
            url: site_url + 'dashboard/index/load',
            type: 'post',
            success: function (data) {
                var dt = JSON.parse(data);
                $('#customer').html(dt.customer);
                $('#restaurant').html(dt.restaurant);
                $('#order').html(dt.order);
                $('#balance').html(dt.balance);
                $('#credit').html(dt.credit);
                $('#debit').html(dt.debit);
               
            }
        });
    }

    function load_activity(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = x + '/' + y + '/';
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><br/><br/><br/><br/><i class="anticon anticon-loading" style="font-size:48px;"></i></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><i class="anticon anticon-loading"></i></div>');
        }

        var type = $('#type').val();
        var search = $('#search').val();
        var start_date = $('#start_date').val();
        var end_date = $('#end_date').val();

        $.ajax({
            url: site_url + 'activity/index/load' + methods,
            type: 'post',
             data: { search: search, start_date: start_date, end_date: end_date },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }

                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-default btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><i class="anticon anticon-reload"></i>Load ' + dt.left + ' More</a>');
                } else {
                    $('#loadmore').html('');
                }
            },
            complete: function () {
                $.getScript(site_url + 'assets/backend/jsmodal.js');
            }
        });
    }
</script>  
<?php echo $this->endSection(); ?>

<?php echo $this->section('footer_top'); ?>

<?php echo $this->endSection(); ?>