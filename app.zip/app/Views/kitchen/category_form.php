
<?php
use App\Models\Crud;
$this->Crud = new Crud();
?>
<?php echo form_open_multipart($form_link, array('id'=>'bb_ajax_form', 'class'=>'')); ?>
    <!-- delete view -->
    <?php if($param2 == 'delete') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <h3><b>Are you sure?</b></h3>
                <input type="hidden" name="d_category_id" value="<?php if(!empty($d_id)){echo $d_id;} ?>" />
            </div>
            
            <div class="col-sm-12 text-center">
                <button class="btn btn-danger text-uppercase" type="submit">
                    <i class="anticon anticon-trash"></i> Yes - Delete
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- insert/edit view -->
    <?php if($param2 == 'edit' || $param2 == '') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        
        <div class="row">
            <input type="hidden" name="cate_id" value="<?php if(!empty($e_id)){echo $e_id;} ?>" />
            
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="activate">Name</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php if(!empty($e_name)){echo $e_name;} ?>" required>
                </div>
            </div>
            <!-- <div class="col-sm-12">
                <div class="form-group">
                    <label for="activate">Main Category</label>
                    <select class=" js-select2" id="category_id" name="category_id" required>
                        <option value="0">None</option>
                        <?php $pro = $this->Crud->read_single_order('category_id',0, 'category', 'name', 'asc'); 
                            if(!empty($pro)){
                                foreach($pro as $prod){?>
                            <option value="<?=$prod->id; ?>" <?php if(!empty($e_category_id)){if($e_category_id == $prod->id){echo 'selected';}} ?>><?=ucwords($prod->name); ?></option>
                        <?php } }?>
                    </select>
                </div>
            </div> -->
            <?php if($role == 'developer' || $role == 'administrator'){?>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="activate">Restaurant</label>
                        <select class=" js-select2" id="restaurant_id" name="restaurant_id" required>
                            <?php 
                                $role_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
                                $pro = $this->Crud->read_single_order('role_id', $role_id, 'user', 'business_name', 'asc'); 
                                if(!empty($pro)){
                                    foreach($pro as $prod){?>
                                    <option value="<?=$prod->id; ?>" <?php if(!empty($e_restaurant_id)){if($e_restaurant_id == $prod->id){echo 'selected';}} ?>><?=ucwords($prod->business_name); ?></option>
                            <?php } }?>
                        </select>
                    </div>
                </div>

            <?php } else{?>
                <input type="hidden" value="<?=$log_id; ?>" name="restaurant_id">
            <?php } ?>
            

            <div class="col-sm-12 text-center">
                <button class="btn btn-primary bb_fo_btn" type="submit">
                    <i class="anticon anticon-save"></i> Save Record
                </button>
            </div>
        </div>
    <?php } ?>
<?php echo form_close(); ?>
<script>
    $('.js-select2').select2();
   
   

</script>
<script src="<?php echo site_url(); ?>assets/js/jsform.js"></script>