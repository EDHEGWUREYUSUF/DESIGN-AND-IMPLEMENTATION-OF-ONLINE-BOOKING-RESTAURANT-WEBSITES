<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
    
?>

<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="icon" type="image/png" href="<?=site_url(); ?>assets/frontend/img/fav.png">
      <title><?=$title; ?></title>
      <!-- Bootstrap core CSS -->
      <link href="<?=site_url(); ?>assets/frontend/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Icofont Icon-->
      
      <link href="https://fonts.googleapis.com/css?family=Afacad:300,400,500,600,700&amp;amp;subset=latin-ext" rel="stylesheet">
      <link href="<?=site_url(); ?>assets/frontend/vendor/icons/icofont.min.css" rel="stylesheet" type="text/css">
      <!-- Bootstraps icon -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link href="<?=site_url(); ?>assets/frontend/css/style.css" rel="stylesheet">
   </head>
   <body class="bg-light">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm osahan-header py-0">
         <div class="container-fluid">
            <a class="navbar-brand me-0 me-lg-3 me-md-3" href="<?=site_url(); ?>">
               <img src="<?=site_url(); ?>assets/frontend/img/logo.svg" alt="#" class="img-fluid d-none d-md-block">
               <img src="<?=site_url(); ?>assets/frontend/img/logo.svg" alt="#" class="d-block d-md-none d-lg-none img-fluid">
            </a>
            <a href="javascript:;" class="ms-2 text-left d-flex text-dark align-items-center gap-2 text-decoration-none bg-white border-0 me-auto" data-bs-toggle="modal" data-bs-target="#ad-delivery-location">
               <i class="bi bi-user fs-5 text-success"></i> 
               <span>
                  <b>Welcome</b>
                  <div class="fs-6 text-success" id="head_change">
                     <?php 
                        if(!empty($log_id)){
                           echo $this->Crud->read_field('id', $log_id, 'user', 'fullname');
                        } else {
                           echo 'Guest';
                        }
                     ?></div>
               </span>
            </a>
            <div id="cart_data" class="mx-3 d-flex align-items-center mb-5  mobile-nav-bottom position-fixed gap-1 align-items-right"></div>
            <button class="navbar-toggler d-none d-lg-none d-md-block" type="button" data-bs-toggle="collapse"
               data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
               aria-label="Toggle navigation" >
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <?php if(!empty($log_id)){?>
                  <ul class="navbar-nav ms-auto me-3 top-link">
                     <li class="nav-item dropdown">
                        <a class="nav-link" href="javascript;;" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Profile<i class="bi bi-chevron-down small ms-1"></i>
                        </a>
                        <ul class="dropdown-menu">
                           <li><a class="dropdown-item"  href="<?=site_url('home/profile'); ?>">Orders List</a></li>
                           <!-- <li><a class="dropdown-item"  href="<?=site_url('home/profile'); ?>">Wallet</a></li> -->
                           <li><a class="dropdown-item"  href="<?=site_url('home/profile'); ?>">My Profile</a></li>
                           <li><a class="dropdown-item"  href="<?=site_url('logout'); ?>">Logout</a></li>
                        </ul>
                     </li>
                     <?php if($role != 'Customer'){?>
                     <li class="nav-item">
                        <a class="nav-link" href="<?=site_url('dashboard'); ?>" role="button" aria-expanded="false">
                        Admin Dashboard
                        </a>
                     </li>
                     <?php }?>
                  </ul>
               <?php  } else{?>
                  <ul class="navbar-nav ms-auto me-3 top-link">
                     <li class="nav-item dropdown">
                        <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Account<i class="bi bi-chevron-down small ms-1"></i>
                        </a>
                        <ul class="dropdown-menu">
                           <li><a class="dropdown-item pop" href="javascript:;" pageTitle="Sign In" pageName="<?php echo site_url('auth/frontend/login'); ?>">Login</a></li>
                           <li><a class="dropdown-item pop" href="javascript:;" pageTitle="Sign In" pageName="<?php echo site_url('auth/frontend/register'); ?>">Sign Up</a></li>
                        </ul>
                     </li>
                  </ul>

               <?php } ?>
               
               <div class="d-flex align-items-center gap-2">
                  
                  <?php if(!empty($log_id)){?>
                  <a  href="<?=site_url('home/cart');?>" class="btn btn-i position-relative rounded-pill rounded-icon" style="color:#1b2a53 !important;">
                     <i class="bi bi-cart"></i>
                  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary" id="cart_nos"><?php 
                     if(!empty($log_id)) echo $this->Crud->check2('user_id', $log_id, 'new', '0', 'cart'); else echo 0;
                  ?>
                  <span class="visually-hidden">Cart</span>
                  </span>
                  </a><?php } ?>
                  <?php if(empty($log_id)){?>
                     <a class="btn rounded-pill btn-success px-3 pop text-white text-uppercase ms-2" href="javascript:;" pageTitle="Sign In" pageName="<?php echo site_url('auth/frontend/login'); ?>" role="button">Sign in</a>
                  <?php } ?>
                  
               </div><br>
            </div>
         </div>
      </nav>
                
        <?=$this->renderSection('content');?>
                
                <!-- Footer -->
      <footer class="bg-footer py-5 d-none d-md-block">
         <div class="container-fluid">
           
            <div class="row text-white">
               <div class="col-md-8 col-12">
                  <div><img src="<?=site_url(); ?>assets/frontend/img/fav.png" alt="" class="img-fluid footer-logo"></div>
               </div>
               <div class="col-md-4 col-6">
                  <h6 class="text-uppercase fw-bold">My Profile</h6>
                  <ul class="list-unstyled d-grid gap-2">
                     <li><a class="text-decoration-none text-white-50" href="<?=site_url();?>">Orders List</a></li>
                     <li><a class="text-decoration-none text-white-50" href="<?=site_url();?>">Manage Payments</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </footer>
      <!-- Sign in Modal -->
      <!-- 1st -->
      <div class="modal modal-center fade" id="theModal"  data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
         <div class="modal-dialog  modal-dialog-centered login-popup-main">
            <div class="modal-content border-0 shadow overflow-hidden rounded">
               <div class="modal-body p-0">
                  <div class="login-popup">
                     <button type="button" class="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close"></button>
                     <div class="row g-0">
                        <div class="d-none d-md-flex col-md-4 col-lg-4 bg-image1"></div>
                        <div class="col-md-8 col-lg-8 py-lg-5">
                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- location Modal -->
    
     <div class="w-100 d-block d-md-none d-lg-none mobile-nav-bottom position-fixed d-flex align-items-center justify-content-around shadow-sm">
         <a href="<?=site_url('main'); ?>"><span class="bi bi-card-heading"></span> Home</a>
         <a href="<?=site_url('home/cart'); ?>">
            <span class="bi bi-basket-fill"></span> Cart <b id="cart_no2"><?php if(empty($log_id)){echo 0;} else {
               echo $this->Crud->check2('user_id', $log_id, 'new', '1', 'cart');}
            ?></b>
         </a>
         <a href="javascript:;"><span class="bi bi-search"></span> Search</a>
         <?php if(empty($log_id)){?><a class="btn rounded-pill px-3 pop text-white text-uppercase ms-2" href="javascript:;" pageTitle="Sign In" pageName="<?php echo site_url('home/auth/login'); ?>" role="button"><span class="bi bi-unlock-fill"></span> Sign In</a>
         <?php } else{ 
            $role = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            if($role != 4){
            ?>
         <a href="<?=site_url('dashboard'); ?>"><span class="bi bi-activity"></span> Dashboard</a>
         <?php } ?>
         <a href="<?=site_url('home/profile'); ?>"><span class="bi bi-person-badge"></span> Account</a>
         <a href="<?=site_url('auth/logout'); ?>"><span class="bi bi-lock-fill"></span> Logout</a>
         <?php } ?>
      </div>
      <script>
         $(function() {
            cart_load();
         });
         function add_cart(food_id){
            $('#cart_resp'+food_id).html('Processing...');
            $.ajax({
               url: '<?=site_url('home/vendor/cart_add/'); ?>' + food_id,
               type: 'post',
               success: function(data) {
                  
                  $('#cart_resp'+food_id).html(data);
                  setTimeout(function() {
                     $('#cart_resp'+food_id).html('');
                  }, 5000);
                  cart_load();
               }
            });
         }
         function up_cart(id){
            $('#ucart_'+id).html('Processing...');
            var qty = $('#qty_'+id).val();
            // console.log(qty);
            $.ajax({
               url: '<?=site_url('home/cart/cart_up/'); ?>' + id,
               type: 'post',
               data: {qty:qty},
               success: function(data) {
                  
                  $('#ucart_'+id).html(data);
                  setTimeout(function() {
                     $('#ucart_'+id).html('');
                  }, 5000);
                  $('#ucart').html(data);
                  setTimeout(function() {
                     $('#ucart').html('');
                  }, 5000);
                  cart_load();
               }
            });
         }

         function cart_del(id){
            $('#ucart_'+id).html('Processing...');
            // console.log(qty);
            $.ajax({
               url: '<?=site_url('home/cart/cart_del/'); ?>' + id,
               type: 'post',
               success: function(data) {
                  cart_load();load();
                  $('#ucart_'+id).html(data);
                  setTimeout(function() {
                     $('#ucart_'+id).html('');
                  }, 3000);
                  $('#load_data').html(data);
                  setTimeout(function() {
                     $('#load_data').html('');
                  }, 3000);
                  
               }
            });
         }
         function cart_load(){
            $('#cart_resp').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
            
            var restaurant_id = $('#restaurant_id').val();
            var search = $('#searches').val();
            
            
            $.ajax({
               url: site_url + 'home/vendor/cart_load',
               type: 'post',
               success: function (data) {
                  var dt = JSON.parse(data);
                  $('#cart_resp').html(dt.item);
                  $('#cart_nos').html(dt.count);
                  $('#price_resp').html(dt.total);
                  $('#btn_cart').attr('href',dt.link);
               }
            });
         }
      </script>
      <!-- Bootstrap core JavaScript -->
      <script src="<?=site_url(); ?>assets/frontend/vendor/jquery/jquery.min.js"></script>
      <script src="<?=site_url(); ?>assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="<?=site_url(); ?>assets/frontend/js/custom.js?t=<?=time(); ?>"></script>
      <script src="<?php echo site_url(); ?>assets/frontend/js/jsmodal.js"></script>
      
      <script src="<?php echo site_url(); ?>assets/frontend/js/jsform.js"></script>
      <script src="<?php echo site_url(); ?>assets/frontend/js/jquery.min.js"></script>
      <script>
       
      </script>
   </body>
</html>