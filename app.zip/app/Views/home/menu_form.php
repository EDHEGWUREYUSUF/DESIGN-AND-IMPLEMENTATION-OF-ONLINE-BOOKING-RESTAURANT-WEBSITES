<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>
<?php if($param1 == 'dish_view'){
    $food_id = $this->Crud->read_field('name', str_replace('_',' ', $param2), 'food', 'id');
    $food = $this->Crud->read_field('id', $food_id, 'food', 'name');
    $img = $this->Crud->read_field('id', $food_id, 'food', 'image');
    $menu_id = $this->Crud->read_field('id', $food_id, 'food', 'menu_id');
    $prepare_status = $this->Crud->read_field('id', $food_id, 'food', 'prepare_status');
    $prepare_time = $this->Crud->read_field('id', $food_id, 'food', 'prepare_time');
    $restaurant_id = $this->Crud->read_field('id', $food_id, 'food', 'restaurant_id');
    $menu = $this->Crud->read_field('id', $menu_id, 'menu', 'name');
    $price = $this->Crud->read_field('id', $food_id, 'food', 'price');
    $description = $this->Crud->read_field('id', $food_id, 'food', 'description');
    $preparation_time = $this->Crud->read_field('id', $food_id, 'food', 'prepare_time');
    $restaurant = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
    
    $prepare = '';
    if($prepare_status > 0){
        $prepare = '<div class="h6 mb-2 text-dark">'.$prepare_time.' Mins</div>';
    }
    if(empty($img) || !file_exists($img)){
        $img = 'assets/img/gallery.png';
    }
    ?>
    <div class="login-popup">
        <div class="row">
            <div class="col-6 text-start p-5 pb-0">
                <h6>View <?=$food; ?> Dish</h6>
            </div>
            <div class="col-6 text-end p-5 pb-0">
                <button type="button" class="btn-close position-absolut" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        </div>
        <hr>
        <div class="row g-0 m-3">
            <div class="col-md-4 mt-2">
                <div class="fixed-sideba">
                    <div id="carouselExampleControls" class="carousel slide shadow-sm rounded overflow-hidden" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="<?=site_url($img); ?>" style="height:150px" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <?php if(!empty($log_id)){?>
                        <div class="d-grid my-3">
                            <a href="javascript:;" onclick="add_cart(<?=$food_id; ?>)"  class="btn btn-warning text-center text-uppercase py-3 px-4">
                            Add to Cart
                            </a>
                            <span id="cart_resp<?=$food_id;?>"></span>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <div class="col-md-7 mx-4 mt-2">
                <div class="bg-white shadow-sm rounded position-relative p-4">
                    <a class="text-success text-decoration-none" href="<?=site_url('home/vendor/'.str_replace(' ', '_', $restaurant)); ?>"><i class="bi bi-shop"></i> <?=ucwords($restaurant); ?></a>
                    <div class="h5 fw-bold mt-1 mb-3"><?=ucwords($restaurant); ?> <?=$food; ?></div>
                    <div class="d-flex align-items-center py-1">
                        <div>
                            <div class="h6 mb-2 text-dark">Price: <?=curr.number_format($price,2); ?></div>
                            <?=$prepare; ?>
                        </div>
                    </div>
                
                    <div class="row">
                        <div class="col-12">
                            <div class="border-top pt-3 mt-3">
                                <h6>Dish Information</h6>
                                <p class="text-muted mb-0"><?=ucwords($description); ?></p>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="border-top pt-3 mt-3">
                                <h6>Ready Time</h6>
                                <p class="text-muted mb-0"><?=($preparation_time); ?> mins</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<script src="<?php echo site_url(); ?>assets/frontend/js/jsform.js?v=<?=time(); ?>"></script>