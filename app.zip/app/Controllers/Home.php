<?php

namespace App\Controllers;

class Home extends BaseController {
    public function index($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['title'] = 'Welcome - '.app_name;
        $data['page_active'] = $mod;
        return view('home/land', $data);
    }

    public function menu($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        $data['param1'] = $param1;
        $data['param2'] = $param2;
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('menu'))) { $menu = $this->request->getPost('menu'); } else { $menu = ''; }
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

			$items = '
				
				
			';
           
            $menu = $this->Crud->read_field('name', str_replace('_', ' ',$menu), 'menu','id');
            $all_rec = $this->Crud->filter_foods('', '', $log_id, $menu, $search);
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $query = $this->Crud->filter_foods($limit, $offset, $log_id, $menu, $search);
            $data['count'] = $counts;
            if(!empty($query)) {
                foreach($query as $q) {
                    $id = $q->id;
                    $menu = $this->Crud->read_field('id', $q->menu_id, 'menu', 'name');
                    $price = $q->price;
                    $name = $q->name;
                    $description = $q->description;
                    $restaurant = $this->Crud->read_field('id', $q->restaurant_id, 'user', 'business_name');
                    $img = $q->image;
                    $reg_date = date('M d, Y', strtotime($q->reg_date));
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/gallery.png';
                     }

                    $item .= '
                        <div class="col">
                            <div class="bg-white listing-card shadow-sm rounded-2 p-3 position-relative">
                                <img src="'.site_url($img).'" style="height:180px !important;" class="img-fluid rounded-1" alt="...">
                                <div class="listing-card-body pt-3">
                                    <h6 class="card-title fw-bold mb-1">'.ucwords($name).'</h6>
                                    <p class="card-text text-muted mb-2"><b>Restaurant:</b> '.ucwords($restaurant).'</p>
                                    <p class="card-text text-dark mb-2"><b>Menu:</b>'.ucwords($menu).'</p>
                                    <p class="card-text text-primary fw-bold">'.curr.number_format($price,2).'</p>
                                    <button class="btn btn-success btn-block" id="add_cart">Add to Cart</button>
                                </div>
                                <a href="javascript:;" pageName="'.site_url('home/menu/dish_view/'.strtolower(str_replace(' ', '_', $name))).'" pageTitle="View Dish" pageSize="modal-lg" class="stretched-link pop"></a>
                            </div>
                            <span id="cart_resp_'.$id.'"></span>
                        </div>
                    ';
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                    <i class="bi bi-cup" style="font-size:150px;"></i><br/><br/>No Dish Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}
        $data['title'] = 'Menu - '.app_name;
        if(!empty($param1)){
            $data['title'] = ucwords(str_replace('_',' ', $param1)).' Menu - '.app_name;
        }
        if($param1 == 'dish_view'){
            return view('home/menu_form', $data);
 
        } else{
            $data['page_active'] = $mod;
            return view('home/menu', $data);
        }
    }

    public function vendor($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        $data['param1'] = $param1;
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;

        // record listing
		if($param1 == 'navbar') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
            $search = $this->request->getPost('search');
            $restaurant_id = $this->request->getPost('restaurant_id');


            $restaurant = $this->Crud->read_field('business_name', str_replace('_', ' ',$restaurant_id), 'user','id');
            $all_rec = $this->Crud->read_single_order('restaurant_id', $restaurant, 'menu', 'name', 'asc', '', '');
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $query = $this->Crud->read_single_order( 'restaurant_id', $restaurant, 'menu', 'name', 'asc', $limit, $offset);
            $data['count'] = $counts;
            

            if(!empty($query)) {
                $a=0;
                foreach($query as $q) {
                    $id = $q->id;
                    $name = $q->name;
                    $img = $q->image;
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/gallery.png';
                    }

                    $active = '';
                    if($a==0)$active = 'active';
                    $item .= '
                        <button class="nav-link '.$active.'" id="v-pills-'.$id.'-tab" data-bs-toggle="pill" data-bs-target="#v-pills-'.$id.'" type="button" role="tab"  aria-controls="v-pills-'.$id.'" aria-selected="true">'.ucwords($name).'</button>
                    ';
                    $a++;
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = '
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                <i class="bi bi-cup-hot" style="font-size:150px;"></i><br/><br/>No Menu Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'nav_content') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
            $search = $this->request->getPost('search');
            $restaurant_id = $this->request->getPost('restaurant_id');


            $restaurant = $this->Crud->read_field('business_name', str_replace('_', ' ',$restaurant_id), 'user','id');
            $all_rec = $this->Crud->read_single_order('restaurant_id', $restaurant, 'menu', 'name', 'asc', '', '');
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $query = $this->Crud->read_single_order( 'restaurant_id', $restaurant, 'menu', 'name', 'asc', $limit, $offset);
            $data['count'] = $counts;
            

            if(!empty($query)) {
                $a=0;
                foreach($query as $q) {
                    $id = $q->id;
                    $name = $q->name;
                    $img = $q->image;
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/gallery.png';
                    }

                    $metric = $this->Crud->check2('status', 1, 'menu_id', $id, 'food');
                    $active = '';
                    if($a==0)$active = 'active show';
                    $item .= '
                        
                        <div class="tab-pane fade '.$active.'" id="v-pills-'.$id.'" role="tabpanel" aria-labelledby="v-pills-'.$id.'-tab">
                            <div class="bg-light border-bottom p-3">
                                <h5 class="fw-bold mb-0 text-dark">'.ucwords($name).'</h5>
                            </div>
                            
                            <div id="content_'.$id.'"></div>
                            <div id="content_more_'.$id.'"></div>
                            
                        </div>
                        <script>load('.$id.');</script>
                    ';
                    $a++;
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = '
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                <i class="bi bi-cup-hot" style="font-size:150px;"></i><br/><br/>No Menu Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'cart_add'){
            if(!empty($param2)){
                $log_id = $this->session->get('ra_id');
                if(empty($log_id)) {
                    
                    echo $this->Crud->msg('warning', 'Please Login First');
                } else {
                    $food_id = $param2;
                    $price = $this->Crud->read_field('id', $food_id, 'food', 'price');
                    $qty = 1;

                    if($this->Crud->check3('user_id', $log_id, 'food_id', $food_id, 'new', 1, 'cart') > 0){
                        echo $this->Crud->msg('warning', 'Already in Cart');
                    } else{

                        $in_data['user_id'] = $log_id;
                        $in_data['food_id'] = $food_id;
                        $in_data['qty'] = $qty;
                        $in_data['price'] = $price;
                        $in_data['sub_total'] = $price;
                        $in_data['reg_date'] = date('Y-m-d H:i:s');
                        $in_data['updated_at'] = date('Y-m-d H:i:s');
                        $in_data['new'] = 1;

                        $ins = $this->Crud->create('cart', $in_data);
                        if($ins > 0){
                            echo $this->Crud->msg('success','Added to Cart');
                        } else {
                            echo $this->Crud->msg('danger','Error Adding to Cart');
                        }
                    }
                }
                die;
            }
        }

        if($param1 == 'cart_load'){
            
            $pay_script = '';
            $total = 0;$links ='';$link='';
            if(empty($log_id)){
                $item = '<span class="text-danger">Please Login First</span>';
                $count = 0;
                $total = 0;
            } else {
                $query = $this->Crud->read2('user_id', $log_id, 'new', '1', 'cart');
                $item = '';
                $count = count($query);
                if(!empty($query)) {
                    $a=0;
                    $link = site_url('home/cart');

                    foreach($query as $q) {
                        $id = $q->id;
                        $user_id = $q->user_id;
                        $qty = $q->qty;
                        $price = $q->price;
                        $sub_total = $q->sub_total;
                        $food_id = $q->food_id;
                        $food = $this->Crud->read_field('id', $food_id, 'food', 'name');
                        $active = '';
                        if($a==0)$active = 'active show';
    
                        $item .= '
                            <div class="cart-box-item d-flex align-items-center py-2 px-3">
                                <div class="success-dot"></div>
                                <div class="cart-box-item-title px-2">
                                    <p class="mb-0">'.ucwords($food).'</p>
                                    <a href="javascript:;"  onclick="cart_del('.$id.')" class="small text-danger text-none-decoration mb-0">Remove</a>
                                </div>
                                <div class="d-flex align-items-center justify-content-between rounded-pill border cart-quantity px-1 ms-auto">
                                    
                                    <input class="form-control text-center border-0 py-0 box" id="qty_'.$id.'" type="number"placeholder aria-label="default input example" min="1" value="'.$qty.'" onchange="up_cart('.$id.')"/>
                                  
                                </div>
                                <div class="cart-box-item-price">
                                    <div class="text-end">'.curr.number_format($sub_total,2).'</div>
                                </div>
                            </div>
                            <div id="ucart_'.$id.'"></div>
                        ';
                        
                        $a++;
                        $total += (float)$sub_total;
                    }
                }

                if($total > 0){
                    $ref = 'RA-'.time().rand(0,9).rand(1,9);

					$redir = site_url('home/cart/make_payment');

					$user = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
					$phone = $this->Crud->read_field('id', $log_id, 'user', 'phone');
					$email = $this->Crud->read_field('id', $log_id, 'user', 'email');
					$this->session->set('f_amount', $total);
					
					
                    $user = ucwords($user);

                    $customer['name'] = ucwords($user);
                    $customer['email'] = $email;
                    $customer['phone_number'] = $phone;
    
    
                    $customize['title'] = 'Eatsie Order Payment';
                    $customize['description'] = 'Payment by ' . $user;
                    $customize['logo'] = site_url('assets/frontend/img/fav.png');
    
                    $meta['user_id'] = $user_id;
    
                    $pay_script = $this->Crud->rave_inline($ref, $redir, $customize, $total, $customer, $meta);
                    // echo $pay_script;
                    // echo $pay_script;
                        $links = 'ravePay()';
                }

                if(empty($item)) {
                    $link = 'javascript:;';
                    $item .= '
                        <div class="col-12">
                            <div class="col-12">
                                <div class="text-center text-muted">
                                    <i class="bi bi-basket-fill" style="font-size:150px;"></i><br/><br/>No Dish Returned
                                </div>
                            </div>
                        </div>
                    ';
                } 

            }
           
            $resp['link'] = $link;
            $resp['links'] = $links;
            $resp['item'] = $item . $pay_script;
            $resp['count'] = $count;
            $resp['total'] = curr.number_format($total,2);
            echo json_encode($resp);
            die;
        }

        if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
            $search = $this->request->getPost('search');
            $menu_id = $this->request->getPost('menu_id');


            $all_rec = $this->Crud->filter_mfood($menu_id,  $search, '', '');
            $query = $this->Crud->filter_mfood($menu_id, $search,  $limit, $offset);
           
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $data['count'] = $counts;
            
            $item .= '<h6 class="small text-success mb-0 p-3">'.$counts.' DISHES</h6>';

            if(!empty($query)) {
                $a=0;
                foreach($query as $q) {
                    $id = $q->id;
                    $name = $q->name;
                    $price = $q->price;
                    $img = $q->image;
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/gallery.png';
                    }
                    $menu = $this->Crud->read_field('id', $q->menu_id, 'menu', 'name');

                    $active = '';
                    if($a==0)$active = 'active show';

                    $item .= '
                        
                        <div class="product-list d-flex p-3 border-bottom">
                            <img src="'.site_url($img).'" class="img-fluid" alt="...">
                            <div class="product-list-body px-3">
                                <p class="fw-bold mb-1">'.ucwords($name).'</p>
                                <p class="card-text small text-muted mb-2">'.ucwords($menu).'</p>
                                <h6 class="fw-bold">'.curr.number_format($price,2).'</h6>
                            </div>
                            <div class="ms-auto mb-auto">
                                <button type="button" onclick="add_cart('.$id.')" class="btn btn-outline-success btn-sm rounded-pill"><span><i class="bi bi-plus-lg"></i></span>&nbsp;ADD</button><br>
                                <span id="cart_resp'.$id.'"></span>
                            </div>
                        </div>
                       
                        
                    ';
                    $a++;
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = '
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                <i class="bi bi-basket-fill" style="font-size:150px;"></i><br/><br/>No Dish Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        $restaurant_id = $this->Crud->read_field('business_name', str_replace('_',' ', $param1), 'user', 'id');
        $restaurant_logo = $this->Crud->read_field('id', $restaurant_id, 'user', 'logo');
        $data['business_name'] = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
        if(empty($restaurant_logo) || !file_exists($restaurant_logo)) {
            $restaurant_logo = 'assets/img/restaurant.png';
        }
        $data['business_logo'] = $restaurant_logo;
        $data['title'] = 'Restaurant - '.app_name;
        if(!empty($param1)){
            $data['title'] = ucwords(str_replace('_',' ', $param1)).'`s Restaurant - '.app_name;
        }
        $data['page_active'] = $mod;
        return view('home/vendor', $data);
    }

    public function cart($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        $data['param1'] = $param1;
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;

        if($param1 == 'make_payment'){
			/////// CHACK PAYMENT RESPONSE //////
			$ref = $this->request->getGet('tx_ref');
			$trans = $this->request->getGet('transaction_id');
			$status = $this->request->getGet('status');
            
            
			if($ref && $trans && $status) {
				if($status == 'successful') {
					$user_id = $this->session->get('ra_wallet_id');
					$amount = $this->session->get('f_amount');
                    // echo $user_id;
					if(!empty($user_id) && !empty($amount)){
                        $v_ins['user_id'] = $user_id;
                        $v_ins['amount'] = $amount;
                        $v_ins['reference'] = $ref;
                        $v_ins['reg_date'] = date(fdate);
                        $v_id = $this->Crud->create('transaction', $v_ins);


                        $wa_id = $this->Crud->order_payment($amount, $user_id);
                        // echo $wa_id;
						if($wa_id > 0) {
							echo $this->Crud->msg('success', 'Order Placed');
							$this->session->set('f_amount', '');
							$this->session->set('ra_wallet_id', '');
							///// store activities
							$by = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
							$action = $by.' Placed an Order';
							$this->Crud->activity('wallet', $wa_id, $action);
							$redir = 'home/profile';
							echo '<script>window.location.replace("'.site_url($redir).'");</script>';
						} else {
							echo $this->Crud->msg('danger', 'Failed! - Please Contact Support.');
							
						}
					}
				}
			}

			////////////////////////////////////
			die;
		}

        
        if($param1 == 'cart_up'){
            if(!empty($param2)){
                $log_id = $this->session->get('ra_id');
                if(empty($log_id)) {
                    
                    echo $this->Crud->msg('warning', 'Please Login First');
                } else {
                    $cart_id = $param2;
                    $food_id = $this->Crud->read_field('id', $cart_id, 'cart', 'food_id');
                    $price = $this->Crud->read_field('id', $food_id, 'food', 'price');
                    $qty = $this->request->getPost('qty');



                    $in_data['qty'] = $qty;
                    $in_data['sub_total'] = (float)$price * (int)$qty;
                    $in_data['updated_at'] = date('Y-m-d H:i:s');

                    $ins = $this->Crud->updates('id', $cart_id, 'cart', $in_data);
                    if($ins > 0){
                        echo $this->Crud->msg('success','Cart Updated');
                    } else {
                        echo $this->Crud->msg('danger','Error Updating Cart');
                    }
            
                }
                die;
            }
        }

        if($param1 == 'cart_del'){
            if(!empty($param2)){
                $log_id = $this->session->get('ra_id');
                if(empty($log_id)) {
                    
                    echo $this->Crud->msg('warning', 'Please Login First');
                } else {
                    $cart_id = $param2;
                   
                    $ins = $this->Crud->deletes('id', $cart_id, 'cart');
                    if($ins > 0){
                        echo $this->Crud->msg('success','Item Deleted');
                    } else {
                        echo $this->Crud->msg('danger','Error Deleting Cart');
                    }
            
                }
                die;
            }
        }

        if($param1 == 'load'){
            $link = '';$links='';
            if(empty($log_id)){
                $item = '<span class="text-danger">Please Login First</span>';
                $count = 0;
                $total = 0;
            } else {
                $query = $this->Crud->read2('user_id', $log_id, 'new', '1', 'cart');
                $item = '';
                $count = count($query);
                $total = 0;
                if(!empty($query)) {
                    $a=0;
                    foreach($query as $q) {
                        $id = $q->id;
                        $user_id = $q->user_id;
                        $qty = $q->qty;
                        $price = $q->price;
                        $sub_total = $q->sub_total;
                        $food_id = $q->food_id;
                        $food = $this->Crud->read_field('id', $food_id, 'food', 'name');
                        $active = '';
                        if($a==0)$active = 'active show';
    
                        $item .= '
                            <div class="cart-box-item d-flex align-items-center py-2 px-3">
                                <div class="success-dot"></div>
                                <div class="cart-box-item-title px-2">
                                    <p class="mb-0">'.ucwords($food).'</p>
                                    <a href="javascript:;"  onclick="cart_del('.$id.')" class="small text-danger text-none-decoration mb-0">Remove</a>
                                </div>
                                <div class="d-flex align-items-center justify-content-between rounded-pill border cart-quantity px-1 ms-auto">
                                    
                                    <input class="form-control text-center border-0 py-0 box" id="qty_'.$id.'" type="number"placeholder aria-label="default input example" min="1" value="'.$qty.'" onchange="up_cart('.$id.')"/>
                                
                                </div>
                                <div class="cart-box-item-price">
                                    <div class="text-end">'.curr.number_format($price,2).'</div>
                                </div>
                            </div>
                           
                        ';
                        $a++;
                        $total += (float)$sub_total;
                    }
                }
                if(empty($item)) {
                    $link = 'javascript:;';
                    $item .= '
                        <div class="col-12">
                            <div class="col-12">
                                <div class="text-center text-muted">
                                    <i class="bi bi-basket-fill" style="font-size:150px;"></i><br/><br/>No Dish Returned
                                </div>
                            </div>
                        </div>
                    ';
                } 
            }

            $pay_script = '';
            if($total > 0){
                $ref = 'RA-'.time().rand(0,9).rand(1,9);
                $this->session->set('ra_wallet_id', $log_id);
                $redir = site_url('home/cart/make_payment');

                $user = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
                $phone = $this->Crud->read_field('id', $log_id, 'user', 'phone');
                $email = $this->Crud->read_field('id', $log_id, 'user', 'email');
                $this->session->set('f_amount', $total);
                
               
                $user = ucwords($user);

                $customer['name'] = ucwords($user);
                $customer['email'] = $email;
                $customer['phone_number'] = $phone;


                $customize['title'] = 'Eatsie Order Payment';
                $customize['description'] = 'Payment by ' . $user;
                $customize['logo'] = site_url('assets/frontend/img/fav.png');

                $meta['user_id'] = $user_id;

                $pay_script = $this->Crud->rave_inline($ref, $redir, $customize, $total, $customer, $meta);
                // echo $pay_script;
                // echo $pay_script;
				$links = 'ravePay()';
            }

           
            $resp['link'] = $link;
            $resp['linkss'] = $links;
            $resp['item'] = $item . $pay_script;
            $resp['count'] = $count;
            $resp['total'] = curr.number_format($total,2);
            echo json_encode($resp);
            die;
        }

        $restaurant_id = $this->Crud->read_field('business_name', str_replace('_',' ', $param1), 'user', 'id');
        $restaurant_logo = $this->Crud->read_field('id', $restaurant_id, 'user', 'logo');
        $data['business_name'] = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
        if(empty($restaurant_logo) || !file_exists($restaurant_logo)) {
            $restaurant_logo = 'assets/img/restaurant.png';
        }
        $data['business_logo'] = $restaurant_logo;
        $data['title'] = 'Restaurant - '.app_name;
        if(!empty($param1)){
            $data['title'] = ucwords(str_replace('_',' ', $param1)).'`s Restaurant - '.app_name;
        }
        $data['page_active'] = $mod;
        return view('home/cart', $data);
    }

    public function restaurant($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        $data['param1'] = $param1;
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('partner'))) { $partner = $this->request->getPost('partner'); } else { $partner = ''; }
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

			$items = '
				
				
			';

            $all_rec = $this->Crud->filter_mrestaurants('', '', $search);
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $query = $this->Crud->filter_mrestaurants($limit, $offset, $search);
            $data['count'] = $counts;
            if(!empty($query)) {
                foreach($query as $q) {
                    $id = $q->id;
                    $business_name = $q->business_name;
                    $img = $q->logo;
                    $reg_date = date('M d, Y', strtotime($q->reg_date));
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/restaurant.png';
                     }

                    $item .= '
                        <div class="col">
                            <div class="bg-white listing-card shadow-sm rounded-2 p-3 position-relative">
                                <img src="'.site_url($img).'" style="height:180px !important;" class="img-fluid rounded-1" alt="...">
                                <a href="'.site_url('home/vendor/'.strtolower(str_replace(' ', '_', $business_name))).'" class="stretched-link"></a>
                            </div>
                        </div>
                    ';
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                    <i class="bi bi-cup-hot" style="font-size:150px;"></i><br/><br/>No Dish Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}
        $restaurant_id = $this->Crud->read_field('business_name', str_replace('_',' ', $param1), 'user', 'id');
        $restaurant_logo = $this->Crud->read_field('id', $restaurant_id, 'user', 'logo');
        $data['business_name'] = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
        if(empty($restaurant_logo) || !file_exists($restaurant_logo)) {
            $restaurant_logo = 'assets/img/team1.jpeg';
        }
        $data['business_logo'] = $restaurant_logo;
        $data['title'] = 'Restaurant - '.app_name;
        if(!empty($param1)){
            $data['title'] = ucwords(str_replace('_',' ', $param1)).'`s Restaurant - '.app_name;
        }
        $data['page_active'] = $mod;
        return view('home/restaurant', $data);
    }

    ///// LOGIN
    public function about() {
        $data['title'] = 'About Page - '.app_name;
        return view('home/about', $data);
    }

    public function profile($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        // if(empty($log_id)) return redirect()->to(site_url('auth'));
        $mod = 'home';
        $role = 'Guest';
        $data['param1'] = $param1;
        $data['param2'] = $param2;
        $data['param3'] = $param3;
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
        }
        $data['log_name'] = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
        $data['log_phone'] = $this->Crud->read_field('id', $log_id, 'user', 'email');
        $data['log_id'] = $log_id;
        $data['role'] = $role;

        // record listing
		if($param1 == 'order_load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 12;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('partner'))) { $partner = $this->request->getPost('partner'); } else { $partner = ''; }
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

			$items = '
				
				
			';

            $menu = $this->Crud->read_field('name', str_replace('_', ' ',$param1), 'menu','id');
            $all_rec = $this->Crud->read_single('user_id', $log_id, 'order',  '', '');
            if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
            $query = $this->Crud->read_single('user_id', $log_id, 'order',  $limit, $offset);
            $data['count'] = $counts;
            if(!empty($query)) {
                foreach($query as $q) {
                    $id = $q->id;
                    $price = $q->price;
                    $amount = $q->amount;
                    $order_code = $q->order_code;
                    $qty = $q->qty;
                    $status = $q->status;
                    $ready_time = $this->Crud->read_field('id', $q->food_id, 'food', 'prepare_time');
                    $restaurant = $this->Crud->read_field('id', $q->restaurant_id, 'user', 'business_name');
                    $name = $this->Crud->read_field('id', $q->food_id, 'food', 'name');
                    $img = $this->Crud->read_field('id', $q->food_id, 'food', 'image');
                    $menu_id = $this->Crud->read_field('id', $q->food_id, 'food', 'menu_id');
                    $menu = $this->Crud->read_field('id', $menu_id, 'menu', 'name');
                    $reg_date = date('M d, Y h:i A', strtotime($q->reg_date));
                    $delivery_date = date('M d, Y h:i A', strtotime($q->delivery_date));
                    if(empty($img) || !file_exists($img)){
                        $img = 'assets/img/gallery.png';
                    }
                   $cdown = '';
                    if($status == 'pending'){
                        $st = '<small><i class="bi bi-exclamation-octagon-fill text-warning"></i> Pending </small>';
                    }
                    if($status == 'confirm'){
                        $st = '<small><i class="bi bi-check-circle-fill text-info"></i> Confirmed </small>';
                        
                        $confirmTime = strtotime($q->confirm_date);
                        $readyTime = $confirmTime + ($ready_time * 60);
                        
                        // Calculate remaining time
                        $currentTime = time();
                        $remainingTime = $readyTime - $currentTime;
                        $remainingTime += 3600;
                        
                        $cdown = '<div id="countdown_' . $id . '"> </div>
                        <script>
                            setInterval(function() {
                                updateCountdown(' . $remainingTime . ', ' . $id . ');
                            }, 1000);
                        </script>';
            
                    }
                    if($status == 'ready'){
                        $st = '<small><i class="bi bi-check2-circle text-info"></i> Ready for Pick-up </small>';
                    }
                    if($status == 'delivered'){
                        $st = '<small><i class="bi bi-check2-all text-success"></i> Picked-Up on </small>
                        <p class="mb-0 small text-success">'.$delivery_date.'</p>';
                    }
                    $item .= '
                        <div class="col">
                            <div class="border rounded p-3 shadow-sm history-card">
                            <div class="d-flex gap-3">
                                <img src="'.site_url($img).'" alt class="img-fluid rounded bg-light h-40" style="height:70px !important">
                                <span class="text-start">
                                    <h6 class="mb-1 fw-bold">'.ucwords($restaurant).'</h6>
                                    <div class="text-muted small text-opacity-50 mb-1">'.ucwords($menu).'</div>
                                    <div class="text-muted small">ORDER #'.$order_code.' | '.$reg_date.'</div>
                                </span>
                                <div class="ms-auto text-end">
                                    '.$st.'  '.$cdown.'
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-3 border-top pt-3 mt-3">
                                <span class="text-start">
                                    <p class="mb-0">'.ucwords($name).' x '.$qty.'</p>
                                    <p class="mb-0 text-danger">Total Paid: <b>'.curr.number_format($price,2).'</b></p>
                                </span>
                                <div class="ms-auto text-end">
                                    <button class="btn btn-sm btn-outline-success text-uppercase me-2" onclick="add_cart('.$q->food_id.')" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">REORDER</button>
                                    <button class="btn btn-sm btn-success text-uppercase pop" pageName="'.site_url('home/profile/manage/order/'.$id).'" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">VIEW DETAILS</button>
                                </div>
                            </div>
                            </div>
                        </div>
                    ';
                }
            }
        
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="col-12">
                        <div class="col-12">
                            <div class="text-center text-muted">
                                    <i class="bi bi-cup-hot" style="font-size:150px;"></i><br/><br/>No Order Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}
        $data['title'] = 'Profile - '.app_name;
        
        
        if($param1 == 'manage'){
            return view('home/profile_form', $data);
 
        } else{
            $data['page_active'] = $mod;
            return view('home/profile', $data);
        }
    }
}
