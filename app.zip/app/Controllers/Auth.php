<?php

namespace App\Controllers;

class Auth extends BaseController {
    public function index() {
        return $this->login();
    }

    ///// LOGIN
    public function login() {
        // check login
        $log_id = $this->session->get('ra_id');
        if(!empty($log_id)) return redirect()->to(site_url('dashboard'));

        if($this->request->getMethod() == 'post') {
            $email = $this->request->getVar('email');
            $password = $this->request->getVar('password');
            $type = $this->request->getVar('type');

            if(!$email || !$password) {
                echo $this->Crud->msg('danger', 'Please provide Email and Password');
            } else {
                // check user login detail
                $user_id = $this->Crud->read_field2('email', $email, 'password', md5($password), 'user', 'id');
                if(empty($user_id)) {
                    echo $this->Crud->msg('danger', 'Invalid Authentication!');
                } else {
                    ///// store activities
					$code = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
					$action = $code.' logged in from the Backend ';
					if($type == 'web') {
						$action = $code.' logged in from the Web ';
					}
					$this->Crud->activity('authentication', $user_id, $action);

                    echo $this->Crud->msg('success', 'Login Successful!');
                    $this->session->set('ra_id', $user_id);
					if($type == 'web'){
						echo '<script>location.reload(false);</script>';
					} else {
						echo '<script>window.location.replace("'.site_url('dashboard').'");</script>';
					}
                }
            }

            die;
        }
        
        $data['title'] = 'Log In - '.app_name;
        return view('auth/login', $data);
    }

	public function register() {
        if($this->request->getMethod() == 'post') {
            $fullname = $this->request->getPost('fullname');
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $confirm = $this->request->getPost('confirm');
            $phone = $this->request->getPost('phone');
            $country_id = $this->request->getPost('country_id');
            $state_id = $this->request->getPost('state_id');
            $address = $this->request->getPost('address');

            $Error = '';
			if($this->Crud->check('email', $email, 'user') > 0) {$Error .= 'Email Taken <br/>';}
			if($this->Crud->check('phone', $phone, 'user') > 0) {$Error .= 'Phone Number Taken <br/>';}
			if($password != $confirm) {$Error .= 'Password Not Match';}

			if($Error) {
				echo $this->Crud->msg('danger', $Error);
				die;
			}

			$role_id = $this->Crud->read_field('name', 'Customer', 'access_role', 'id');
            $ins_data['fullname'] = $fullname;
			$ins_data['email'] = $email;
			$ins_data['phone'] = $phone;
			$ins_data['address'] = $address;
			$ins_data['role_id'] = $role_id;
			$ins_data['activate'] = 1;
			$ins_data['password'] = md5($password);
			$ins_data['reg_date'] = date(fdate);

			$ins_id = $this->Crud->create('user', $ins_data);
			if($ins_id > 0) {
				$msg = 'Email Verify message body.';
				// $this->Crud->send_email($email, $fullname, $ins_id, 'Account Email Verification', $msg);
				
				echo $this->Crud->msg('success', 'Account Created Successfully. Please Login');
				// echo '<script>location.reload(false);</script>';
				///// store activities
				$code = $this->Crud->read_field('id', $ins_id, 'user', 'fullname');
				$action = $code.' Created a Customer Account ';
				$this->Crud->activity('authentication', $ins_id, $action);
				echo '<script>
					$("#bb_ajax_form").hide(500);
				</script>';

			} else {
				echo $this->Crud->msg('danger', 'Please Try Again Later');
			}

			die;
        }
        
        $data['title'] = 'Register | '.app_name;
        return view('auth/register', $data);
    }
    public function frontend($param1='', $param2=''){
        $data['log_id'] = $this->session->get('ra_id');
        $data['param1'] = $param1;
        $data['param2'] = $param2;
        
        return view('frontend/auth', $data);
    }

    ///// LOGOUT
    public function logout() {
        if (!empty($this->session->get('ra_id'))) {
            $user_id = $this->session->get('ra_id');
            ///// store activities
            $code = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
            $action = $code . ' logged out';
            $this->Crud->activity('authentication', $user_id, $action);

            $this->session->remove('ra_id');
        }
        return redirect()->to(site_url());
    }

    
    /////////////Check if Email Exist////////////////////
    public function check_email($email) {
		if($email) {
			if($this->Crud->check('email', $email, 'user') <= 0) {
				echo '<span class="text-success small">'.('Email Accepted').'!</span>';
			} else {
				echo '<span class="text-danger small">'.('Email Taken').'</span>';
			}
			die;
		}
	}

	/////////////Check if Phone Number Exist////////////////////
    public function check_phone($phone) {
		if($phone) {
			if($this->Crud->check('phone', $phone, 'user') <= 0) {
				echo '<span class="text-success small">'.('Phone Number Accepted').'</span>';
			} else {
				echo '<span class="text-danger small">'.('Phone Number Taken').'</span>';
			}
			die;
		}
	}


    //////////////Check if Password Matchs////////////////////////////
	public function check_password($param1 = '', $param2 = '') {
		if($param1 && $param2) {
			if($param1 == $param2) {
				echo '<span class="text-success small">'.('Password Matched').'</span>';
			} else {
				echo '<span class="text-danger small">'.('Password Not Matched').'</span>';
			}
			die;
		}
	}


    /////////////Get state from Country////////////////////
    public function get_state($country_id) {
        $states = '<option value="">Select </option>';

		$state_id = $this->request->getGet('state_id');

		$all_states = $this->Crud->read_single_order('country_id', $country_id, 'state', 'name', 'asc');
		if(!empty($all_states)) {
			foreach($all_states as $as) {
				$s_sel = '';
				if(!empty($state_id)) if($state_id == $as->id) $s_sel = 'selected';
				$states .= '<option value="'.$as->id.'" '.$s_sel.'>'.$as->name.'</option>';
			}
		} else{
			$states = '<option value="">Select Country First</option>';
		}

		echo $states;
		die;
	}

}
