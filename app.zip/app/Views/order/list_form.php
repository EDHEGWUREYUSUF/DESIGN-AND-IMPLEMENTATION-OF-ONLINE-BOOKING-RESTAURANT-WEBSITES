
<?php
use App\Models\Crud;
$this->Crud = new Crud();
?>
<?php echo form_open_multipart($form_link, array('id'=>'bb_ajax_form2', 'class'=>'')); ?>
    <!-- delete view -->
    <?php if($param2 == 'delete') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <h3><b>Are you sure?</b></h3>
                <input type="hidden" name="d_order_id" value="<?php if(!empty($d_id)){echo $d_id;} ?>" />
            </div>
            
            <div class="col-sm-12 text-center">
                <button class="btn btn-danger text-uppercase" type="submit">
                    <i class="ri-delete-bin-4-line"></i> Yes - Delete
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- insert/edit view -->
    <?php if($param2 == 'edit' || $param2 == '') { ?>
       

        <div class="row">
            <input type="hidden" name="order_id" value="<?php if(!empty($e_id)){echo $e_id;} ?>" />

            <div class="col-6 col-sm-4 mb-3">
                <div style="background-color:#eee; padding: 15px;">
                    <div class="text-muted"><?php echo $e_reg_date; ?></div>
                    <div style="font-size:20px; font-weight:bold;"><?php echo $e_code; ?></div>
                </div>
            </div>
            <div class="col-sm-2 mb-3"></div>
            <div class="col-6 col-sm-6 mb-3 ">
                <div style="background-color:#eee; padding: 15px;">
                    <b class="text-muted"></b>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            <img alt="" height="80px" src="<?php echo site_url($e_food_img); ?>" />
                        </div>
                        <div class="m-l-10">
                            <div class="mb-0 ml-2 text-dark font-weight-semibold"><?php echo ucwords($e_name); ?></div>
                            <div class="mb-0 ml-2 text-muted"><?php echo ucwords($e_menu); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Customer -->
            <div class="col-sm-6 mb-5">
                <div style="background-color:#fcfcfc; padding: 15px;">
                    <b class="text-muted">CUSTOMER</b>
                    <hr/>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            <img alt="" height="50px" src="<?php echo site_url($e_customer_img); ?>" />
                        </div>
                        <div class="m-l-10">
                            <div class="mb-0 ml-2 text-dark font-weight-semibold"><?php echo ucwords($e_customer); ?></div>
                            <div class="mb-0 ml-2 opacity-07 font-size-13"><?php echo $e_customer_phone; ?></div>
                        </div>
                    </div><br/>
                    <div class="text-muted"><?php echo $e_customer_email; ?></div>
                </div>
            </div>

            <!-- Vendor -->
            <div class="col-sm-6 m-b-15">
                <div style="background-color:#fcfcfc; padding: 15px;">
                    <b class="text-muted">RESTAURANT</b>
                    <hr/>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            <img alt="" height="50px" src="<?php echo site_url($e_vendor_img); ?>" />
                        </div>
                        <div class="m-l-10">
                            <div class="m-b-0 text-dark font-weight-semibold"><?php echo ucwords($e_vendor); ?></div>
                            <div class="m-b-0 opacity-07 font-size-13"><?php echo $e_vendor_phone; ?></div>
                        </div>
                    </div><br/>
                    <div class="text-muted"><?php echo $e_vendor_email; ?></div>
                </div>
            </div>
            <!-- Pricing -->
            <div class="col-sm-12">
                <b class="text-muted">ORDER PRICING</b>
                <table class="table table-response table-stried">
                    <thead>
                        <tr>
                            <td><b>ITEM</b></td>
                            <td class="text-right" width="125px"><b>QUANTITY</b></td>
                            <td class="text-right" width="125px"><b>AMOUNT (<?php echo $e_curr; ?>)</b></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class=""><?php echo $e_item_name; ?></td>
                            <td class="text-right"><?php echo $e_quantity  ; ?></td>
                            <td class="text-right"><?php echo $e_price; ?></td>
                        </tr>
                        <tr>
                            <td colspan="2"><b>TOTAL</b></td>
                            <td class="text-right"><b><?php echo $e_total; ?></b></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Settlements -->
            <?php if($role != 'customer') { ?>
            
                <?php if($e_status != 'delivered' && $e_status != 'cancel') { ?>
                    <div class="col-sm-12">
                        <hr />
                        
                        <?php $status = array('pending', 'confirm', 'ready', 'delivered'); ?>
                        
                        <div class="row">
                            <h3 class="col-sm-12 text-center m-b-30">Manage Order Status</h3>
                            <div class="col-6 col-sm-6">
                                <select name="status" class="select2">
                                    <?php 
                                        foreach($status as $k=>$v) {
                                            $list = true;
                                            if($e_status == $v) { $s_sel = 'selected'; } else { $s_sel = ''; }
                                            
                                            if($e_status == 'pending' && $v != 'confirm') { $list = false; } 
                                            if($e_status == 'confirm' && $v != 'ready') { $list = false; } 
                                            if($e_status == 'ready' && $v != 'delivered') { $list = false; } 
                                            if($list) { echo '<option value="'.$v.'" '.$s_sel.'>'.ucwords($v).'</option>'; }
                                        }
                                    ?>
                                    <option value="cancel">Cancel Order</option>
                                </select>
                            </div>
                            <div class="col-12 col-sm-4">
                                <button class="btn btn-primary bb_form_bt" type="submit">
                                    <i class="anticon anticon-save"></i> Update Order
                                </button>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
        <div class="row">
            <div class="col-sm-12 mt-3"><div id="bb_ajax_msg2"></div></div>
        </div>
    <?php } ?>
<?php echo form_close(); ?>
<script>
    $('.select2').select2();
   
   

</script>
<script src="<?php echo site_url(); ?>assets/backend/jsform.js"></script>