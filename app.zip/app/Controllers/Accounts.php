<?php

namespace App\Controllers;

class Accounts extends BaseController {
	private $db;

    public function __construct() {
		$this->db = \Config\Database::connect();
	}


    //// Restaurant
    public function restaurant($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        if(empty($log_id)) return redirect()->to(site_url('auth'));

        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, 'accounts/restaurant', 'create');
        $role_r = $this->Crud->module($role_id, 'accounts/restaurant', 'read');
        $role_u = $this->Crud->module($role_id, 'accounts/restaurant', 'update');
        $role_d = $this->Crud->module($role_id, 'accounts/restaurant', 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('profile'));	
        }

        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

        $table = 'user';

		$form_link = site_url('accounts/restaurant/');
		if($param1){$form_link .= $param1.'/';}
		if($param2){$form_link .= $param2.'/';}
		if($param3){$form_link .= $param3.'/';}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = rtrim($form_link, '/');
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}

					if($this->request->getMethod() == 'post'){
						$del_id = $this->request->getVar('d_restaurant_id');
						///// store activities
						$log_name = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$code = $this->Crud->read_field('id', $del_id, 'user', 'business_name');
						$action = $log_name.' deleted ('.$code.') Restaurant Account';

						if($this->Crud->deletes('id', $del_id, $table) > 0) {
							$this->Crud->activity('account', $del_id, $action);
							echo $this->Crud->msg('success', 'Account Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}	
						exit;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_fullname'] = $e->fullname;
								$data['e_business_name'] = $e->business_name;
								$data['e_address'] = $e->address;
								$data['e_logo'] = $e->logo;
								$data['e_phone'] = $e->phone;
								$data['e_email'] = $e->email;
								$data['e_ban'] = $e->activate;
							}
						}
					}
				}

				if($this->request->getMethod() == 'post'){
					$user_id = $this->request->getVar('user_id');
					$business_name = $this->request->getVar('business_name');
					$fullname = $this->request->getVar('fullname');
					$email = $this->request->getVar('email');
					$phone = $this->request->getVar('phone');
					$address = $this->request->getVar('address');
					$logo = $this->request->getVar('logo');
					$ban = $this->request->getVar('ban');
					$password = $this->request->getVar('password');

					 //// Image upload
					if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/restaurant_logo/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}

					$role_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
					// echo $role_id;die;
					$ins_data['fullname'] = $fullname;
					$ins_data['email'] = $email;
					$ins_data['role_id'] = $role_id;
					$ins_data['phone'] = $phone;
					$ins_data['logo'] = $logo;
					$ins_data['address'] = $address;
					$ins_data['business_name'] = $business_name;
					$ins_data['phone'] = $phone;
					$ins_data['activate'] = $ban;
					if(!empty($password))$ins_data['password'] = md5($password);
					$role_id = $this->Crud->read_field('name', 'User', 'access_role', 'id');
				
					// do create or update
					if ($user_id) {
						$upd_rec = $this->Crud->updates('id', $user_id, $table, $ins_data);
						if ($upd_rec > 0) {
							///// store activities
							$code = $this->Crud->read_field('id', $user_id, $table, 'fullname');
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$action = $by.' updated Parent '.$code.' Record';
							$this->Crud->activity('account', $user_id, $action);

							echo $this->Crud->msg('success', 'Record Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');
						}
					} else {
						if($this->Crud->check('email', $email, 'user') > 0){
							echo $this->Crud->msg('danger', 'Email Already Taken');
						} elseif($this->Crud->check('phone', $phone, 'user') > 0){
							echo $this->Crud->msg('danger', 'Phone Number Already Taken');
						} else{
							$ins_data['reg_date'] = date(fdate);

							$user_id = $this->Crud->create('user', $ins_data);
							if($user_id > 0) {
								///// store activities
								$action = $fullname.' created a Restaurant Account';
								$this->Crud->activity('account', $user_id, $action);

								echo $this->Crud->msg('success', 'Record Created');
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('info', 'No Changes');
							}
						}
					}
					die;	
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
			$counts = 0;

			if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			
			$search = $this->request->getPost('search');
			$status = $this->request->getPost('status');
			if (!empty($this->request->getPost('start_date'))) {$start_date = $this->request->getPost('start_date');} else {$start_date = '';}
			if (!empty($this->request->getPost('end_date'))) {$end_date = $this->request->getPost('end_date');} else {$end_date = '';}
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_restaurant('', '', $log_id, $search, $status, $start_date, $end_date);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_restaurant($limit, $offset, $log_id, $search, $status, $start_date, $end_date);

				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$fullname = $q->fullname;
						$business_name = $q->business_name;
						$address = $q->address;
						$logo = $q->logo;
						$email = $q->email;
						$phone = $q->phone;
						$ban = $q->activate;
						
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						if(empty($ban) && $ban == 0){
							$b = '<span class="text-danger font-size-12">ACCOUNT BANNED</span>';
						} else {
							$b = '<span class="text-success font-size-12">ACCOUNT ACTIVE</span>';
						}
						
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
								<div class="textright">
									<a href="javascript:;" class="text-info pop m-b-5 m-r-5" pageTitle="Reset '.$fullname.' Details" pageName="'.base_url('accounts/restaurant/manage/edit/'.$id).'" pageSize="modal-lg">
										<i class="anticon anticon-rollback"></i> EDIT
									</a>
									<a href="javascript:;" class="text-danger pop m-b-5 m-l-5  m-r-5" pageTitle="Delete '.$fullname.' Record" pageName="'.base_url('accounts/restaurant/manage/delete/'.$id).'" pageSize="modal-sm">
										<i class="anticon anticon-delete"></i> DELETE
									</a>
									
								</div>
							';
						}
						
						
						$item .= '
							<li class="list-group-item">
								<div class="row p-t-10">
									<div class="col-12 col-md-4 m-b-10">
										<div class="d-flex align-items-center">
											<div class="avatar avatar-image">
												<img src="'.site_url($logo).'" alt="">
											</div>
											<div class="m-l-10">
												<div class="m-b-0 text-dark  font-size-16 font-weight-semibold">'.ucwords($business_name).'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$email.'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$phone.'</div>
											</div>
										</div>
										
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="text-primary font-size-14">'.strtoupper($fullname).'</div>
											<div class=" text-muted">'.$address.'</div>
											'.$b.'
										</div>
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="text-primary font-size-14"><b>Reg Date<i class="anticon anticon-swap-right"></i></b> '.$reg_date.'</div>
										</div>
									</div>
									<div class="col-12 col-md-2 text-right">
										<b class="font-size-12">'.$all_btn.'</b>
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-cluster" style="font-size:150px;"></i><br/><br/>No Restaurant Found Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'manage') { // view for form data posting
			return view('accounts/restaurant_form', $data);
		} else { // view for main page
            $data['title'] = 'Restaurant - '.app_name;
            $data['page_active'] = 'accounts/restaurant';
            return view('accounts/restaurant', $data);
        }
    }

	public function administrator($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        if(empty($log_id)) return redirect()->to(site_url('auth'));

        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, 'accounts/administrator', 'create');
        $role_r = $this->Crud->module($role_id, 'accounts/administrator', 'read');
        $role_u = $this->Crud->module($role_id, 'accounts/administrator', 'update');
        $role_d = $this->Crud->module($role_id, 'accounts/administrator', 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('profile'));	
        }

        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

        $table = 'user';

		$form_link = site_url('accounts/administrator/');
		if($param1){$form_link .= $param1.'/';}
		if($param2){$form_link .= $param2.'/';}
		if($param3){$form_link .= $param3.'/';}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = rtrim($form_link, '/');
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}

					if($this->request->getMethod() == 'post'){
						$del_id = $this->request->getVar('d_administrator_id');
						///// store activities
						$log_name = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$code = $this->Crud->read_field('id', $del_id, 'user', 'fullname');
						$action = $log_name.' deleted ('.$code.') Administrator Account';

						if($this->Crud->deletes('id', $del_id, $table) > 0) {
							$this->Crud->activity('account', $del_id, $action);
							echo $this->Crud->msg('success', 'Account Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}	
						exit;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_fullname'] = $e->fullname;
								$data['e_role_id'] = $e->role_id;
								$data['e_logo'] = $e->img_id;
								$data['e_phone'] = $e->phone;
								$data['e_email'] = $e->email;
								$data['e_ban'] = $e->activate;
							}
						}
					}
				}

				if($this->request->getMethod() == 'post'){
					$user_id = $this->request->getVar('user_id');
					$fullname = $this->request->getVar('fullname');
					$email = $this->request->getVar('email');
					$phone = $this->request->getVar('phone');
					$role_id = $this->request->getVar('role_id');
					$logo = $this->request->getVar('logo');
					$ban = $this->request->getVar('ban');
					$password = $this->request->getVar('password');

					 //// Image upload
					 if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/users/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}


					// echo $role_id;die;
					$ins_data['fullname'] = $fullname;
					$ins_data['email'] = $email;
					$ins_data['phone'] = $phone;
					$ins_data['img_id'] = $logo;
					$ins_data['role_id'] = $role_id;
					$ins_data['phone'] = $phone;
					$ins_data['is_staff'] = 1;
					$ins_data['activate'] = $ban;
					if(!empty($password))$ins_data['password'] = md5($password);
				
					// do create or update
					if ($user_id) {
						$upd_rec = $this->Crud->updates('id', $user_id, $table, $ins_data);
						if ($upd_rec > 0) {
							///// store activities
							$code = $this->Crud->read_field('id', $user_id, $table, 'fullname');
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$action = $by.' updated Administrator '.$code.' Record';
							$this->Crud->activity('account', $user_id, $action);

							echo $this->Crud->msg('success', 'Record Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');
						}
					} else {
						if($this->Crud->check('email', $email, 'user') > 0){
							echo $this->Crud->msg('danger', 'Email Already Taken');
						} elseif($this->Crud->check('phone', $phone, 'user') > 0){
							echo $this->Crud->msg('danger', 'Phone Number Already Taken');
						} else{
							$ins_data['reg_date'] = date(fdate);

							$user_id = $this->Crud->create('user', $ins_data);
							if($user_id > 0) {
								///// store activities
								$action = $fullname.' created an Administrator Account';
								$this->Crud->activity('account', $user_id, $action);

								echo $this->Crud->msg('success', 'Record Created');
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('info', 'No Changes');
							}
						}
					}
					die;	
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
			$counts = 0;

			if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			
			$search = $this->request->getPost('search');
			$status = $this->request->getPost('status');
			if (!empty($this->request->getPost('start_date'))) {$start_date = $this->request->getPost('start_date');} else {$start_date = '';}
			if (!empty($this->request->getPost('end_date'))) {$end_date = $this->request->getPost('end_date');} else {$end_date = '';}
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_admin('', '', $log_id, $search, $status, $start_date, $end_date);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_admin($limit, $offset, $log_id, $search, $status, $start_date, $end_date);

				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$fullname = $q->fullname;
						$role_id = $q->role_id;
						$address = $q->address;
						$logo = $q->logo;
						$email = $q->email;
						$phone = $q->phone;
						$ban = $q->activate;
						$u_role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						if(empty($ban) && $ban == 0){
							$b = '<span class="text-danger font-size-12">ACCOUNT BANNED</span>';
						} else {
							$b = '<span class="text-success font-size-12">ACCOUNT ACTIVE</span>';
						}
						
						
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
								<div class="textright">
									<a href="javascript:;" class="text-info pop m-b-5 m-r-5" pageTitle="Reset '.$fullname.' Details" pageName="'.base_url('accounts/administrator/manage/edit/'.$id).'" pageSize="modal-lg">
										<i class="anticon anticon-rollback"></i> EDIT
									</a>
									<a href="javascript:;" class="text-danger pop m-b-5 m-l-5  m-r-5" pageTitle="Delete '.$fullname.' Record" pageName="'.base_url('accounts/administrator/manage/delete/'.$id).'" pageSize="modal-sm">
										<i class="anticon anticon-delete"></i> DELETE
									</a>
									
								</div>
							';
						}
						
						
						$item .= '
							<li class="list-group-item">
								<div class="row p-t-10">
									<div class="col-12 col-md-4 m-b-10">
										<div class="d-flex align-items-center">
											<div class="avatar avatar-image">
												<img src="'.site_url($logo).'" alt="">
											</div>
											<div class="m-l-10">
												<div class="m-b-0 text-dark  font-size-16 font-weight-semibold">'.ucwords($fullname).'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$email.'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$phone.'</div>
											</div>
										</div>
										
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="text-primary font-size-14">'.strtoupper($u_role).'</div>
											<div class=" text-muted">'.$address.'</div>
											'.$b.'
										</div>
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											
										</div>
									</div>
									<div class="col-12 col-md-2 text-right">
										<b class="font-size-12">'.$all_btn.'</b>
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-team" style="font-size:150px;"></i><br/><br/>No Administrator Found Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'manage') { // view for form data posting
			return view('accounts/administrator_form', $data);
		} else { // view for main page
            $data['title'] = 'Administrator - '.app_name;
            $data['page_active'] = 'accounts/administrator';
            return view('accounts/administrator', $data);
        }
    }

	public function staffs($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        if(empty($log_id)) return redirect()->to(site_url('auth'));

        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, 'accounts/staffs', 'create');
        $role_r = $this->Crud->module($role_id, 'accounts/staffs', 'read');
        $role_u = $this->Crud->module($role_id, 'accounts/staffs', 'update');
        $role_d = $this->Crud->module($role_id, 'accounts/staffs', 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('profile'));	
        }

        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

        $table = 'user';

		$form_link = site_url('accounts/staffs/');
		if($param1){$form_link .= $param1.'/';}
		if($param2){$form_link .= $param2.'/';}
		if($param3){$form_link .= $param3.'/';}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = rtrim($form_link, '/');
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}

					if($this->request->getMethod() == 'post'){
						$del_id = $this->request->getVar('d_staff_id');
						///// store activities
						$log_name = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$code = $this->Crud->read_field('id', $del_id, 'user', 'fullname');
						$action = $log_name.' deleted ('.$code.') Administrator Account';

						if($this->Crud->deletes('id', $del_id, $table) > 0) {
							$this->Crud->activity('account', $del_id, $action);
							echo $this->Crud->msg('success', 'Account Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}	
						exit;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_fullname'] = $e->fullname;
								$data['e_role_id'] = $e->role_id;
								$data['e_restaurant_id'] = $e->restaurant_id;
								$data['e_logo'] = $e->img_id;
								$data['e_phone'] = $e->phone;
								$data['e_email'] = $e->email;
								$data['e_ban'] = $e->activate;
							}
						}
					}
				}

				if($this->request->getMethod() == 'post'){
					$user_id = $this->request->getVar('user_id');
					$fullname = $this->request->getVar('fullname');
					$email = $this->request->getVar('email');
					$phone = $this->request->getVar('phone');
					$role_id = $this->request->getVar('role_id');
					$restaurant_id = $this->request->getVar('restaurant_id');
					$logo = $this->request->getVar('logo');
					$ban = $this->request->getVar('ban');
					$password = $this->request->getVar('password');

					 //// Image upload
					 if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/users/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}


					// echo $role_id;die;
					$ins_data['fullname'] = $fullname;
					$ins_data['email'] = $email;
					$ins_data['phone'] = $phone;
					$ins_data['img_id'] = $logo;
					$ins_data['role_id'] = $role_id;
					$ins_data['restaurant_id'] = $restaurant_id;
					$ins_data['phone'] = $phone;
					$ins_data['is_staffs'] = 1;
					$ins_data['activate'] = $ban;
					if(!empty($password))$ins_data['password'] = md5($password);
				
					// do create or update
					if ($user_id) {
						$upd_rec = $this->Crud->updates('id', $user_id, $table, $ins_data);
						if ($upd_rec > 0) {
							///// store activities
							$code = $this->Crud->read_field('id', $user_id, $table, 'fullname');
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$action = $by.' update Staff '.$code.' Record';
							$this->Crud->activity('account', $user_id, $action);

							echo $this->Crud->msg('success', 'Record Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');
						}
					} else {
						if($this->Crud->check('email', $email, 'user') > 0){
							echo $this->Crud->msg('danger', 'Email Already Taken');
						} elseif($this->Crud->check('phone', $phone, 'user') > 0){
							echo $this->Crud->msg('danger', 'Phone Number Already Taken');
						} else{
							$ins_data['reg_date'] = date(fdate);

							$user_id = $this->Crud->create('user', $ins_data);
							if($user_id > 0) {
								///// store activities
								$action = $fullname.' created a Staff Account';
								$this->Crud->activity('account', $user_id, $action);

								echo $this->Crud->msg('success', 'Record Created');
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('info', 'No Changes');
							}
						}
					}
					die;	
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
			$counts = 0;

			if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			
			$search = $this->request->getPost('search');
			$status = $this->request->getPost('status');
			if (!empty($this->request->getPost('start_date'))) {$start_date = $this->request->getPost('start_date');} else {$start_date = '';}
			if (!empty($this->request->getPost('end_date'))) {$end_date = $this->request->getPost('end_date');} else {$end_date = '';}
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_staff('', '', $log_id, $search, $status, $start_date, $end_date);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_staff($limit, $offset, $log_id, $search, $status, $start_date, $end_date);

				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$fullname = $q->fullname;
						$role_id = $q->role_id;
						$address = $q->address;
						$logo = $q->logo;
						$email = $q->email;
						$phone = $q->phone;
						$ban = $q->activate;
						$restaurant_id = $q->restaurant_id;
						$restaurant = $this->Crud->read_field('id', $restaurant_id, 'user', 'business_name');
						$u_role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						if(empty($ban) && $ban == 0){
							$b = '<span class="text-danger font-size-12">ACCOUNT BANNED</span>';
						} else {
							$b = '<span class="text-success font-size-12">ACCOUNT ACTIVE</span>';
						}
						
						
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
								<div class="textright">
									<a href="javascript:;" class="text-info pop" pageTitle="Reset '.$fullname.' Details" pageName="'.base_url('accounts/staffs/manage/edit/'.$id).'" pageSize="modal-lg">
										<i class="anticon anticon-rollback"></i> EDIT
									</a>
									<a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$fullname.' Record" pageName="'.base_url('accounts/staffs/manage/delete/'.$id).'" pageSize="modal-sm">
										<i class="anticon anticon-delete"></i> DELETE
									</a>
									
								</div>
							';
						}
						
						
						$item .= '
							<li class="list-group-item">
								<div class="row p-t-10">
									<div class="col-12 col-md-4 m-b-10">
										<div class="d-flex align-items-center">
											<div class="avatar avatar-image">
												<img src="'.site_url($logo).'" alt="">
											</div>
											<div class="m-l-10">
												<div class="m-b-0 text-dark  font-size-16 font-weight-semibold">'.ucwords($fullname).'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$email.'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$phone.'</div>
											</div>
										</div>
										
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="text-primary font-size-14">'.strtoupper($u_role).'</div>
											<div class=" text-muted">'.$address.'</div>
											'.$b.'
										</div>
									</div>
									<div class="col-12 col-md-2 m-b-5">
										<div class="single">
											'.ucwords($restaurant).'
										</div>
									</div>
									<div class="col-12 col-md-2 text-right">
										<b class="font-size-12">'.$all_btn.'</b>
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-team" style="font-size:150px;"></i><br/><br/>No Staffs Found Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'manage') { // view for form data posting
			return view('accounts/staff_form', $data);
		} else { // view for main page
            $data['title'] = 'Staffs - '.app_name;
            $data['page_active'] = 'accounts/staff';
            return view('accounts/staff', $data);
        }
    }

	public function customer($param1='', $param2='', $param3='') {
        // check login
        $log_id = $this->session->get('ra_id');
        if(empty($log_id)) return redirect()->to(site_url('auth'));

        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, 'accounts/customer', 'create');
        $role_r = $this->Crud->module($role_id, 'accounts/customer', 'read');
        $role_u = $this->Crud->module($role_id, 'accounts/customer', 'update');
        $role_d = $this->Crud->module($role_id, 'accounts/customer', 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('profile'));	
        }

        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

        $table = 'user';

		$form_link = site_url('accounts/customer/');
		if($param1){$form_link .= $param1.'/';}
		if($param2){$form_link .= $param2.'/';}
		if($param3){$form_link .= $param3.'/';}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = rtrim($form_link, '/');
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}

					if($this->request->getMethod() == 'post'){
						$del_id = $this->request->getVar('d_customer_id');
						///// store activities
						$log_name = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$code = $this->Crud->read_field('id', $del_id, 'user', 'business_name');
						$action = $log_name.' deleted ('.$code.') Customer Account';

						if($this->Crud->deletes('id', $del_id, $table) > 0) {
							$this->Crud->activity('account', $del_id, $action);
							echo $this->Crud->msg('success', 'Account Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}	
						exit;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_fullname'] = $e->fullname;
								$data['e_role_id'] = $e->role_id;
								$data['e_address'] = $e->address;
								$data['e_logo'] = $e->img_id;
								$data['e_phone'] = $e->phone;
								$data['e_email'] = $e->email;
								$data['e_ban'] = $e->activate;
							}
						}
					}
				}

				if($this->request->getMethod() == 'post'){
					$user_id = $this->request->getVar('user_id');
					$role_id = $this->request->getVar('role_id');
					$fullname = $this->request->getVar('fullname');
					$email = $this->request->getVar('email');
					$phone = $this->request->getVar('phone');
					$address = $this->request->getVar('address');
					$logo = $this->request->getVar('logo');
					$ban = $this->request->getVar('ban');
					$password = $this->request->getVar('password');

					 //// Image upload
					 if(file_exists($this->request->getFile('logo'))) {
						$path = 'assets/backend/images/users/'.$log_id.'/';
						$file = $this->request->getFile('logo');
						$getImg = $this->Crud->img_upload($path, $file);
						
						if(!empty($getImg->path)) $logo = $getImg->path;
					}

					// echo $role_id;die;
					$ins_data['fullname'] = $fullname;
					$ins_data['email'] = $email;
					$ins_data['role_id'] = $role_id;
					$ins_data['phone'] = $phone;
					$ins_data['logo'] = $logo;
					$ins_data['address'] = $address;
					$ins_data['phone'] = $phone;
					$ins_data['activate'] = $ban;
					if(!empty($password))$ins_data['password'] = md5($password);
				
					// do create or update
					if ($user_id) {
						$upd_rec = $this->Crud->updates('id', $user_id, $table, $ins_data);
						if ($upd_rec > 0) {
							///// store activities
							$code = $this->Crud->read_field('id', $user_id, $table, 'fullname');
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$action = $by.' updated Customer '.$code.' Record';
							$this->Crud->activity('account', $user_id, $action);

							echo $this->Crud->msg('success', 'Record Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');
						}
					} else {
						if($this->Crud->check('email', $email, 'user') > 0){
							echo $this->Crud->msg('danger', 'Email Already Taken');
						} elseif($this->Crud->check('phone', $phone, 'user') > 0){
							echo $this->Crud->msg('danger', 'Phone Number Already Taken');
						} else{
							$ins_data['reg_date'] = date(fdate);

							$user_id = $this->Crud->create('user', $ins_data);
							if($user_id > 0) {
								///// store activities
								$action = $fullname.' created a Restaurant Account';
								$this->Crud->activity('account', $user_id, $action);

								echo $this->Crud->msg('success', 'Record Created');
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('info', 'No Changes');
							}
						}
					}
					die;	
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
			$counts = 0;

			if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			
			$search = $this->request->getPost('search');
			$status = $this->request->getPost('status');
			if (!empty($this->request->getPost('start_date'))) {$start_date = $this->request->getPost('start_date');} else {$start_date = '';}
			if (!empty($this->request->getPost('end_date'))) {$end_date = $this->request->getPost('end_date');} else {$end_date = '';}
			$log_id = $this->session->get('ra_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_customer('', '', $log_id, $search, $status, $start_date, $end_date);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_customer($limit, $offset, $log_id, $search, $status, $start_date, $end_date);

				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$fullname = $q->fullname;
						$business_name = $q->business_name;
						$address = $q->address;
						$logo = $q->logo;
						$email = $q->email;
						$phone = $q->phone;
						$ban = $q->activate;
						
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						if(empty($logo) || !file_exists($logo)){
							$logo = 'assets/backend/images/avatar.jpeg';
						}
						if(empty($ban) && $ban == 0){
							$b = '<span class="text-danger font-size-12">ACCOUNT BANNED</span>';
						} else {
							$b = '<span class="text-success font-size-12">ACCOUNT ACTIVE</span>';
						}
						
						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
								<div class="textright">
									<a href="javascript:;" class="text-info pop m-b-5 m-r-5" pageTitle="Reset '.$fullname.' Details" pageName="'.base_url('accounts/customer/manage/edit/'.$id).'" pageSize="modal-lg">
										<i class="anticon anticon-rollback"></i> EDIT
									</a>
									<a href="javascript:;" class="text-danger pop m-b-5 m-l-5  m-r-5" pageTitle="Delete '.$fullname.' Record" pageName="'.base_url('accounts/customer/manage/delete/'.$id).'" pageSize="modal-sm">
										<i class="anticon anticon-delete"></i> DELETE
									</a>
									
								</div>
							';
						}
						
						
						$item .= '
							<li class="list-group-item">
								<div class="row p-t-10">
									<div class="col-12 col-md-4 m-b-10">
										<div class="d-flex align-items-center">
											<div class="avatar avatar-image">
												<img src="'.site_url($logo).'" alt="">
											</div>
											<div class="m-l-10">
												<div class="m-b-0 text-dark  font-size-16 font-weight-semibold">'.ucwords($fullname).'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$email.'</div>
												<div class="m-b-0 opacity-07 font-size-13">'.$phone.'</div>
											</div>
										</div>
										
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class=" text-muted">'.$address.'</div>
											'.$b.'
										</div>
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="text-primary font-size-14"><b>Reg Date<i class="anticon anticon-swap-right"></i></b> '.$reg_date.'</div>
										</div>
									</div>
									<div class="col-12 col-md-2 text-right">
										<b class="font-size-12">'.$all_btn.'</b>
									</div>
								</div>
							</li>
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-cluster" style="font-size:150px;"></i><br/><br/>No Restaurant Found Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

        if($param1 == 'manage') { // view for form data posting
			return view('accounts/customer_form', $data);
		} else { // view for main page
            $data['title'] = 'Customer - '.app_name;
            $data['page_active'] = 'accounts/customer';
            return view('accounts/customer', $data);
        }
    }

	

	public function get_state($country_id) {
        $states = '<option value="">Select </option>';

		$state_id = $this->request->getGet('state_id');

		$all_states = $this->Crud->read_single_order('country_id', $country_id, 'state', 'name', 'asc');
		if(!empty($all_states)) {
			foreach($all_states as $as) {
				$s_sel = '';
				if(!empty($state_id)) if($state_id == $as->id) $s_sel = 'selected';
				$states .= '<option value="'.$as->id.'" '.$s_sel.'>'.$as->name.'</option>';
			}
		} else{
			$states = '<option value="">Select Country First</option>';
		}

		echo $states;
		die;
	}
	
}
