
<?php
use App\Models\Crud;
$this->Crud = new Crud();
?>
<?php echo form_open_multipart($form_link, array('id'=>'bb_ajax_form', 'class'=>'')); ?>
    <!-- delete view -->
    <?php if($param2 == 'delete') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <h3><b>Are you sure?</b></h3>
                <input type="hidden" name="d_restaurant_id" value="<?php if(!empty($d_id)){echo $d_id;} ?>" />
            </div>
            
            <div class="col-sm-12 text-center">
                <button class="btn btn-danger text-uppercase" type="submit">
                    <i class="anticon anticon-delete"></i> Yes - Delete
                </button>
            </div>
        </div>
    <?php } ?>

  
    <!-- insert/edit view -->
    <?php if($param2 == 'edit' || $param2 == '') { ?>
        
        
        <div class="row">
            <input type="hidden" name="user_id" value="<?php if(!empty($e_id)){echo $e_id;} ?>" />
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Restaurant Name</label>
                    <input type="text" class="form-control" name="business_name" id="business_name" required value="<?php if(!empty($e_business_name)){echo $e_business_name;} ?>">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Contact Name</label>
                    <input type="text" class="form-control" name="fullname" id="fullname" required value="<?php if(!empty($e_fullname)){echo $e_fullname;} ?>">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Email</label>
                    <input type="email" class="form-control" name="email" id="email" required value="<?php if(!empty($e_email)){echo $e_email;} ?>">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Phone</label>
                    <input type="text" class="form-control" name="phone" id="phone" required value="<?php if(!empty($e_phone)){echo $e_phone;} ?>">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="activate">Active Status</label>
                    <select class="form-control select2" data-toggle="select2" id="ban" name="ban" required>
                        <option value="1" <?php if(!empty($e_ban)){if($e_ban == 1){echo 'selected';}} ?>>Active</option>
                        <option value="0" <?php if(empty($e_ban) && $param2 == 'edit'){if($e_ban == 0){echo 'selected';}} ?>>Disable</option>
                    </select>
                </div>
            </div>
           
            <?php if($param2 == 'edit'){?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="activate">Reset Password</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                </div>
            <?php } else {?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="activate">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                </div>
            <?php } ?>
           
            <div class="col-sm-7">
                <div class="form-group">
                    <label for="activate">Restaurant Address</label>
                    <input type="text" class="form-control" name="address" id="address" required value="<?php if(!empty($e_address)){echo $e_address;} ?>">
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-group"><b>Restaurant Logo</b><br>
                    <label for="img-upload" class="pointer text-center" style="width:100%;">
                        <input type="hidden" name="logo" value="<?php if(!empty($e_logo)){echo $e_logo;} ?>" />
                        <img id="img0" src="<?php if(!empty($e_logo)){echo site_url($e_logo);} ?>" style="max-width:100%;" />
                        <span class="btn btn-danger btn-block no-mrg-btm">Choose Image</span>
                        <input class="d-none" type="file" name="logo" id="img-upload">
                    </label>
                </div>
            </div>           
            

            <div class="col-sm-12 text-center">
                <button class="btn btn-primary m-t-5 m-b-5 bb_fo_btn" type="submit">
                    <i class="anticon anticon-save"></i> Save Record
                </button>
            </div>

           

        </div>
        <div class="row ">
            <div class="col-sm-12 text-center m-t-5"><div id="bb_ajax_msg"></div></div>
        </div>
    <?php } ?>
<?php echo form_close(); ?>
<script>
    $('.js-select2').select2();
   
    function statea() {
        var country = $('#country_id').val();
        $.ajax({
            url: '<?=site_url('accounts/get_state/');?>'+ country,
            success: function(data) {
                $('#state').html(data);
            }
        });
        
    }

    function lgaa() {
        var lga = $('#state').val();
        $.ajax({
            url: '<?=site_url('accounts/get_lga/');?>'+ lga,
            success: function(data) {
                $('#lga_resp').html(data);
            }
        });
    }
    function readURL(input, id) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#' + id).attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	$("#img-upload").change(function(){
		readURL(this, 'img0');
	});
	
	$("#img-uploads").change(function(){
		readURL(this, 'img1');
	});

</script>
<script src="<?php echo site_url(); ?>assets/backend/jsform.js"></script>