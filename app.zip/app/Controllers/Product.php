<?php

namespace App\Controllers;

class Product extends BaseController {
    //Pump for Filling Station
	public function pump($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('fls_id') == ''){
			$request_uri = uri_string();
			$this->session->set('fls_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'product/pump';

        $log_id = $this->session->get('fls_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'pump';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_pump_id');
                        $code = $this->Crud->read_field('id', $del_id, 'pump', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted pump ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('pump', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_product'] = $e->product;
								$data['e_branch_id'] = $e->branch_id;
								$data['e_price'] = $e->price;
								
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$pump_id =  $this->request->getVar('pump_id');
					$name =  $this->request->getVar('name');
					$product =  $this->request->getVar('product');
					$branch_id =  $this->request->getVar('branch_id');
					$price =  $this->request->getVar('price');
					
					// do create or update
					if($pump_id) {
						$upd_data['name'] = $name;
						$upd_data['product'] = $product;
						$upd_data['price'] = $price;
						
						$upd_rec = $this->Crud->updates('id', $pump_id, $table, $upd_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $pump_id, 'pump', 'name');
							$action = $by.' updated Pump ('.$code.') Record';
							$this->Crud->activity('pump', $pump_id, $action);

							echo $this->Crud->msg('success', 'Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'user_id', $log_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['name'] = $name;
							$ins_data['product'] = $product;
							$ins_data['price'] = $price;
							$ins_data['user_id'] = $log_id;
							$ins_data['branch_id'] = $branch_id;
							$ins_data['reg_date'] = date(fdate);
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Record Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'pump', 'name');
								$action = $by.' created Pump ('.$code.') Record';
								$this->Crud->activity('pump', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('partner'))) { $partner = $this->request->getPost('partner'); } else { $partner = ''; }
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

			$items = '
				<div class="nk-tb-item nk-tb-head">
					<div class="nk-tb-col"><span class="sub-text">Fueling Station</span></div>
					<div class="nk-tb-col"><span class="sub-text">Pump</span></div>
					<div class="nk-tb-col tb-col-lg"><span class="sub-text">Product</span></div>
					<div class="nk-tb-col tb-col-mb"><span class="sub-text">Price</span></div>
					<div class="nk-tb-col tb-col-mb"><span class="sub-text">Branch</span></div>
					<div class="nk-tb-col tb-col-md"><span class="sub-text">Action</span></div>
				</div><!-- .nk-tb-item -->
				
			';

            //echo $status;
			$log_id = $this->session->get('fls_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_pump('', '', $log_id, $partner, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_pump($limit, $offset, $log_id, $partner, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$product = $q->product;
						$price = $q->price;
						$name = $q->name;
						$user = $this->Crud->read_field('id', $q->user_id, 'user', 'fullname');
						$branch = $this->Crud->read_field('id', $q->branch_id, 'branch', 'name');
						$img_id = $this->Crud->read_field('id', $q->user_id, 'user', 'img_id');
						$prod = $this->Crud->read_field('id', $q->product, 'category', 'name');
						$img = $this->Crud->image($img_id, 'big');
						$reg_date = date('M d, Y', strtotime($q->reg_date));

						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="ni ni-edit-alt"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="ni ni-trash-alt"></i> Delete
									</a>
								
							';
						}

						$item .= '
							<div class="nk-tb-item">
								<div class="nk-tb-col">
									<div class="user-card">
										<div class="user-avatar ">
											<img alt="" src="'.site_url($img).'" height="40px"/>
										</div>
										<div class="user-info">
											<span class="tb-lead">'.ucwords($user).' <span class="dot dot-success d-md-none ms-1"></span></span>
											<span></span>
										</div>
									</div>
								</div>
								<div class="nk-tb-col tb-col-lg">
									<span class="text-dark"><b>'.ucwords($name).'</b></span>
								</div>
								<div class="nk-tb-col tb-col-mb">
									<span>'.ucwords($prod).'</span>
								</div>
								<div class="nk-tb-col tb-col-mb">
									<span>&#163;'.number_format($price, 2).'</span>
								</div>
								<div class="nk-tb-col tb-col-mb">
									<span>'.($branch).'</span>
								</div>
								<div class="nk-tb-col nk-tb-col-mb">
                                    <a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
                                        <i class="ni ni-edit-alt"></i> Edit
                                    </a>&nbsp;
                                    <a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
                                        <i class="ni ni-trash-alt"></i> Delete
                                    </a>
								</div>
							</div><!-- .nk-tb-item -->
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="text-center text-muted">
                                <br/><br/><br/><br/>
                                <i class="ni ni-truck" style="font-size:150px;"></i><br/><br/>No Product Pump Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Pump  | '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

     //Filling Station Branch
	public function branch($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('fls_id') == ''){
			$request_uri = uri_string();
			$this->session->set('fls_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'product/branch';

        $log_id = $this->session->get('fls_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'branch';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			if($param2 == 'account') {
				if($param3) {
					$edit = $this->Crud->read_single('branch_id', $param3, 'account');
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['e_id'] = $e->id;
							$data['e_branch_id'] = $param3;
							$data['e_bank'] = $e->code;
							$data['e_account'] = $e->account;
							$data['e_name'] = $e->name;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$branch_id =  $this->request->getVar('branch_id');
                        $bank_id =  $this->request->getVar('bank_id');
                        $account =  $this->request->getVar('account');
						$bank = $this->Crud->read_field('code', $bank_id, 'bank', 'name');
						if(!empty($bank_id) && !empty($account)){
							$ins['branch_id'] = $branch_id;
							$ins['bank'] = $bank;
							$ins['code'] = $bank_id;
							$ins['account'] = $account;
							$ins['user_id'] = $log_id;
							$ins['name'] = 'Verify';

							
							$code = $this->Crud->read_field('id', $branch_id, 'branch', 'name');
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$action = $by.' assigned bank account to ('.$code.')';
							
							if($this->Crud->check('branch_id', $branch_id, 'account') > 0){
								if($this->Crud->updates('branch_id', $branch_id, 'account', $ins) > 0){
									///// store activities
									$this->Crud->activity('pump', $branch_id, $action);

									echo $this->Crud->msg('success', 'Account Assigned');
									echo '<script>location.reload(false);</script>';
								} else {
									echo $this->Crud->msg('danger', 'No Changes');
									die;
								}

							} else {
								if($this->Crud->create('account', $ins) > 0){
									///// store activities
									$this->Crud->activity('pump', $branch_id, $action);

									echo $this->Crud->msg('success', 'Account Assigned');
									echo '<script>location.reload(false);</script>';
								} else {
									echo $this->Crud->msg('danger', 'Try Again');
									die;
								}


							}

									
							die;
						}	
					}
				}
			}
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_branch_id');
                        $code = $this->Crud->read_field('id', $del_id, 'branch', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted pump ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('pump', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_address'] = $e->address;
								$data['e_country_id'] = $e->country_id;
								$data['e_state_id'] = $e->state_id;
								$data['e_city_id'] = $e->city_id;
								
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$branch_id =  $this->request->getVar('branch_id');
					$name =  $this->request->getVar('name');
					$address =  $this->request->getVar('address');
					$country_id =  $this->request->getVar('country_id');
					$state_id =  $this->request->getVar('state');
					$city_id =  $this->request->getVar('lga');
					
                    $ins_data['name'] = $name;
                    $ins_data['address'] = $address;
                    $ins_data['country_id'] = $country_id;
					$ins_data['state_id'] = $state_id;
					$ins_data['city_id'] = $city_id;
					// do create or update
					if($branch_id) {
						$upd_rec = $this->Crud->updates('id', $branch_id, $table, $ins_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $branch_id, 'pump', 'name');
							$action = $by.' updated branch ('.$code.') Record';
							$this->Crud->activity('branch', $branch_id, $action);

							echo $this->Crud->msg('success', 'Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'partner_id', $log_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['partner_id'] = $log_id;
							$ins_data['reg_date'] = date(fdate);
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Record Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'branch', 'name');
								$action = $by.' created Branch ('.$code.') Record';
								$this->Crud->activity('branch', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$rec_limit = 25;
			$item = '';
            if(empty($limit)) {$limit = $rec_limit;}
			if(empty($offset)) {$offset = 0;}
			
			if(!empty($this->request->getPost('partner'))) { $partner = $this->request->getPost('partner'); } else { $partner = ''; }
			if(!empty($this->request->getPost('status'))) { $status = $this->request->getPost('status'); } else { $status = ''; }
			$search = $this->request->getPost('search');

            if($role =='developer' || $role == 'administrator') $show = '<div class="nk-tb-col"><span class="sub-text">Fueling Station</span></div>
            '; else $show = '';
			$items = '
				<div class="nk-tb-item nk-tb-head">'.$show.'
					<div class="nk-tb-col"><span class="sub-text">Branch</span></div>
					<div class="nk-tb-col tb-col"><span class="sub-text">Address</span></div>
					<div class="nk-tb-col tb-col-mb"><span class="sub-text">Location</span></div>
					<div class="nk-tb-col"><span class="sub-text">Action</span></div>
				</div>
			';

            //echo $status;
			$log_id = $this->session->get('fls_id');
			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$all_rec = $this->Crud->filter_branch('', '', $log_id, $partner, $search);
				if(!empty($all_rec)) { $counts = count($all_rec); } else { $counts = 0; }
				$query = $this->Crud->filter_branch($limit, $offset, $log_id, $partner, $search);
				$data['count'] = $counts;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$address = $q->address;
						$name = $q->name;
						$user = $this->Crud->read_field('id', $q->partner_id, 'user', 'fullname');
						$img_id = $this->Crud->read_field('id', $q->partner_id, 'user', 'img_id');
						$country = $this->Crud->read_field('id', $q->country_id, 'country', 'name');
						$state = $this->Crud->read_field('id', $q->state_id, 'state', 'name');
						$city = $this->Crud->read_field('id', $q->city_id, 'city', 'name');
						$img = $this->Crud->image($img_id, 'big');
						$reg_date = date('M d, Y', strtotime($q->reg_date));

						// add manage buttons
						if($role_u != 1) {
							$all_btn = '';
						} else {
							$all_btn = '
									<a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
										<i class="ni ni-edit-alt"></i> Edit
									</a>
									<a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
										<i class="ni ni-trash-alt"></i> Delete
									</a>
								
							';
						}
                        if($role =='developer' || $role == 'administrator') {
                            $show = '<div class="nk-tb-col">
                            <div class="user-card">
                                <div class="user-avatar ">
                                    <img alt="" src="'.site_url($img).'" height="40px"/>
                                </div>
                                <div class="user-info">
                                    <span class="tb-lead">'.ucwords($user).'</span>
                                    <span></span>
                                </div>
                            </div>
                        </div>'; 
                        } else $show = '';
						$item .= '
							<div class="nk-tb-item">
								'.$show.'
								<div class="nk-tb-col tb-col">
									<span class="text-dark"><b>'.ucwords($name).'</b></span>
								</div>
								<div class="nk-tb-col tb-col">
									<span>'.ucwords($address).'</span>
								</div>
								<div class="nk-tb-col tb-col-mb">
                                    <span class="tb-amount">'.$country.'</span><span class="text-info">'.$state.'&rarr; '.$city.'</span>
								</div>
								<div class="nk-tb-col nk-tb-col-mb">
                                    <a href="javascript:;" class="text-primary pop" pageTitle="Manage '.$name.'" pageName="'.site_url($mod.'/manage/edit/'.$id).'">
                                        <i class="ni ni-edit-alt"></i> Edit
                                    </a>&nbsp;
                                    <a href="javascript:;" class="text-danger pop" pageTitle="Delete '.$name.'" pageName="'.site_url($mod.'/manage/delete/'.$id).'">
                                        <i class="ni ni-trash-alt"></i> Delete
                                    </a>&nbsp;
                                    <a href="javascript:;" class="text-info pop" pageTitle="Account" pageName="'.site_url($mod.'/manage/account/'.$id).'">
                                        <i class="ni ni-user"></i>Bank Account
                                    </a>
								</div>
							</div><!-- .nk-tb-item -->
						';
					}
				}
			}
			
			if(empty($item)) {
				$resp['item'] = $items.'
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="text-center text-muted">
                                <br/><br/><br/><br/>
                                <i class="ni ni-home-alt" style="font-size:150px;"></i><br/><br/>No Branch Returned
                            </div>
                        </div>
                    </div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['count'] = $counts;

			$more_record = $counts - ($offset + $rec_limit);
			$resp['left'] = $more_record;

			if($counts > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Branch  | '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }
}
