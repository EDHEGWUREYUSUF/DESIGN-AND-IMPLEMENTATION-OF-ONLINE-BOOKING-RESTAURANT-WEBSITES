<?php

namespace App\Controllers;

class Wallets extends BaseController {

    
    //Wallet
	public function list($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'wallets/list';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'wallets';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_pump_id');
                        $code = $this->Crud->read_field('id', $del_id, 'pump', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted pump ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('pump', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_product'] = $e->product;
								$data['e_price'] = $e->price;
								
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$pump_id =  $this->request->getVar('pump_id');
					$name =  $this->request->getVar('name');
					$product =  $this->request->getVar('product');
					$price =  $this->request->getVar('price');
					
					// do create or update
					if($pump_id) {
						$upd_data['name'] = $name;
						$upd_data['product'] = $product;
						$upd_data['price'] = $price;
						
						$upd_rec = $this->Crud->updates('id', $pump_id, $table, $upd_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $pump_id, 'pump', 'name');
							$action = $by.' updated Pump ('.$code.') Record';
							$this->Crud->activity('pump', $pump_id, $action);

							echo $this->Crud->msg('success', 'Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'user_id', $log_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['name'] = $name;
							$ins_data['product'] = $product;
							$ins_data['price'] = $price;
							$ins_data['user_id'] = $log_id;
							$ins_data['reg_date'] = date(fdate);
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Record Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'pump', 'name');
								$action = $by.' created Pump ('.$code.') Record';
								$this->Crud->activity('pump', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // fund wallet
		if($param1 == 'withdraw') {
		    if($_POST) {
		        $user_id = $this->request->getVar('user_id');
		        $amount = $this->request->getVar('amount');
		        $remark = $this->request->getVar('remark');
		        
		        if(!$user_id || !$amount) {
		            echo $this->Crud->msg('danger', 'Account and Amount required');
		        } else {
		            $amount = $this->Crud->to_number($amount);
		            
		            if(empty($remark)) { $remark = 'Coupon Bonus'; }
		            
		            $v_ins['user_id'] = $user_id;
		            $v_ins['type'] = 'credit';
		            $v_ins['amount'] = $amount;
		            $v_ins['item'] = 'coupon';
		            $v_ins['item_id'] = $user_id;
		            $v_ins['remark'] = $remark;
		            $v_ins['reg_date'] = date(fdate);
		            $v_id = $this->Crud->create('wallet', $v_ins);
		            
		            if($v_id > 0) {
		                echo $this->Crud->msg('success', 'Wallet Funded!');
		                
		                // notify add
		                $staff = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
		                $customer = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
						$user_role_id = $this->Crud->read_field('id', $user_id, 'user', 'role_id');
						$user_role = $this->Crud->read_field('id', $user_role_id, 'access_role', 'name');

						///// store activities
						$action = $staff.' funded '.$user_role.' ('.$customer.') wallet with &#163;'.number_format($amount,2).' as '.$remark;
						$this->Crud->activity('wallet', $v_id, $action);
		                
		                $subject = 'Coupon Bonus Notification';
		                $subhead = 'Account Wallet Funded';
		                $body_msg = 'Hello,<br/><br/>This is to notify you about a Wallet funded by '.$staff.' to '.$customer.' for '.$remark.'.</i><br/><br/>Thank you.';
		                $this->Crud->send_email('walaone2010@gmail.com', push_email, $subject, $body_msg, app_name, $subhead);
		                
		                echo '<script>location.reload(false);</script>';
		            } else {
		                echo $this->Crud->msg('warning', 'Failed to credit Wallet! Please try later');
		            }
		        }
		        
		        die;
		    }
		}
		
		// wallet statement
		if($param1 == 'statement') {
		    $data['statement_id'] = $param2;
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$count = 0;
			$rec_limit = 25;
			$item = '';

			if($limit == '') {$limit = $rec_limit;}
			if($offset == '') {$offset = 0;}
			
			if(!empty($this->request->getVar('start_date'))) { $start_date = $this->request->getVar('start_date'); } else { $start_date = ''; }
			if(!empty($this->request->getVar('end_date'))) { $end_date = $this->request->getVar('end_date'); } else { $end_date = ''; }
			$search = $this->request->getVar('search');

			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$query = $this->Crud->filter_wallet($limit, $offset, $log_id, $search, $start_date, $end_date);
				$all_rec = $this->Crud->filter_wallet('', '', $log_id, $search, $start_date, $end_date);
				if(!empty($all_rec)) { $count = count($all_rec); } else { $count = 0; }
				$curr = '&#163;';
				$debit = 0;$credit = 0;
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$user_id = $q->user_id;
						$type = $q->type;
						$mod = $q->item;
						$remark = $q->remark;
						$amount = number_format((float)$q->amount, 2);
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						
						$color = 'danger';
						if($type == 'credit')$color = 'success';

						if($type == 'debit')$debit+=(float)$q->amount;
						if($type == 'credit')$credit+=(float)$q->amount;
						
						// user 
						$user = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
						$user_role_id = $this->Crud->read_field('id', $user_id, 'user', 'role_id');
						$user_role = strtoupper($this->Crud->read_field('id', $user_role_id, 'access_role', 'name'));
						$user_image_id = $this->Crud->read_field('id', $user_id, 'user', 'img_id');
						$user_image = $this->Crud->image($user_image_id, 'big');

						// currency
						

						$item .= '
							<li class="list-group-item">
								<div class="row">
									<div class="col-8 col-md-3 mb-10">
										<div class="single">
											<div class="text-muted font-size-12">'.$reg_date.'</div>
											'.ucwords($user).'
										</div>
									</div>
									<div class="col-12 col-md-2 mb-2">
										<div class="font-size-12 small">'.ucwords($mod).'</div>
										<div class="font-size-14 text-'.$color.'">'.ucwords($type).'</div>
									</div>
									<div class="col-12 col-md-5 mb-2">
										<div class="font-size-14 text-muted">'.ucwords($remark).'</div>
									</div>
									<div class="col-12 col-md-2 text-right" align="right">
										<b class="font-size-14 text-'.$color.'">'.$curr.$amount.'</b>
									</div>
								</div>
							</li>
						';
					}
				}
			}

			$total = 0;
			
			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-wallet" style="font-size:150px;"></i><br/><br/>No Wallet Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}

			$more_record = $count - ($offset + $rec_limit);
			$resp['left'] = $more_record;
			$resp['total'] = $curr . number_format($total, 2);

			if($count > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}
			$bal = (float)$credit - (float)$debit;
			if($bal < 0)$bal = 0;
			$resp['balance'] =  $curr . number_format($bal, 2);
			$resp['debit'] =  $curr . number_format($debit, 2);
			$resp['credit'] =  $curr . number_format($credit, 2);
			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage' || $param1 == 'withdraw' || $param1 == 'statement') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Wallets  | '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

	public function transaction($param1='', $param2='', $param3='') {
		// check session login
		if($this->session->get('ra_id') == ''){
			$request_uri = uri_string();
			$this->session->set('ra_redirect', $request_uri);
			return redirect()->to(site_url('auth'));
		} 

        $mod = 'wallets/transaction';

        $log_id = $this->session->get('ra_id');
        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, $mod, 'create');
        $role_r = $this->Crud->module($role_id, $mod, 'read');
        $role_u = $this->Crud->module($role_id, $mod, 'update');
        $role_d = $this->Crud->module($role_id, $mod, 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('dashboard'));	
        }
        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;
       
		$table = 'wallets';
		$form_link = site_url($mod);
		if($param1){$form_link .= '/'.$param1;}
		if($param2){$form_link .= '/'.$param2.'/';}
		if($param3){$form_link .= $param3;}
		
		// pass parameters to view
		$data['param1'] = $param1;
		$data['param2'] = $param2;
		$data['param3'] = $param3;
		$data['form_link'] = $form_link;
		
		// manage record
		if($param1 == 'manage') {
			// prepare for delete
			if($param2 == 'delete') {
				if($param3) {
					$edit = $this->Crud->read_single('id', $param3, $table);
                    //echo var_dump($edit);
					if(!empty($edit)) {
						foreach($edit as $e) {
							$data['d_id'] = $e->id;
						}
					}
					
					if($this->request->getMethod() == 'post'){
						$del_id =  $this->request->getVar('d_pump_id');
                        $code = $this->Crud->read_field('id', $del_id, 'pump', 'name');
						$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
						$action = $by.' deleted pump ('.$code.')';
							
                        if($this->Crud->deletes('id', $del_id, $table) > 0) {

							///// store activities
							$this->Crud->activity('pump', $del_id, $action);
							
							echo $this->Crud->msg('success', 'Record Deleted');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('danger', 'Please try later');
						}
						die;	
					}
				}
			} else {
				// prepare for edit
				if($param2 == 'edit') {
					if($param3) {
						$edit = $this->Crud->read_single('id', $param3, $table);
						if(!empty($edit)) {
							foreach($edit as $e) {
								$data['e_id'] = $e->id;
								$data['e_name'] = $e->name;
								$data['e_product'] = $e->product;
								$data['e_price'] = $e->price;
								
							}
						}
					}
				}

				
				if($this->request->getMethod() == 'post'){
					$pump_id =  $this->request->getVar('pump_id');
					$name =  $this->request->getVar('name');
					$product =  $this->request->getVar('product');
					$price =  $this->request->getVar('price');
					
					// do create or update
					if($pump_id) {
						$upd_data['name'] = $name;
						$upd_data['product'] = $product;
						$upd_data['price'] = $price;
						
						$upd_rec = $this->Crud->updates('id', $pump_id, $table, $upd_data);
						if($upd_rec > 0) {
							///// store activities
							$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
							$code = $this->Crud->read_field('id', $pump_id, 'pump', 'name');
							$action = $by.' updated Pump ('.$code.') Record';
							$this->Crud->activity('pump', $pump_id, $action);

							echo $this->Crud->msg('success', 'Updated');
							echo '<script>location.reload(false);</script>';
						} else {
							echo $this->Crud->msg('info', 'No Changes');	
						}
                        die;
					} else {
						if($this->Crud->check2('name', $name, 'user_id', $log_id, $table) > 0) {
							echo $this->Crud->msg('warning', 'Record Already Exist');
						} else {
							$ins_data['name'] = $name;
							$ins_data['product'] = $product;
							$ins_data['price'] = $price;
							$ins_data['user_id'] = $log_id;
							$ins_data['reg_date'] = date(fdate);
							
							$ins_rec = $this->Crud->create($table, $ins_data);
							if($ins_rec > 0) {
								echo $this->Crud->msg('success', 'Record Created');
								///// store activities
								$by = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
								$code = $this->Crud->read_field('id', $ins_rec, 'pump', 'name');
								$action = $by.' created Pump ('.$code.') Record';
								$this->Crud->activity('pump', $ins_rec, $action);
								echo '<script>location.reload(false);</script>';
							} else {
								echo $this->Crud->msg('danger', 'Please try later');	
							}	
						}

					}die;
						
				}
			}
		}

        // fund wallet
		if($param1 == 'fund') {
		    if($_POST) {
		        $user_id = $this->request->getVar('user_id');
		        $amount = $this->request->getVar('amount');
		        $remark = $this->request->getVar('remark');
		        
		        if(!$user_id || !$amount) {
		            echo $this->Crud->msg('danger', 'Account and Amount required');
		        } else {
		            $amount = $this->Crud->to_number($amount);
		            
		            if(empty($remark)) { $remark = 'Coupon Bonus'; }
		            
		            $v_ins['user_id'] = $user_id;
		            $v_ins['type'] = 'credit';
		            $v_ins['amount'] = $amount;
		            $v_ins['item'] = 'coupon';
		            $v_ins['item_id'] = $user_id;
		            $v_ins['remark'] = $remark;
		            $v_ins['reg_date'] = date(fdate);
		            $v_id = $this->Crud->create('wallet', $v_ins);
		            
		            if($v_id > 0) {
		                echo $this->Crud->msg('success', 'Wallet Funded!');
		                
		                // notify add
		                $staff = $this->Crud->read_field('id', $log_id, 'user', 'fullname');
		                $customer = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
						$user_role_id = $this->Crud->read_field('id', $user_id, 'user', 'role_id');
						$user_role = $this->Crud->read_field('id', $user_role_id, 'access_role', 'name');

						///// store activities
						$action = $staff.' funded '.$user_role.' ('.$customer.') wallet with &#163;'.number_format($amount,2).' as '.$remark;
						$this->Crud->activity('wallet', $v_id, $action);
		                
		                $subject = 'Coupon Bonus Notification';
		                $subhead = 'Account Wallet Funded';
		                $body_msg = 'Hello,<br/><br/>This is to notify you about a Wallet funded by '.$staff.' to '.$customer.' for '.$remark.'.</i><br/><br/>Thank you.';
		                $this->Crud->send_email('walaone2010@gmail.com', push_email, $subject, $body_msg, app_name, $subhead);
		                
		                echo '<script>location.reload(false);</script>';
		            } else {
		                echo $this->Crud->msg('warning', 'Failed to credit Wallet! Please try later');
		            }
		        }
		        
		        die;
		    }
		}
		
		// wallet statement
		if($param1 == 'statement') {
		    $data['statement_id'] = $param2;
		}

        // record listing
		if($param1 == 'load') {
			$limit = $param2;
			$offset = $param3;

			$count = 0;
			$rec_limit = 25;
			$item = '';

			if($limit == '') {$limit = $rec_limit;}
			if($offset == '') {$offset = 0;}
			
			if(!empty($this->request->getVar('start_date'))) { $start_date = $this->request->getVar('start_date'); } else { $start_date = ''; }
			if(!empty($this->request->getVar('end_date'))) { $end_date = $this->request->getVar('end_date'); } else { $end_date = ''; }
			$search = $this->request->getVar('search');

			if(!$log_id) {
				$item = '<div class="text-center text-muted">Session Timeout! - Please login again</div>';
			} else {
				$total_bal = 0;$total_deb = 0;$total_cred = 0;
				$query = $this->Crud->filter_transaction($limit, $offset, $log_id, $search, $start_date, $end_date);
				$all_rec = $this->Crud->filter_transaction('', '', $log_id, $search, $start_date, $end_date);
				if(!empty($all_rec)) { $count = count($all_rec); } else { $count = 0; }
				$curr = '&#163;';

				$item = '
					<li class="list-group-item">
						<div class="row p-t-10">
							<div class="col-8 col-md-3 m-b-10">
								<div class="single">
									<div class="text-dark font-size-14 font-weight-bold">DATE</div>
								</div>
							</div>
							<div class="col-12 col-md-3 m-b-5">
								<div class="single">
									<div class="font-size-14 text-dark font-weight-bold">USER</div>
								</div>
							</div>
							<div class="col-12 col-md-3 m-b-5">
								<div class="single">
									<b class="font-size-14 text-dark">REFERENCE</b>
								</div>
							</div>
							<div class="col-12 col-md-2 text-right">
								<div class="single">
									<b class="font-size-14 text-dark">AMOUNT</b>
								</div>
							</div>
						</div>
					</li>
				';
				if(!empty($query)) {
					foreach($query as $q) {
						$id = $q->id;
						$user_id = $q->user_id;
						$reference = $q->reference;
						$amount = number_format((float)$q->amount, 2);
						$reg_date = date('M d, Y h:i A', strtotime($q->reg_date));

						// user 
						$user = $this->Crud->read_field('id', $user_id, 'user', 'fullname');
						$user_role_id = $this->Crud->read_field('id', $user_id, 'user', 'role_id');
						$user_role = strtoupper($this->Crud->read_field('id', $user_role_id, 'access_role', 'name'));
						$user_image_id = $this->Crud->read_field('id', $user_id, 'user', 'img_id');
						$user_image = $this->Crud->image($user_image_id, 'big');

						

						$item .= '
							<li class="list-group-item">
								<div class="row p-t-10">
									<div class="col-8 col-md-3 m-b-10">
										<div class="single">
											<div class="text-muted font-size-12">'.$reg_date.'</div>
										</div>
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<div class="font-size-14">'.$user.'</div>
										</div>
									</div>
									<div class="col-12 col-md-3 m-b-5">
										<div class="single">
											<b class="font-size-14 text-success">'.strtoupper($reference).'</b>
										</div>
									</div>
									<div class="col-12 col-md-2 text-right">
										<div class="single">
											<b class="font-size-14 text-dark">'.$curr.$amount.'</b>
										</div>
									</div>
								</div>
							</li>
						';
					}
				}
			}

			if(empty($item)) {
				$resp['item'] = '
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<i class="anticon anticon-cc-secure" style="font-size:150px;"></i><br/><br/>No Transaction Returned
					</div>
				';
			} else {
				$resp['item'] = $item;
			}
			$total_bal = $total_cred - $total_deb;
			$more_record = $count - ($offset + $rec_limit);
			$resp['left'] = $more_record;
			$resp['count'] = $count;

			if($count > ($offset + $rec_limit)) { // for load more records
				$resp['limit'] = $rec_limit;
				$resp['offset'] = $offset + $limit;
			} else {
				$resp['limit'] = 0;
				$resp['offset'] = 0;
			}

			echo json_encode($resp);
			die;
		}

		if($param1 == 'manage' || $param1 == 'fund' || $param1 == 'statement') { // view for form data posting
			return view($mod.'_form', $data);
		} else { // view for main page
			
			$data['title'] = 'Transactions  | '.app_name;
			$data['page_active'] = $mod;
			return view($mod, $data);
		}
    }

    ////// ACCOUNT STATEMENT
	public function account($id=0) {
	    $email = $this->request->getVar('email');
	    if(!empty($email)) { $id = $this->Crud->read_field('email', $email, 'user', 'id'); }
	    
	    if(empty($id)) { redirect(base_url('wallet')); }
	    
	    $items = '';
	    $total_credit = 0;
	    $total_debit = 0;
	    
	    $name = $this->Crud->read_field('id', $id, 'user', 'fullname');
	    $query = $this->Crud->read_single_order('user_id', $id, 'wallet', 'id', 'asc');
	    if(!empty($query)) {
	        foreach($query as $q) {
	            $date = date('M d, Y h:iA', strtotime($q->reg_date));
	            
	            $credit = '-';
	            $debit = '-';
	            if($q->type == 'credit') {
	                $credit = '&#163;'.number_format($q->amount, 2);
	                $total_credit += $q->amount;
	            } else {
	                $debit = '&#163;'.number_format($q->amount, 2);
	                $total_debit += $q->amount;
	            }
	            
	            $items .= '
	                <tr>
	                    <td>'.$date.'</td>
	                    <td align="right">'.$credit.'</td>
	                    <td align="right">'.$debit.'</td>
	                </tr>
	            ';
	        }
	    }
	    
	    echo '
	        <h3>'.$name.' Wallet Account Statement
	            <div style="font-size:small; color:#666;">as at '.date('M d, Y h:iA').'</div>
	        </h3>
	        <table class="table table-striped">
	            <thead>
	                <tr>
	                    <td><b>DATE</b></td>
	                    <td width="200px" align="right"><b>CR</b></td>
	                    <td width="200px" align="right"><b>DR</b></td>
	                </tr>
	            </thead>
	            <tbody>'.$items.'</tbody>
	        </table>
	        <hr/>
	        <b>TOTAL CREDIT:</b> &#163;'.number_format($total_credit, 2).'<br/>
	        <b>TOTAL DEBIT:</b> &#163;'.number_format($total_debit, 2).'
	    ';
	}
	
	/////// CHECK ACCOUNT
	public function check_account() {
	    $status = false;
	    
	    $email = $this->request->getVar('email');
	    $id = $this->Crud->read_field('email', $email, 'user', 'id');
	    $fullname = $this->Crud->read_field('email', $email, 'user', 'fullname');
	    
	    if(!empty($id)) {
	        $status = true;
	        $fullname = '<b class="text-success"><i class="anticon anticon-user"></i> '.strtoupper($fullname).'</b><hr/>';
	    } else {
	        $fullname = '<b class="text-danger">Account Not Found!</b><hr/>';
	    }
	    
	    echo json_encode(array('status'=>$status, 'id'=>$id, 'fullname'=>$fullname));
	    die;
	}

	
	public function get_state($country){
		if(empty($country)){
			echo '<label for="activate">State</label>
			<input type="text" class="form-control" name="state" id="state" readonly placeholder="Select Country First">';
		} else {
			$state = $this->Crud->read_single_order('country_id', $country, 'state', 'name', 'asc');
			echo '<label for="activate">State</label>
				<select class="form-select js-select2" data-search="on" id="state" name="state" onchange="lgaa();">
					<option value="">Select</option>
			';
			foreach($state as $qr) {
				$hid = '';
				$sel = '';
				echo '<option value="'.$qr->id.'" '.$sel.'>'.$qr->name.'</option>';
			}
			echo '</select>
			<script> $(".js-select2").select2();</script>';
		}
	}

	public function get_lga($state){
		if(empty($state)){
			echo '<label for="activate">Local Goverment Area</label>
			<input type="text" class="form-control" name="lga" id="lga" readonly placeholder="Select State First">';
		} else {
			$state = $this->Crud->read_single_order('state_id', $state, 'city', 'name', 'asc');
			echo '<label for="activate">Local Goverment Area</label>
				<select class="form-select js-select2" data-search="on" id="lga" name="lga" onchange="branc();">
					<option value="">Select</option>
			';
			foreach($state as $qr) {
				$hid = '';
				$sel = '';
				echo '<option value="'.$qr->id.'" '.$sel.'>'.$qr->name.'</option>';
			}
			echo '</select>
			<script> $(".js-select2").select2();</script>';
		}
	}

	public function get_branch($state){
		if(empty($state)){
			echo '<label for="activate">Branch</label>
			<input type="text" class="form-control" name="branch" id="branch" readonly placeholder="Select LGA First">';
		} else {
			$state = $this->Crud->read_single_order('city_id', $state, 'branch', 'name', 'asc');
			echo '<label for="activate">Branch</label>
				<select class="form-select js-select2" data-search="on" id="branch" name="branch">
					<option value="">Select</option>
			';
			foreach($state as $qr) {
				$hid = '';
				$sel = '';
				echo '<option value="'.$qr->id.'" '.$sel.'>'.$qr->name.'</option>';
			}
			echo '</select>
			<script> $(".js-select2").select2();</script>';
		}
	}
}
