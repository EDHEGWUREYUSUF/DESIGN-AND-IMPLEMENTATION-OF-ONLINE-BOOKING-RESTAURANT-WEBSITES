
<?php
use App\Models\Crud;
$this->Crud = new Crud();
?>
<?php echo form_open_multipart($form_link, array('id'=>'bb_ajax_form', 'class'=>'')); ?>
    <!-- delete view -->
    <?php if($param2 == 'delete') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <h3><b>Are you sure?</b></h3>
                <input type="hidden" name="d_order_id" value="<?php if(!empty($d_id)){echo $d_id;} ?>" />
            </div>
            
            <div class="col-sm-12 text-center">
                <button class="btn btn-danger text-uppercase" type="submit">
                    <i class="ri-delete-bin-4-line"></i> Yes - Delete
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- insert/edit view -->
    <?php if($param2 == 'edit' || $param2 == '') { ?>
        <div class="row">
            <div class="col-sm-12"><div id="bb_ajax_msg"></div></div>
        </div>

        <div class="row">
            <input type="hidden" name="order_id" value="<?php if(!empty($e_id)){echo $e_id;} ?>" />

            <div class="col-6 col-sm-4 mb-3">
                <div style="background-color:#eee; padding: 15px;">
                    <div class="text-muted"><?php echo $e_reg_date; ?></div>
                    <div style="font-size:20px; font-weight:bold;"><?php echo $e_code; ?></div>
                </div>
            </div>

            <div class="col-6 col-sm-8 text-right">
                
            </div>
            
            <!-- Customer -->
            <div class="col-sm-6 mb-5">
                <div style="background-color:#fcfcfc; padding: 15px;">
                    <b class="text-muted">CUSTOMER</b>
                    <hr/>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            <img alt="" src="<?php echo base_url($e_customer_img); ?>" />
                        </div>
                        <div class="m-l-10">
                            <div class="mb-0 ml-2 text-dark font-weight-semibold"><?php echo $e_customer; ?></div>
                            <div class="mb-0 ml-2 opacity-07 font-size-13"><?php echo $e_customer_phone; ?></div>
                        </div>
                    </div><br/>
                    <?php echo $e_customer_address; ?>
                    <div class="text-muted"><?php echo $e_customer_email; ?></div>
                </div>
            </div>

            <!-- Vendor -->
            <div class="col-sm-6 m-b-15">
                <div style="background-color:#fcfcfc; padding: 15px;">
                    <b class="text-muted">VENDOR</b>
                    <hr/>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            <img alt="" height="40px" src="<?php echo base_url($e_vendor_img); ?>" />
                        </div>
                        <div class="m-l-10">
                            <div class="m-b-0 text-dark font-weight-semibold"><?php echo $e_vendor; ?></div>
                            <div class="m-b-0 opacity-07 font-size-13"><?php echo $e_vendor_phone; ?></div>
                        </div>
                    </div><br/>
                    <?php echo $e_vendor_address; ?>
                    <div class="text-muted"><?php echo $e_vendor_email; ?></div>
                </div>
            </div>
            <!-- Pricing -->
            <div class="col-sm-12">
                <b class="text-muted">ORDER PRICING</b>
                <table class="table table-response table-striped">
                    <thead>
                        <tr>
                            <td><b>ITEM</b></td>
                            <td class="text-right" width="125px"><b>UNIT</b></td>
                            <td class="text-right" width="125px"><b>AMOUNT (<?php echo $e_curr; ?>)</b></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class=""><?php echo $e_item_name; ?></td>
                            <td class=""><?php echo $e_quantity  ; ?></td>
                            <td class="text-right"><?php echo $e_sub_total; ?></td>
                        </tr>
                        <tr>
                            <td colspan="2">VAT (7.5%)</td>
                            <td class="text-right"><?php echo $e_vat; ?></td>
                        </tr>
                        <tr>
                            <td colspan="2"><b>TOTAL</b></td>
                            <td class="text-right"><b><?php echo $e_total; ?></b></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Settlements -->
            <?php if($role != 'isv' && $role != 'cluster' && $role != 'sales agent') { ?>
                <div class="col-sm-12" style="background-color:#f2f2f2; padding:15px;">
                    <b class="text-muted">SETTLEMENTS DETAILS</b>
                    <table class="table table-response table-striped">
                        <thead>
                            <tr>
                                <td><b>ACCOUNT</b></td>
                                <td width="200px"><b>TYPE</b></td>
                                <td class="text-right" width="125px"><b>TOTAL (<?php echo $e_curr; ?>)</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $comms; ?>
                        </tbody>
                    </table>
                </div>
            
            
                <?php if($e_status != 'Approved') { ?>
                    <?php if($e_status == 'Pending'){ ?>
                    <!--<div class="col-sm-12 text-center">
                        <hr />
                        <button class="btn btn-success bb_form_btn" type="submit">
                            <i class="anticon anticon-save"></i> Confirm Order
                        </button>
                    </div>-->
                    <?php } else { ?>
                    <div class="col-sm-12">
                        <hr />
                        
                        <?php $status = array('Processing', 'Processed', 'In-Transit', 'Delivered', 'Approved'); ?>
                        
                        <div class="row">
                            <h3 class="col-sm-12 text-center m-b-30">Manage Order Status (Online/Offline)</h3>
                            <div class="col-6 col-sm-4">
                                <select name="status" class="form-control select2">
                                    <?php 
                                        foreach($status as $k=>$v) {
                                            $list = true;
                                            if($e_status == $v) { $s_sel = 'selected'; } else { $s_sel = ''; }

                                            if($v == 'Approved') { if($e_status != 'Delivered') { $list = false; } }
                                            if($list) { echo '<option value="'.$v.'" '.$s_sel.'>'.$v.'</option>'; }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="col-6 col-sm-4">
                                <div class="small"><b>Auto Payment</b></div>
                                <div class="checkbox">
                                    <input type="checkbox" id="offline_pay" name="offline_pay">
                                    <label for="offline_pay">Offline Settlement</label>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <button class="btn btn-primary bb_form_btn" type="submit">
                                    <i class="anticon anticon-save"></i> Update Order
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                <?php } ?>
            <?php } ?>
        </div>
    <?php } ?>
<?php echo form_close(); ?>
<script>
    $('.js-select2').select2();
   
   

</script>
<script src="<?php echo site_url(); ?>assets/backend/js/jsform.js"></script>
<script src="<?php echo site_url(); ?>assets/backend/js/scripts.js"></>