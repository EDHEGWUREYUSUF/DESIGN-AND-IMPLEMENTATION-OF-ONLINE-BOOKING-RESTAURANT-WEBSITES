<?php
use App\Models\Crud;

$this->Crud = new Crud();
?>

<?= $this->extend('frontend/designs'); ?>
<?= $this->section('title'); ?>
<?= $title; ?>
<?= $this->endSection(); ?>

<?= $this->section('content'); ?>
<style>
   /* Styles for screens smaller than 600 pixels */
   @media (max-width: 600px) {
      .sliders {
         height: 250px;
      }
   }

   /* Styles for screens between 601 and 900 pixels */
   @media (min-width: 601px) and (max-width: 900px) {
      .sliders {
         height: 400px;
      }
   }

   /* Styles for screens larger than 900 pixels */
   @media (min-width: 901px) {
      .sliders {
         height: 500px;
      }
   }
</style>
<!-- app link -->
<section class="main-banner bg-white pt-4">
   <div class="container-fluid">
      <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
         <div class="carousel-inner rounded">
            <div class="carousel-item active">
               <a href="<?= site_url(); ?>"><img src="<?= site_url(); ?>assets/frontend/img/slide1.jpg"
                     class="d-block sliders w-100" alt="..."></a>
            </div>
            <div class="carousel-item">
               <a href="<?= site_url(); ?>"><img src="<?= site_url(); ?>assets/img/slider6.jpg"
                     class="d-block sliders w-100" alt="..."></a>
            </div>
            <div class="carousel-item">
               <a href="<?= site_url(); ?>"><img src="<?= site_url(); ?>assets/img/slider5.jpg"
                     class="d-block sliders w-100" alt="..."></a>
            </div>
         </div>
         <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
         </button>
         <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
         </button>
      </div>
   </div>
</section>

<section class="bg-white">
   <div class="container-fluid py-5">
      <div class="d-flex align-items-center justify-content-between pt-3 mb-4">
         <h5 class="mb-0 fw-bold">Menu</h5>
         <a class="text-decoration-none text-success" href="<?= site_url('home/menu'); ?>">View All <i
               class="bi bi-arrow-right-circle-fill ms-1"></i></a>
      </div>
      <div class="row row-cols-2 row-cols-md-4 row-cols-lg-6 g-4 homepage-products-range">
         <?php $menu = $this->Crud->read_order('menu', 'name', 'random');
         if (!empty($menu)) {
            $a = 0;
            foreach ($menu as $m) {
               $metric = $this->Crud->check2('status', 1, 'menu_id', $m->id, 'food');
               if($metric == 0)continue;
               if($a > 6 )continue;
               $img = $m->image;
               if (empty($img) || !file_exists($img)) {
                  $img = 'assets/frontend/img/1.png';
               }
               ?>
               <div class="col">
                  <div class="text-center position-relative border rounded pb-4">
                     <img src="<?= site_url($img); ?>" style="height:120px;" class="img-fluid rounded-3 p-3" alt="...">
                     <div class="listing-card-body pt-0">
                        <h6 class="card-title mb-1 fs-14"><?= ucwords($m->name); ?></h6>
                        <p class="card-text small text-success">
                           <?= number_format($metric); ?> Dishes
                        </p>
                     </div>
                     <a href="<?= site_url('home/menu/' . strtolower(str_replace(' ', '_', $m->name))); ?>"
                        class="stretched-link"></a>
                  </div>
               </div>
            <?php $a++;
            }
         } ?>
      </div>
   </div>
</section>

<section class="bg-white">
   <div class="container-fluid">
      <div class="d-flex align-items-center justify-content-between mb-4">
         <h5 class="mb-0 fw-bold">Restaturants</h5>
         <a class="text-decoration-none text-success" href="<?=site_url('home/restaurant'); ?>">View All <i
               class="bi bi-arrow-right-circle-fill ms-1"></i></a>
      </div>
      <div class="row g-4">
         <?php
         $role_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
         $user = $this->Crud->read_single_order('role_id', $role_id, 'user', 'name', 'random');
         if (!empty($user)) {
            foreach ($user as $u) {
               $logo = $u->logo;
               if (empty($logo) || !file_exists($logo)) {
                  $logo = 'assets/frontend/img/slider1.jpg';
               }
               ?>
               <div class="col-md-3 col-6 mb-5">
                  <a href="<?= site_url('home/vendor/' . strtolower(str_replace(' ', '_', $u->business_name))); ?>"><img
                        src="<?= site_url($logo); ?>" style="height:150px" class="img-fluid rounded-2"></a>
                        <p class="text-center mt-4"><?=ucwords($u->business_name); ?></p>
               </div>
            <?php }
         } ?>
      </div>
   </div>
</section>


<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
   $(function () {

   });

   function load(x, y) {
      var more = 'no';
      var methods = '';
      if (parseInt(x) > 0 && parseInt(y) > 0) {
         more = 'yes';
         methods = '/' + x + '/' + y;
      }

      if (more == 'no') {
         $('#load_data').html('<div class="col-sm-12 text-center"><br/><br/><br/><br/><span class="ni ni-loader fa-spin" style="font-size:38px;"></span></div>');
      } else {
         $('#loadmore').html('<div class="col-sm-12 text-center"><span class="ni ni-loader fa-spin"></span></div>');
      }

      var partner = $('#partner').val();
      var search = $('#search').val();
      //alert(status);

      $.ajax({
         url: site_url + 'product/pump/load' + methods,
         type: 'post',
         data: { partner: partner, search: search },
         success: function (data) {
            var dt = JSON.parse(data);
            if (more == 'no') {
               $('#load_data').html(dt.item);
            } else {
               $('#load_data').append(dt.item);
            }

            if (dt.offset > 0) {
               $('#loadmore').html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
            } else {
               $('#loadmore').html('');
            }
         },
         complete: function () {
            $.getScript(site_url + '/assets/backend/js/jsmodal.js');
         }
      });
   }
</script>

<?= $this->endSection(); ?>