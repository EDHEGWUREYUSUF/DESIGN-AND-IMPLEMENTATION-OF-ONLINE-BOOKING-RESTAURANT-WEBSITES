<?php
    use App\Models\Crud;
    $this->Crud = new Crud();
?>

<?=$this->extend('frontend/designs');?>
<?=$this->section('title');?>
    <?=$title;?>
<?=$this->endSection();?>

<?=$this->section('content');?>
<style>
   
   /* Styles for screens smaller than 600 pixels */
   @media (max-width: 600px) {
   .sliders {
      height: 250px;
   }
   }

   /* Styles for screens between 601 and 900 pixels */
   @media (min-width: 601px) and (max-width: 900px) {
   .sliders {
      height: 400px;
   }
   }

   /* Styles for screens larger than 900 pixels */
   @media (min-width: 901px) {
   .sliders {
      height: 500px;
   }
   }
</style>

<div class="container-fluid py-3">
   <div class="row">
      <div class="col-12">
         <nav>
            <ol class="breadcrumb small mb-0">
               <li class="breadcrumb-item"><a href="<?=site_url(); ?>" class="text-decoration-none text-success">Home</a></li>
               
               <li class="breadcrumb-item active" aria-current="page"> Restaurants</li>
            </ol>
         </nav>
      </div>
   </div>
</div>
<section class="bg-white">
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="py-5 d-flex align-items-center gap-4">
               <div class="d-none d-md-block"><img alt="#" src="<?=site_url(); ?>assets/img/gallery.png" class="img-fluid ch-100 rounded-pill bg-light p-4"></div>
               <div class="text-md-start text-center">
                  <h2 class="mb-2 fw-bold"> Restaurants</h2>
                  <p class="lead m-0"><i class="bi bi-shop me-2"></i> <span id="counts"></span> restaurant(s)</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<div class="container-fluid py-5">
   <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4" id="load_data">
      
   </div>
   <div class="row my-4" id="loadmore"></div>
   
</div>
<script>var site_url = '<?php echo site_url(); ?>';</script>
<script src="<?php echo site_url(); ?>/assets/backend/jquery.min.js"></script>
<script>
    $(function() {
        load();
    });
   
      function load(x, y) {
        var more = 'no';
        var methods = '';
        if (parseInt(x) > 0 && parseInt(y) > 0) {
            more = 'yes';
            methods = '/' + x + '/' + y;
        }

        if (more == 'no') {
            $('#load_data').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        } else {
            $('#loadmore').html('<div class="col-sm-12 text-center"><div class="text-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mb-0 mt-2">Loading</p></div></div>');
        }

        var partner = $('#partner').val();
        var search = $('#search').val();
        //alert(status);

        $.ajax({
            url: site_url + 'home/restaurant/load' + methods,
            type: 'post',
            data: { partner: partner, search: search },
            success: function (data) {
                var dt = JSON.parse(data);
                if (more == 'no') {
                    $('#load_data').html(dt.item);
                } else {
                    $('#load_data').append(dt.item);
                }

                if (dt.offset > 0) {
                    $('#loadmore').html('<a href="javascript:;" class="btn btn-dim btn-light btn-block p-30" onclick="load(' + dt.limit + ', ' + dt.offset + ');"><em class="icon ni ni-redo fa-spin"></em> Load ' + dt.left + ' More</a>');
                } else {
                    $('#loadmore').html('');
                }
                $('#counts').html(dt.count);
            },
            complete: function () {
                $.getScript(site_url + '/assets/frontend/js/jsmodal.js');
            }
        });
    }
</script>   

<?=$this->endSection();?>