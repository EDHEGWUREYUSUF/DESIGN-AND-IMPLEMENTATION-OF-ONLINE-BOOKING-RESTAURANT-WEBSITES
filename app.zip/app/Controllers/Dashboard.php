<?php

namespace App\Controllers;

class Dashboard extends BaseController {
    private $db;

    public function __construct() {
		$this->db = \Config\Database::connect();
	}

    public function index($param1='',$param2='', $param3='') {
        $db = \Config\Database::connect();

        // check login
        $log_id = $this->session->get('ra_id');
        if(empty($log_id)) return redirect()->to(site_url('auth'));

        $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
        $role = strtolower($this->Crud->read_field('id', $role_id, 'access_role', 'name'));
        $role_c = $this->Crud->module($role_id, 'dashboard', 'create');
        $role_r = $this->Crud->module($role_id, 'dashboard', 'read');
        $role_u = $this->Crud->module($role_id, 'dashboard', 'update');
        $role_d = $this->Crud->module($role_id, 'dashboard', 'delete');
        if($role_r == 0){
            return redirect()->to(site_url('profile'));	
        }

        $data['log_id'] = $log_id;
        $data['role'] = $role;
        $data['role_c'] = $role_c;

        if($param1 == 'load') {
			$curr = '&#163;';
			$debit = 0;$credit = 0;
			if($role == 'developer' || $role == 'administrator'){
                $customer_id = $this->Crud->read_field('name', 'Customer', 'access_role', 'id');
                $restaurant_id = $this->Crud->read_field('name', 'Restaurant', 'access_role', 'id');
                $customer = $this->Crud->check('role_id', $customer_id, 'user');
                $restaurant = $this->Crud->check('role_id', $restaurant_id, 'user');
                $order = $this->Crud->check0('order');
                
				$wall = $this->Crud->read('wallet');
				if(!empty($wall)){
					foreach($wall as $w){
						$type = $w->type;
						if($type == 'debit')$debit+=(float)$w->amount;
						if($type == 'credit')$credit+=(float)$w->amount;
						
					}
				}
            }

			$bal = (float)$credit - (float)$debit;
			if($bal < 0)$bal = 0;
			$resp['balance'] =  $curr . number_format($bal, 2);
			$resp['debit'] =  $curr . number_format($debit, 2);
			$resp['credit'] =  $curr . number_format($credit, 2);

			$items = '
				<li class="list-group-item d-none d-md-block">
					<div class="row p-t-15">
						<div class="col-sm-8 m-b-2">
							<span class="text-dark"><b>MENU</b></span>
						</div>
						
						<div class="col-sm-4 m-b-2 text-right" >
							<b>ACTION</b>
						</div>
					</div>
				</li>
				
			';

			
			if(empty($item)) {
				$resp['item'] = $items.'
					<div class="text-center text-muted">
						<br/><br/><br/><br/>
						<em class="icon anticon anticon-home" style="font-size:150px;"></em><br/><br/>No Restaurant Category Returned
					</div>
				';
			} else {
				$resp['item'] = $items . $item;
			}

			$resp['customer'] = $customer;
            $resp['restaurant'] = $restaurant;
            $resp['order'] = $order;

			echo json_encode($resp);
			die;
		}
      

        $data['title'] = 'Dashboard | '.app_name;
        $data['page_active'] = 'dashboard';
        return view('dashboard', $data);
    }
    public function codes($sub_id=1, $count=10) {
        $rands = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for($i = 1; $i <= $count; $i++) {
            $code = substr(str_shuffle($rands), 0, 10);

            $vdata['sub_id'] = $sub_id;
            $vdata['code'] = $code;
            $vdata['reg_date'] = date(fdate);
            $this->Crud->create('coupon', $vdata);
        }
    }

    public function mail() {
        // $body['from'] = 'itcerebral@gmail.com';
        // $body['to'] = 'iyinusa@yahoo.co.uk';
        // $body['subject'] = 'Test Email';
        // $body['text'] = 'Sending test email via mailgun API';
        // echo $this->Crud->mailgun($body);
        $to = 'kennethjames23@yahoo.com, iyinusa@yahoo.co.uk';
        $subject = 'Test Email';
        $body = 'Sending test email from local email server';
        echo $this->Crud->send_email($to, $subject, $body);
    }

    public function order_check(){
        $log_id = $this->session->get('ra_id');
        if(!empty($log_id)){
            $role_id = $this->Crud->read_field('id', $log_id, 'user', 'role_id');
            $role = $this->Crud->read_field('id', $role_id, 'access_role', 'name');

            $restaurant_id = 0;
            if($role == 'Kitchen' || $role == 'Receptionist'){
                $restaurant_id = $this->Crud->read_field('id', $log_id, 'user', 'restaurant_id');
            }
            if($role == 'Restaurant'){
                $restaurant_id = $log_id;
            }

            $order = $this->Crud->check2('restaurant_id', $restaurant_id, 'status', 'pending', 'order');
            $status = false;
            if($order > 0){
                $status = true;
            }
            echo $status;
        }
    }
}
